# schema.md — Tables, fields, and POS mapping (ร้านรุ่งเรืองพานิช)

Version 1.0 · Last updated 2026-10-12 · PostgreSQL / Supabase

## Conventions

- Primary keys are `uuid` (default `gen_random_uuid()`) or string ID.
- Every table has `created_at timestamptz default now()`.
- Quantities are `integer`. Money is `numeric(12,2)`.
- No hard deletes. Core tables use `is_active = false`.
- RLS is ON for every table below.

## users

| Field | Type | Notes |
|---|---|---|
| id | uuid / text PK | equals Auth user id |
| name | text | display name (e.g. สมชาย ใจดี, พนักงาน) |
| role | enum `owner` / `staff` | |
| pin | text | 4-digit personal PIN (Owner: 1234, Staff: 5678) |
| is_active | boolean | default true |

## suppliers

| Field | Type | Notes |
|---|---|---|
| id | text PK | e.g. `sup-sermsuk`, `sup-singha`, `sup-unilever` |
| name | text | supplier company name |
| contact | text | phone or LINE ID |
| lead_time_days | integer | default 2, used in suggested order formula |
| is_active | boolean | |

## products

| Field | Type | Notes |
|---|---|---|
| id | text PK | e.g. `p-1900`, `p-2110`, `p-0001` |
| name_th | text | Thai product name (matches POS `CF_ITEMNAME`) |
| name_en | text null | English name |
| barcode | text null UNIQUE | barcode or POS item code (`CF_ITEMID`) |
| category | text | POS category (`CF_ITEMGROUPL1_GROUPNAME`) |
| supplier_id | FK → suppliers | |
| sell_price | numeric(12,2) | unit retail/carton price (`CF_TDUNITPRICE`) |
| cost_price | numeric(12,2) | **owner only** (hidden from staff via RLS) |
| low_stock_level | integer | warning threshold |
| track_mode | enum `fast` / `slow` | |
| has_expiry | boolean | true for perishable groceries |
| is_active | boolean | |

## stock_batches

One row per delivery lot of a product. Products without expiry have one active batch (`expiry_date` null).

| Field | Type | Notes |
|---|---|---|
| id | text PK | e.g. `b-milk-1`, `b-mama-1` |
| product_id | FK → products | |
| quantity | integer | current remaining quantity, $\ge 0$ |
| expiry_date | date null | YYYY-MM-DD |
| received_at | timestamptz | delivery timestamp |
| is_active | boolean | false when quantity reaches 0 |

`on_hand(product) = sum(quantity)` of its active batches.

## stock_movements

Every change of stock is one immutable row. Never edited, never deleted.

| Field | Type | Notes |
|---|---|---|
| id | text PK | |
| product_id | FK → products | |
| batch_id | FK → stock_batches null | |
| type | enum `sale` / `receive` / `waste` / `count_adjust` / `correction` | |
| quantity | integer | positive = added, negative = deducted |
| source | enum `pos_import` / `manual` / `count` | |
| import_id | FK → pos_imports null | set when source is `pos_import` |
| reason | text null | for waste: `expired` / `damaged` / `lost` / other |
| cost_at_time | numeric(12,2) null | copied from cost_price, **owner only** |
| negative_stock_flag | boolean | true if sale exceeded on-hand stock |
| created_by | FK → users | user id |
| created_at | timestamptz | |

## pos_imports & POS Header Mapping

Maps directly to **ร้านรุ่งเรืองพานิช** POS export files:

| POS Column | Target App Field | Description |
|---|---|---|
| `CF_ITEMNAME` | `raw_name` → `product.name_th` | Thai product name |
| `CF_ITEMID` | `raw_barcode` → `product.barcode` | Item ID / Barcode |
| `CF_TDBASEQUANTITY` | `quantity` | Quantity sold / moved |
| `CF_FSTOCKMAIN` | direction (`-1` = sale, `1` = receive) | Stock flow indicator |
| `CF_TRANDATE` / `TRANDATE` | `sales_date` | Date (converts BE 2569 $\to$ AD 2026) |
| `CF_UNITNAME` | unit display | ลัง, ลูก, แพค, ชิ้น |
| `CF_ITEMGROUPL1_GROUPNAME` | `product.category` | Category grouping |
| `CF_TDUNITPRICE` | unit price reference | Sale unit price |
| `CF_TRANNO` | transaction reference | Receipt number (ORCM... / IRNM...) |

## audit_logs

| Field | Type | Notes |
|---|---|---|
| id | text PK | |
| user_id | FK → users | |
| action | text | e.g. `receive_stock`, `record_waste`, `apply_pos_import` |
| table_name | text | target table |
| record_id | text | affected record ID |
| old_value | jsonb null | snapshot before mutation |
| new_value | jsonb null | snapshot after mutation |
| created_at | timestamptz | |

## Views & Security

- `v_stock_on_hand`: `product_id, on_hand` (Accessible by owner & staff)
- `v_low_stock`: products where `on_hand <= low_stock_level` (Owner & staff)
- `v_expiring_batches`: active batches expiring $\le 7$ days, plus expired (Owner & staff)
- `v_suggested_order`: suggested order per product: $\lceil\text{avg\_sales} \times (\text{lead\_time} + 7)\rceil - \text{on\_hand}$ (Owner only)
- `v_waste_value`: waste quantity $\times$ cost at time (Owner only)
