# architecture.md — One client, one shared backend (ร้านรุ่งเรืองพานิช)

Version 1.0 · Last updated 2026-10-12

## 1. Stack and Rationale

| Layer | Choice | Why |
|---|---|---|
| Client | React 19 + TypeScript + Vite, as a PWA | Mobile-first installable PWA for iOS Safari and Android Chrome |
| Backend | PostgreSQL (Supabase / local emulation) | Relational model for FIFO batches, movements, and RLS policies |
| CSV Engine | PapaParse with Auto-Detector | Handles real POS export headers (`CF_ITEMNAME`, `CF_ITEMID`, `CF_TDBASEQUANTITY`, `CF_FSTOCKMAIN`, etc.) and standard CSVs |
| Barcode | Camera `getUserMedia` + numeric keypad | Fast scanning on phone or manual lookup |
| Styling | Tailwind CSS 4 | Clean mobile UI, touch targets $\ge 48\text{px}$, responsive |

## 2. Real Store POS Integration Flow

```
   ┌──────────────────────────────────────────────────────────────┐
   │               ร้านรุ่งเรืองพานิช POS System                   │
   │               Export: pos_sales_YYYYMMDD.csv                 │
   │   (Headers: CF_ITEMNAME, CF_ITEMID, CF_TDBASEQUANTITY, ...)  │
   └──────────────────────────────┬───────────────────────────────┘
                                  │
                                  ▼ Drag & Drop / File Select
   ┌──────────────────────────────────────────────────────────────┐
   │               PapaParse Auto-Detection Parser                │
   │  • Detects CF_ITEMNAME ──► Product name                      │
   │  • Detects CF_ITEMID   ──► Product Barcode / Code            │
   │  • Detects CF_TDBASEQUANTITY ──► Quantity                    │
   │  • Parses Thai BE year: 02/10/2569 ──► 2026-10-02            │
   │  • Checks Rule 11 (Duplicate upload guard)                   │
   └──────────────────────────────┬───────────────────────────────┘
                                  │
                                  ▼
   ┌──────────────────────────────────────────────────────────────┐
   │             FIFO Batch Deduction Transaction                 │
   │  1. Match product by CF_ITEMID, then Thai CF_ITEMNAME        │
   │  2. Deduct from batch with earliest expiry date first        │
   │  3. Flag negative stock if sold > on-hand                    │
   │  4. Store unmatched rows in pos_import_rows                  │
   │  5. Append immutable record to stock_movements & audit_logs  │
   └──────────────────────────────────────────────────────────────┘
```

## 3. Security & Multi-User Boundary

- **Owner account (PIN: 1234)**: Full view of inventory, cost prices, profit margins, waste valuation, POS upload, and order management.
- **Staff account (PIN: 5678)**: Operational actions (Receive, Waste, Manual Sale, Shelf Count). **Cost prices and waste financials are completely filtered out.**
- **No secrets in client**: Anon key only.
- **Zero data loss**: Unmatched POS rows are preserved for linking; core records use `is_active = false`.
