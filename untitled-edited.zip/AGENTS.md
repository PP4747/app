# AGENTS.md — Standing rules for the AI

Paste this into System Instructions at the start of every AI Studio session. Project: Convenience Store Stock Manager (see prd.md).

## Source of truth

- `prd.md` decides behavior. `schema.md` decides table and field names. `architecture.md` decides stack and structure. `implementation-plan.md` decides what to build now.
- Follow `schema.md` exactly. Do not rename, add, or remove fields without asking first.
- Work on **one milestone at a time** from `implementation-plan.md`. Do not start the next one.
- If something in `prd.md` is ambiguous, list it at the end of your answer. Do not guess silently.

## Hard rules (security and multi-user)

- NEVER put a `service_role` key, admin token, or password in client code. Only the public `anon` key may appear in the browser.
- Every table has **row-level security ON**. Write the policy in the same change as the table.
- Roles come from `users.role` (`owner` or `staff`) and are checked by RLS, not only by hiding buttons.
- Every insert, update, or correction also writes an `audit_logs` row (user_id, action, old_value, new_value).
- No DELETE on core tables. Use `is_active = false`.
- Stock is changed **only** by inserting a `stock_movements` row (and updating the batch in the same transaction). Never edit stock numbers directly.
- `cost_price`, profit, and waste value must never be returned to a `staff` user. Enforce in RLS or views, not in the UI.
- Never log PINs, tokens, or customer data to the console.

## Conventions

- Language: TypeScript, React, Vite. Keep functions small and pure where possible.
- Business rules (stock, FIFO, low stock, expiry, suggested order) live in `src/lib/rules/` as **pure functions with no UI and no database calls**, so they can be checked by `runChecks()`.
- All user-facing text is Thai first, from `src/i18n/th.ts`. English from `src/i18n/en.ts`. No hardcoded strings in components.
- Dates are stored in UTC, displayed in Asia/Bangkok. Expiry dates are plain dates (no time).
- Quantities are integers (units), never floats.
- Money is stored in satang or as `numeric(12,2)`, never as float.
- Big tap targets (at least 44px). Primary actions reachable with one thumb.
- Every screen needs three states: loading, empty, error. Messages are in Thai and say what to do next.

## Definition of done (per milestone)

- Tested with **two accounts of different roles** in two browsers (owner and staff).
- Works installed on a phone. No console errors.
- `runChecks()` all PASS on the deployed URL, not only locally.
- No secret keys in the repo (search before every push).
- `progress.md` updated. If `prd.md` changed, the other five docs are updated in the same commit.

## Do not

- Do not generate the whole app in one go.
- Do not add libraries without saying why in `architecture.md`.
- Do not add features that are in "Out of scope" in `prd.md`.
- Do not "fix" a failing check by changing the check. Fix the code or ask.
