// schema.md - Types for Convenience Store Stock Manager

export type UserRole = 'owner' | 'staff';

export interface User {
  id: string;
  name: string;
  role: UserRole;
  pin: string;
  phone?: string;
  is_active: boolean;
  created_at: string;
}

export interface Supplier {
  id: string;
  name: string;
  contact: string; // phone or LINE ID
  lead_time_days: number; // default 2
  is_active: boolean;
  created_at: string;
}

export type TrackMode = 'fast' | 'slow';

export interface Product {
  id: string;
  name_th: string;
  name_en: string | null;
  barcode: string | null;
  category: string;
  supplier_id: string;
  sell_price: number;
  cost_price?: number; // OWNER ONLY - hidden from staff
  low_stock_level: number; // default 5
  track_mode: TrackMode;
  has_expiry: boolean;
  is_active: boolean;
  created_at: string;
}

export interface StockBatch {
  id: string;
  product_id: string;
  quantity: number; // current remaining, never below 0
  expiry_date: string | null; // YYYY-MM-DD
  received_at: string; // ISO
  is_active: boolean;
  created_at: string;
}

export type MovementType = 'sale' | 'receive' | 'waste' | 'count_adjust' | 'correction';
export type MovementSource = 'pos_import' | 'manual' | 'count';
export type WasteReason = 'expired' | 'damaged' | 'lost' | 'other';

export interface StockMovement {
  id: string;
  product_id: string;
  batch_id: string | null;
  type: MovementType;
  quantity: number; // positive = added, negative = removed
  source: MovementSource;
  import_id: string | null;
  reason: WasteReason | string | null;
  cost_at_time: number | null; // owner only
  negative_stock_flag: boolean;
  created_by: string; // user id
  created_by_name?: string;
  created_at: string;
}

export type ImportStatus = 'applied' | 'partial' | 'failed';

export interface PosImport {
  id: string;
  filename: string;
  sales_date: string; // YYYY-MM-DD
  row_count: number;
  matched_count: number;
  unmatched_count: number;
  status: ImportStatus;
  uploaded_by: string;
  created_at: string;
}

export type ImportRowStatus = 'matched' | 'unmatched' | 'resolved';

export interface PosImportRow {
  id: string;
  import_id: string;
  raw_name: string;
  raw_barcode: string | null;
  quantity: number;
  product_id: string | null;
  status: ImportRowStatus;
}

export type OrderStatus = 'draft' | 'ordered' | 'received' | 'cancelled';

export interface Order {
  id: string;
  supplier_id: string;
  status: OrderStatus;
  ordered_at: string | null;
  created_by: string;
  created_at: string;
  items?: OrderItem[];
}

export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string;
  suggested_qty: number;
  ordered_qty: number;
}

export interface Settings {
  id: 1;
  expiry_warning_days: number; // default 7
  urgent_expiry_days: number; // default 2
  language: 'th' | 'en';
}

export interface AuditLog {
  id: string;
  user_id: string;
  user_name?: string;
  action: string;
  table_name: string;
  record_id: string;
  old_value: Record<string, unknown> | null;
  new_value: Record<string, unknown> | null;
  created_at: string;
}

// Derived Views
export interface ProductWithStock extends Product {
  on_hand: number;
  batches: StockBatch[];
  supplier?: Supplier;
  avg_daily_sales_14d?: number;
  suggested_order_qty?: number;
  is_low_stock?: boolean;
  expiring_batches_count?: number;
  has_urgent_expiry?: boolean;
}

export interface ExpiringBatchInfo {
  batch: StockBatch;
  product: Product;
  days_until_expiry: number;
  is_expired: boolean;
  is_urgent: boolean;
}

export interface CheckResult {
  id: number;
  title: string;
  description: string;
  status: 'PASS' | 'FAIL';
  details: string;
}
