import React, { useState } from 'react';
import { Download, Smartphone, X } from 'lucide-react';
import { usePWAInstall } from './usePWAInstall';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  // If already running as an installed PWA, hide the button
  if (isInstalled) {
    return null;
  }

  // Chromium / Android / Desktop flow
  if (isInstallable) {
    return (
      <button
        onClick={install}
        className="flex items-center gap-1.5 rounded-lg bg-teal-600 hover:bg-teal-700 px-3 py-1.5 text-xs font-medium text-white shadow-sm transition active:scale-95"
      >
        <Download className="w-3.5 h-3.5" />
        <span>ติดตั้งแอป (PWA)</span>
      </button>
    );
  }

  // iOS Safari flow (beforeinstallprompt is not supported by WebKit)
  if (isIOS) {
    return (
      <>
        <button
          onClick={() => setShowIOSGuide(true)}
          className="flex items-center gap-1.5 rounded-lg border border-teal-200 bg-teal-50 hover:bg-teal-100 px-2.5 py-1 text-xs font-medium text-teal-800 transition active:scale-95"
        >
          <Smartphone className="w-3.5 h-3.5 text-teal-700" />
          <span>ติดตั้งบน iPhone</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
            <div className="w-full max-w-sm rounded-2xl bg-white p-5 shadow-2xl animate-in fade-in zoom-in-95">
              <div className="flex items-center justify-between pb-3 border-b border-gray-100">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-teal-600 flex items-center justify-center text-white font-bold text-sm">
                    📦
                  </div>
                  <h3 className="text-base font-semibold text-gray-900">ติดตั้งบน iPhone / iPad</h3>
                </div>
                <button
                  onClick={() => setShowIOSGuide(false)}
                  className="rounded-full p-1 text-gray-400 hover:bg-gray-100 hover:text-gray-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="mt-4 space-y-3 text-sm text-gray-700">
                <div className="flex items-start gap-3 bg-slate-50 p-3 rounded-xl">
                  <span className="w-6 h-6 rounded-full bg-teal-100 text-teal-700 flex items-center justify-center font-bold text-xs shrink-0">
                    1
                  </span>
                  <p>
                    แตะปุ่ม <strong>แชร์ (Share)</strong>{' '}
                    <span className="inline-block px-1.5 py-0.5 bg-gray-200 text-xs rounded">⎋</span> ที่แถบเครื่องมือของ Safari
                  </p>
                </div>
                <div className="flex items-start gap-3 bg-slate-50 p-3 rounded-xl">
                  <span className="w-6 h-6 rounded-full bg-teal-100 text-teal-700 flex items-center justify-center font-bold text-xs shrink-0">
                    2
                  </span>
                  <p>
                    เลื่อนลงแล้วแตะ <strong>"เพิ่มไปยังหน้าจอโฮม"</strong> (Add to Home Screen)
                  </p>
                </div>
                <div className="flex items-start gap-3 bg-slate-50 p-3 rounded-xl">
                  <span className="w-6 h-6 rounded-full bg-teal-100 text-teal-700 flex items-center justify-center font-bold text-xs shrink-0">
                    3
                  </span>
                  <p>
                    แตะ <strong>"เพิ่ม" (Add)</strong> มุมขวาบนเพื่อเปิดใช้งานเต็มหน้าจอเหมือนแอปจริง
                  </p>
                </div>
              </div>

              <button
                onClick={() => setShowIOSGuide(false)}
                className="mt-5 w-full rounded-xl bg-teal-600 py-2.5 text-sm font-medium text-white hover:bg-teal-700 transition"
              >
                เข้าใจแล้ว
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  // Fallback demo button
  return (
    <button
      onClick={() => setShowIOSGuide(true)}
      className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 px-2.5 py-1 text-xs font-medium text-slate-700 transition"
      title="คลิกเพื่อดูวิธีติดตั้งเป็นแอป PWA"
    >
      <Download className="w-3.5 h-3.5 text-slate-500" />
      <span>ติดตั้งแอป</span>
    </button>
  );
};
