import React, { useState } from 'react';
import { Delete, KeyRound, ShieldCheck, UserCheck, X } from 'lucide-react';
import { useStore } from '../lib/store';

interface PinLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  onSuccess?: () => void;
}

export const PinLoginModal: React.FC<PinLoginModalProps> = ({
  isOpen,
  onClose,
  title = 'สลับบัญชีผู้ใช้ / ยืนยันรหัส PIN',
  onSuccess,
}) => {
  const { switchUserWithPin, setCurrentUserRoleDirectly } = useStore();
  const [pin, setPin] = useState('');
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleDigit = (digit: string) => {
    if (pin.length < 4) {
      const nextPin = pin + digit;
      setPin(nextPin);
      setError(null);
      if (nextPin.length === 4) {
        verifyPin(nextPin);
      }
    }
  };

  const handleDelete = () => {
    setPin((prev) => prev.slice(0, -1));
    setError(null);
  };

  const handleClear = () => {
    setPin('');
    setError(null);
  };

  const verifyPin = (pinToTest: string) => {
    const res = switchUserWithPin(pinToTest);
    if (res.success) {
      setPin('');
      setError(null);
      if (onSuccess) onSuccess();
      onClose();
    } else {
      setError(res.message || 'รหัส PIN ไม่ถูกต้อง (ลอง 1234 หรือ 5678)');
      setTimeout(() => setPin(''), 600);
    }
  };

  const handleQuickSwitch = (role: 'owner' | 'staff') => {
    setCurrentUserRoleDirectly(role);
    setPin('');
    setError(null);
    if (onSuccess) onSuccess();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs animate-in fade-in">
      <div className="w-full max-w-sm rounded-3xl bg-white p-6 shadow-2xl">
        <div className="flex items-center justify-between pb-3 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-teal-50 rounded-xl text-teal-700">
              <KeyRound className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-gray-900">{title}</h3>
              <p className="text-xs text-gray-500">กรอกรหัส PIN 4 หลักประจำตัว</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-full p-1.5 text-gray-400 hover:bg-gray-100 hover:text-gray-600 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* PIN Dots Display */}
        <div className="my-5 flex flex-col items-center">
          <div className="flex items-center justify-center gap-4 py-2">
            {[0, 1, 2, 3].map((index) => {
              const filled = index < pin.length;
              return (
                <div
                  key={index}
                  className={`w-4 h-4 rounded-full transition-all duration-200 ${
                    filled
                      ? 'bg-teal-600 scale-125 ring-4 ring-teal-100'
                      : 'bg-gray-200 border border-gray-300'
                  }`}
                />
              );
            })}
          </div>

          {error ? (
            <p className="mt-2 text-xs font-medium text-rose-600 animate-shake">{error}</p>
          ) : (
            <p className="mt-2 text-xs text-gray-400">Owner PIN: 1234 • Staff PIN: 5678</p>
          )}
        </div>

        {/* Numeric Keypad */}
        <div className="grid grid-cols-3 gap-2.5">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((d) => (
            <button
              key={d}
              type="button"
              onClick={() => handleDigit(d)}
              className="h-14 rounded-2xl bg-slate-50 hover:bg-slate-100 active:bg-teal-100 active:text-teal-800 text-xl font-semibold text-slate-800 transition active:scale-95 shadow-2xs"
            >
              {d}
            </button>
          ))}
          <button
            type="button"
            onClick={handleClear}
            className="h-14 rounded-2xl bg-slate-50 hover:bg-slate-100 text-xs font-medium text-slate-500 transition active:scale-95"
          >
            ล้าง
          </button>
          <button
            type="button"
            onClick={() => handleDigit('0')}
            className="h-14 rounded-2xl bg-slate-50 hover:bg-slate-100 active:bg-teal-100 active:text-teal-800 text-xl font-semibold text-slate-800 transition active:scale-95 shadow-2xs"
          >
            0
          </button>
          <button
            type="button"
            onClick={handleDelete}
            className="h-14 rounded-2xl bg-slate-50 hover:bg-slate-100 flex items-center justify-center text-slate-600 transition active:scale-95"
          >
            <Delete className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Demo Switchers */}
        <div className="mt-5 pt-4 border-t border-gray-100 space-y-2">
          <p className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider text-center">
            สลับบทบาทสำหรับทดสอบ (Demo Switcher)
          </p>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => handleQuickSwitch('owner')}
              className="flex items-center justify-center gap-1.5 p-2 rounded-xl bg-teal-50 border border-teal-200 text-teal-800 text-xs font-semibold hover:bg-teal-100 transition active:scale-95"
            >
              <ShieldCheck className="w-4 h-4 text-teal-600" />
              <span>เจ้าของร้าน (1234)</span>
            </button>
            <button
              onClick={() => handleQuickSwitch('staff')}
              className="flex items-center justify-center gap-1.5 p-2 rounded-xl bg-sky-50 border border-sky-200 text-sky-800 text-xs font-semibold hover:bg-sky-100 transition active:scale-95"
            >
              <UserCheck className="w-4 h-4 text-sky-600" />
              <span>พนักงาน (5678)</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
