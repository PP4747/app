import React from 'react';
import { WifiOff } from 'lucide-react';
import { useStore } from '../lib/store';

export const OfflineIndicator: React.FC = () => {
  const { isOnline } = useStore();

  if (isOnline) return null;

  return (
    <div className="fixed bottom-20 left-4 right-4 z-50 flex items-center justify-between rounded-xl bg-amber-600 px-4 py-2.5 text-xs font-medium text-white shadow-lg animate-bounce">
      <div className="flex items-center gap-2">
        <WifiOff className="w-4 h-4 shrink-0" />
        <span>โหมดออฟไลน์: กำลังแสดงข้อมูลจากแคชในเครื่อง (ระบบล็อคการบันทึกเพื่อป้องกันสต็อกคลาดเคลื่อน)</span>
      </div>
    </div>
  );
};
