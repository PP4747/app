import React, { useEffect, useRef, useState } from 'react';
import { Camera, Check, Search, Sparkles, X } from 'lucide-react';
import { useStore } from '../lib/store';
import { Product } from '../types';

interface BarcodeScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScan: (barcode: string, product?: Product) => void;
  title?: string;
}

export const BarcodeScannerModal: React.FC<BarcodeScannerModalProps> = ({
  isOpen,
  onClose,
  onScan,
  title = 'สแกนบาร์โค้ดสินค้า (Barcode Scanner)',
}) => {
  const { products } = useStore();
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [manualCode, setManualCode] = useState('');
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);

  // Start camera if available
  useEffect(() => {
    if (!isOpen) {
      stopCamera();
      return;
    }

    let stream: MediaStream | null = null;
    let isCancelled = false;

    async function initCamera() {
      try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          setCameraError('เบราว์เซอร์ไม่รองรับกล้อง กรุณาใช้การพิมพ์บาร์โค้ด');
          return;
        }

        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' },
          audio: false,
        });

        if (isCancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play().catch(() => {});
          setCameraActive(true);
        }
      } catch (err) {
        console.warn('Camera access denied or unavailable:', err);
        setCameraError('ไม่สามารถเข้าถึงกล้องได้ กรุณาพิมพ์บาร์โค้ดหรือเลือกจากรายการด้านล่าง');
      }
    }

    initCamera();

    return () => {
      isCancelled = true;
      if (stream) {
        stream.getTracks().forEach((t) => t.stop());
      }
    };
  }, [isOpen]);

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach((t) => t.stop());
      videoRef.current.srcObject = null;
    }
    setCameraActive(false);
  };

  if (!isOpen) return null;

  const handleManualSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!manualCode.trim()) return;
    const barcode = manualCode.trim();
    const matched = products.find((p) => p.barcode === barcode);
    stopCamera();
    onScan(barcode, matched);
    onClose();
  };

  const handleSelectDemoProduct = (p: Product) => {
    if (!p.barcode) return;
    stopCamera();
    onScan(p.barcode, p);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-xs animate-in fade-in">
      <div className="w-full max-w-md rounded-3xl bg-white p-5 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-teal-50 text-teal-700 rounded-xl">
              <Camera className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-gray-900">{title}</h3>
          </div>
          <button
            onClick={() => {
              stopCamera();
              onClose();
            }}
            className="rounded-full p-1.5 text-gray-400 hover:bg-gray-100 hover:text-gray-600 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Viewfinder area */}
        <div className="relative mt-3 h-48 bg-slate-900 rounded-2xl overflow-hidden flex items-center justify-center">
          <video
            ref={videoRef}
            className={`w-full h-full object-cover ${cameraActive ? 'block' : 'hidden'}`}
            playsInline
            muted
          />

          {/* Scanner frame graphic */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-48 h-28 border-2 border-teal-400 rounded-xl relative shadow-[0_0_15px_rgba(45,212,191,0.5)]">
              <div className="absolute -top-1 -left-1 w-4 h-4 border-t-2 border-l-2 border-teal-300" />
              <div className="absolute -top-1 -right-1 w-4 h-4 border-t-2 border-r-2 border-teal-300" />
              <div className="absolute -bottom-1 -left-1 w-4 h-4 border-b-2 border-l-2 border-teal-300" />
              <div className="absolute -bottom-1 -right-1 w-4 h-4 border-b-2 border-r-2 border-teal-300" />
              {/* Laser scan line animation */}
              <div className="absolute left-0 right-0 top-1/2 h-0.5 bg-rose-500 shadow-[0_0_8px_red] animate-pulse" />
            </div>
          </div>

          {!cameraActive && (
            <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center bg-slate-800 text-slate-300 text-xs">
              <Camera className="w-8 h-8 text-slate-400 mb-1 animate-pulse" />
              <span>{cameraError || 'กำลังเริ่มการทำงานของกล้อง...'}</span>
            </div>
          )}
        </div>

        {/* Manual Barcode Input */}
        <form onSubmit={handleManualSubmit} className="mt-4">
          <label className="block text-xs font-semibold text-gray-700 mb-1">
            หรือกรอกเลขบาร์โค้ด (Manual Barcode)
          </label>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-3 text-gray-400" />
              <input
                type="text"
                value={manualCode}
                onChange={(e) => setManualCode(e.target.value)}
                placeholder="เช่น 8850188002021"
                className="w-full pl-9 pr-3 py-2 text-sm border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500 bg-slate-50 focus:bg-white"
              />
            </div>
            <button
              type="submit"
              className="px-4 py-2 bg-teal-600 hover:bg-teal-700 active:scale-95 text-white text-xs font-semibold rounded-xl transition flex items-center gap-1"
            >
              <Check className="w-4 h-4" />
              ค้นหา
            </button>
          </div>
        </form>

        {/* Quick Demo Barcode Buttons */}
        <div className="mt-4 pt-3 border-t border-gray-100 flex-1 overflow-y-auto">
          <div className="flex items-center gap-1 text-[11px] font-semibold text-gray-500 mb-2">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>เลือกบาร์โค้ดทดสอบสินค้าในร้าน (แตะเพื่อสแกนทันที):</span>
          </div>
          <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
            {products
              .filter((p) => p.barcode)
              .slice(0, 8)
              .map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => handleSelectDemoProduct(p)}
                  className="w-full text-left p-2 rounded-xl bg-slate-50 hover:bg-teal-50 hover:border-teal-200 border border-transparent transition flex items-center justify-between text-xs group"
                >
                  <div className="truncate pr-2">
                    <p className="font-medium text-slate-800 group-hover:text-teal-900 truncate">
                      {p.name_th}
                    </p>
                    <p className="text-[10px] text-slate-400 font-mono">{p.barcode}</p>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-teal-100 text-teal-800 font-medium shrink-0">
                    เลือก
                  </span>
                </button>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
};
