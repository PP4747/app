import React, { useState } from 'react';
import { Download, Share2, Smartphone, X } from 'lucide-react';
import { usePWAInstall } from './usePWAInstall';

export const PWAInstallBanner: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [dismissed, setDismissed] = useState(false);
  const [showIOSModal, setShowIOSModal] = useState(false);

  // If already running standalone on phone or dismissed, hide
  if (isInstalled || dismissed) {
    return null;
  }

  return (
    <>
      {/* Top Mobile Install Bar (Matches Slide 18 PWA Banner) */}
      <div className="bg-gradient-to-r from-teal-700 via-teal-800 to-emerald-800 text-white px-3.5 py-2.5 shadow-sm border-b border-teal-600/60 flex items-center justify-between text-xs animate-in slide-in-from-top duration-300">
        <div className="flex items-center gap-2.5 min-w-0 pr-2">
          <div className="w-8 h-8 rounded-xl bg-white text-teal-800 flex items-center justify-center font-bold text-sm shadow-xs shrink-0">
            📦
          </div>
          <div className="truncate">
            <p className="font-bold text-white text-xs truncate leading-tight">
              ติดตั้งแอปบนหน้าจอมือถือ (PWA)
            </p>
            <p className="text-[10px] text-teal-200 truncate">
              เปิดเต็มจอ เร็วขึ้น ใช้งานได้ทันทีไม่ต้องเข้า App Store
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          {isInstallable ? (
            <button
              onClick={install}
              className="px-3 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 active:scale-95 text-white font-bold text-xs shadow-xs transition flex items-center gap-1"
            >
              <Download className="w-3.5 h-3.5" />
              <span>ติดตั้ง</span>
            </button>
          ) : (
            <button
              onClick={() => setShowIOSModal(true)}
              className="px-3 py-1.5 rounded-xl bg-white text-teal-900 hover:bg-teal-50 active:scale-95 font-bold text-xs shadow-xs transition flex items-center gap-1"
            >
              <Smartphone className="w-3.5 h-3.5 text-teal-700" />
              <span>วิธีติดตั้ง</span>
            </button>
          )}

          <button
            onClick={() => setDismissed(true)}
            className="p-1 rounded-lg text-teal-300 hover:text-white hover:bg-teal-700/60 transition"
            title="ซ่อนแถบแจ้งเตือน"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* iOS Safari Guided Install Dialog (Slide 18) */}
      {showIOSModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 p-4 backdrop-blur-xs animate-in fade-in">
          <div className="w-full max-w-sm rounded-3xl bg-white p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-teal-600 text-white flex items-center justify-center text-sm font-bold">
                  📦
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">วิธีติดตั้งบน iPhone / iPad</h3>
                  <p className="text-[10px] text-slate-400">Safari บน iOS ไม่ต้องดาวน์โหลดผ่าน App Store</p>
                </div>
              </div>
              <button
                onClick={() => setShowIOSModal(false)}
                className="p-1 rounded-full text-slate-400 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2.5 text-xs text-slate-700">
              <div className="flex items-start gap-3 p-3 bg-slate-50 rounded-2xl border border-slate-100">
                <div className="w-6 h-6 rounded-full bg-teal-100 text-teal-800 font-bold flex items-center justify-center text-xs shrink-0">
                  1
                </div>
                <div>
                  <p className="font-semibold text-slate-900">
                    แตะปุ่ม "แชร์" (Share) ที่แถบล่างของ Safari
                  </p>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    มองหาไอคอนสี่เหลี่ยมที่มีลูกศรชี้ขึ้น <span className="inline-block px-1.5 py-0.5 bg-slate-200 rounded text-[10px]">⎋</span>
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 bg-slate-50 rounded-2xl border border-slate-100">
                <div className="w-6 h-6 rounded-full bg-teal-100 text-teal-800 font-bold flex items-center justify-center text-xs shrink-0">
                  2
                </div>
                <div>
                  <p className="font-semibold text-slate-900">
                    เลื่อนลงแล้วแตะ "เพิ่มไปยังหน้าจอโฮม"
                  </p>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    (Add to Home Screen พร้อมไอคอนแอปสีเขียว)
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 bg-slate-50 rounded-2xl border border-slate-100">
                <div className="w-6 h-6 rounded-full bg-teal-100 text-teal-800 font-bold flex items-center justify-center text-xs shrink-0">
                  3
                </div>
                <div>
                  <p className="font-semibold text-slate-900">
                    แตะ "เพิ่ม" (Add) มุมขวาบน
                  </p>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    ไอคอน Store Stock Manager จะไปปรากฏบนหน้าจอมือถือของคุณทันที
                  </p>
                </div>
              </div>
            </div>

            <button
              onClick={() => setShowIOSModal(false)}
              className="w-full py-3 bg-teal-600 hover:bg-teal-700 text-white rounded-xl font-bold text-xs transition active:scale-95"
            >
              เข้าใจแล้ว
            </button>
          </div>
        </div>
      )}
    </>
  );
};
