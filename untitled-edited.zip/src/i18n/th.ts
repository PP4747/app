// Thai translations (Primary language according to prd.md & AGENTS.md)

export const th = {
  app_name: 'Store Stock Manager',
  app_subtitle: 'ระบบจัดการสต็อกร้านสะดวกซื้อ',
  role_owner: 'เจ้าของร้าน (Owner)',
  role_staff: 'พนักงานหน้าร้าน (Staff)',
  role_switch: 'สลับบัญชีผู้ใช้',
  enter_pin: 'กรอกรหัส PIN ประจำตัว',
  pin_hint_owner: 'PIN เจ้าของร้าน: 1234',
  pin_hint_staff: 'PIN พนักงาน: 5678',
  login: 'เข้าสู่ระบบ',
  logout: 'ออกจากระบบ',
  login_error: 'รหัส PIN ไม่ถูกต้อง โปรดลองอีกครั้ง',

  // Navigation
  nav_home: 'หน้าหลัก',
  nav_products: 'สินค้า',
  nav_receive: 'รับของ',
  nav_waste: 'ของเสีย',
  nav_pos_upload: 'นำเข้า POS',
  nav_to_order: 'ต้องสั่งซื้อ',
  nav_manual_sale: 'บันทึกขาย',
  nav_shelf_count: 'นับสต็อก',
  nav_summary: 'สรุปรายสัปดาห์',
  nav_audit: 'ประวัติบันทึก',
  nav_checks: 'ตรวจระบบ (M2)',

  // Alerts & Badges
  alerts_title: 'รายการแจ้งเตือนด่วน',
  alert_low_stock: 'สินค้าสต็อกต่ำ',
  alert_expiring_soon: 'ใกล้หมดอายุ (ภายใน 7 วัน)',
  alert_expired: 'หมดอายุแล้ว!',
  alert_urgent: 'ด่วนมาก',
  no_alerts: 'สต็อกอยู่ในเกณฑ์ปกติ ไม่มีรายการด่วน',

  // Actions
  action_receive_delivery: 'รับสินค้าเข้าสต็อก',
  action_record_waste: 'บันทึกสินค้าเสียหาย/หมดอายุ',
  action_manual_sale: 'บันทึกการขายหน้าร้าน',
  action_shelf_count: 'ตรวจนับสต็อกจริงบนชั้นวาง',
  action_upload_pos: 'อัปโหลดไฟล์ยอดขาย POS',
  action_view_orders: 'ดูรายการต้องสั่งซื้อ',
  action_copy_line: 'คัดลอกข้อความส่ง LINE ซัพพลายเออร์',
  action_mark_ordered: 'ทำเครื่องหมายว่าสั่งแล้ว',
  action_export_csv: 'ส่งออกข้อมูลเป็น CSV',
  action_scan_barcode: 'สแกนบาร์โค้ด',
  action_add_product: 'เพิ่มสินค้าใหม่',
  action_confirm: 'ยืนยัน',
  action_cancel: 'ยกเลิก',
  action_close: 'ปิด',
  action_search: 'ค้นหาสินค้า (ชื่อไทย / บาร์โค้ด)...',

  // Product Fields
  field_barcode: 'บาร์โค้ด',
  field_product_name: 'ชื่อสินค้า',
  field_category: 'หมวดหมู่',
  field_supplier: 'ผู้จัดจำหน่าย / ซัพพลายเออร์',
  field_sell_price: 'ราคาขาย',
  field_cost_price: 'ราคาทุน (เฉพาะเจ้าของร้าน)',
  field_on_hand: 'คงเหลือ (ชิ้น)',
  field_low_stock_level: 'เกณฑ์แจ้งเตือนสต็อกต่ำ',
  field_expiry_date: 'วันหมดอายุ (วว/ดด/ปปปป)',
  field_quantity: 'จำนวน (ชิ้น)',
  field_batches: 'ล็อตสินค้า (Batches)',
  field_reason: 'สาเหตุของเสีย',
  field_counted_qty: 'จำนวนที่นับได้จริง',
  field_system_qty: 'จำนวนในระบบปัจจุบัน',
  field_diff: 'ผลต่าง',

  // Waste reasons
  reason_expired: 'สินค้าหมดอายุ',
  reason_damaged: 'ชำรุด / แตกหัก / บรรจุภัณฑ์ฉีกขาด',
  reason_lost: 'สูญหาย / นับไม่พบ',
  reason_other: 'อื่นๆ',

  // POS Upload
  pos_upload_title: 'อัปโหลดไฟล์ยอดขายประจำวันจากเครื่อง POS (CSV)',
  pos_upload_desc: 'ระบบจะตัดสต็อกแบบ FIFO (หยิบล็อตที่หมดอายุก่อน) และแจ้งเตือนแถวที่ไม่พบบาร์โค้ด',
  pos_drop_zone: 'คลิกเพื่อเลือกไฟล์ หรือลากไฟล์ CSV มาวางที่นี่',
  pos_download_sample: 'ดาวน์โหลดไฟล์ตัวอย่าง POS (CSV)',
  pos_mapping_title: 'ตรวจสอบการจับคู่คอลัมน์',
  pos_preview_title: 'พรีวิวยอดขายก่อนตัดสต็อก',
  pos_matched_rows: 'จับคู่สินค้าสำเร็จ',
  pos_unmatched_rows: 'ไม่พบในระบบ (ต้องระบุสินค้า)',
  pos_apply_button: 'ยืนยันตัดสต็อกตามไฟล์ POS',
  pos_duplicate_warning: 'คำเตือน: คุณเคยอัปโหลดไฟล์ชื่อนี้ในวันนี้แล้ว ต้องการทำซ้ำหรือไม่?',
  pos_success_toast: 'ตัดสต็อกตามยอดขาย POS สำเร็จเรียบร้อย',

  // Ordering
  order_suggested_formula: 'สูตรแนะนำ = ปัดขึ้น(ยอดขายเฉลี่ย 14 วัน × (ระยะเวลารอของ + 7 วัน)) - จำนวนคงเหลือ',
  order_lead_time: 'ระยะเวลารอสินค้า (วัน)',
  order_suggested_qty: 'จำนวนที่ระบบแนะนำ',
  order_actual_qty: 'จำนวนที่ต้องการสั่งจริง',
  order_copied_toast: 'คัดลอกรายการสั่งซื้อสำหรับส่ง LINE เรียบร้อยแล้ว!',

  // PWA & Connectivity
  install_pwa: 'ติดตั้งแอปบนหน้าจอโฮม',
  install_ios_guide_title: 'วิธีติดตั้งบน iPhone / iPad',
  install_ios_step1: '1. แตะปุ่ม "แชร์" (Share) ที่แถบด้านล่างของ Safari',
  install_ios_step2: '2. เลื่อนลงแล้วเลือก "เพิ่มไปยังหน้าจอโฮม" (Add to Home Screen)',
  offline_warning: 'ขณะนี้อยู่ในโหมดออฟไลน์ ระบบแสดงข้อมูลจากแคช',
  offline_write_error: 'ไม่สามารถบันทึกได้ขณะออฟไลน์ โปรดเชื่อมต่ออินเทอร์เน็ตเพื่อป้องกันสต็อกคลาดเคลื่อน',

  // Contact support
  contact_line_support: 'แจ้งปัญหาการใช้งาน: ติดต่อทีมพัฒนานักศึกษา KMITL (LINE / Email)',

  // States
  loading: 'กำลังโหลดข้อมูล...',
  empty_products: 'ไม่พบรายการสินค้าที่ตรงกับคำค้นหา',
  empty_batches: 'ไม่มีสต็อกคงเหลือในขณะนี้',
  success_receive: 'บันทึกรับสินค้าเข้าสต็อกสำเร็จ',
  success_waste: 'บันทึกสินค้าเสียหายสำเร็จ',
  success_sale: 'บันทึกการขายสำเร็จ (ตัดสต็อก FIFO แล้ว)',
  success_count: 'ปรับปรุงยอดสต็อกจากการนับจริงสำเร็จ',
};
