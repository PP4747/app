// English translations (Fallback language)

export const en = {
  app_name: 'Store Stock Manager',
  app_subtitle: 'Convenience Store Stock Manager',
  role_owner: 'Store Owner',
  role_staff: 'Store Staff',
  role_switch: 'Switch Account',
  enter_pin: 'Enter Personal PIN',
  pin_hint_owner: 'Owner PIN: 1234',
  pin_hint_staff: 'Staff PIN: 5678',
  login: 'Sign In',
  logout: 'Sign Out',
  login_error: 'Invalid PIN. Please try again.',

  // Navigation
  nav_home: 'Dashboard',
  nav_products: 'Inventory',
  nav_receive: 'Receive',
  nav_waste: 'Waste',
  nav_pos_upload: 'POS Upload',
  nav_to_order: 'To Order',
  nav_manual_sale: 'Quick Sale',
  nav_shelf_count: 'Shelf Count',
  nav_summary: 'Weekly Summary',
  nav_audit: 'Audit Log',
  nav_checks: 'System Checks (M2)',

  // Alerts & Badges
  alerts_title: 'Urgent Alerts',
  alert_low_stock: 'Low Stock Items',
  alert_expiring_soon: 'Expiring Soon (Within 7 Days)',
  alert_expired: 'Expired Items!',
  alert_urgent: 'Urgent',
  no_alerts: 'All stock levels and expiry dates are normal.',

  // Actions
  action_receive_delivery: 'Receive Delivery',
  action_record_waste: 'Record Waste / Damage',
  action_manual_sale: 'Record Manual Sale',
  action_shelf_count: 'Shelf Count Adjustment',
  action_upload_pos: 'Upload Daily POS Sales',
  action_view_orders: 'View Suggested Orders',
  action_copy_line: 'Copy for Supplier LINE Chat',
  action_mark_ordered: 'Mark as Ordered',
  action_export_csv: 'Export Data to CSV',
  action_scan_barcode: 'Scan Barcode',
  action_add_product: 'Add New Product',
  action_confirm: 'Confirm',
  action_cancel: 'Cancel',
  action_close: 'Close',
  action_search: 'Search products (Thai / English / Barcode)...',

  // Product Fields
  field_barcode: 'Barcode',
  field_product_name: 'Product Name',
  field_category: 'Category',
  field_supplier: 'Supplier',
  field_sell_price: 'Sell Price',
  field_cost_price: 'Cost Price (Owner Only)',
  field_on_hand: 'On Hand (Units)',
  field_low_stock_level: 'Low Stock Warning Level',
  field_expiry_date: 'Expiry Date',
  field_quantity: 'Quantity',
  field_batches: 'Delivery Batches',
  field_reason: 'Waste Reason',
  field_counted_qty: 'Actual Counted Quantity',
  field_system_qty: 'Current System Quantity',
  field_diff: 'Difference',

  // Waste reasons
  reason_expired: 'Expired Product',
  reason_damaged: 'Damaged / Broken / Packaging Tear',
  reason_lost: 'Lost / Missing',
  reason_other: 'Other Reason',

  // POS Upload
  pos_upload_title: 'Upload Daily POS Sales Export (CSV)',
  pos_upload_desc: 'System applies FIFO batch deduction and flags unlinked barcodes.',
  pos_drop_zone: 'Click or drop daily POS CSV file here',
  pos_download_sample: 'Download Sample POS CSV',
  pos_mapping_title: 'Map CSV Columns',
  pos_preview_title: 'Preview Sales Before Deduction',
  pos_matched_rows: 'Matched Products',
  pos_unmatched_rows: 'Unmatched Rows (Link Product)',
  pos_apply_button: 'Apply FIFO Stock Reduction',
  pos_duplicate_warning: 'Warning: This file was already uploaded today. Apply again?',
  pos_success_toast: 'POS sales applied and stock updated successfully.',

  // Ordering
  order_suggested_formula: 'Suggested = ceil(Avg Daily Sales × (Lead Time + 7)) - On Hand',
  order_lead_time: 'Lead Time (Days)',
  order_suggested_qty: 'Suggested Quantity',
  order_actual_qty: 'Order Quantity',
  order_copied_toast: 'Supplier order copied to clipboard for LINE message!',

  // PWA & Connectivity
  install_pwa: 'Install App on Home Screen',
  install_ios_guide_title: 'Install on iPhone / iPad',
  install_ios_step1: '1. Tap the "Share" button in Safari toolbar',
  install_ios_step2: '2. Scroll down and choose "Add to Home Screen"',
  offline_warning: 'Offline Mode: Displaying cached data.',
  offline_write_error: 'Writes require an active network connection.',

  // Contact support
  contact_line_support: 'Support Contact: KMITL Student Development Team',

  // States
  loading: 'Loading data...',
  empty_products: 'No products match your search query.',
  empty_batches: 'No active stock batches found.',
  success_receive: 'Delivery received successfully.',
  success_waste: 'Waste recorded successfully.',
  success_sale: 'Sale recorded (FIFO batch deduction applied).',
  success_count: 'Stock count adjustment recorded.',
};
