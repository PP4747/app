import { en } from './en';
import { th } from './th';

export type TranslationKey = keyof typeof th;

export const translations = {
  th,
  en,
};

export function getTranslation(lang: 'th' | 'en', key: TranslationKey): string {
  return translations[lang]?.[key] ?? translations.th[key] ?? key;
}
