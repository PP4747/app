/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Barcode,
  FileSpreadsheet,
  Home,
  KeyRound,
  Package,
  ShieldCheck,
  ShoppingCart,
  Trash2,
  Truck,
  UserCheck,
} from 'lucide-react';
import { BarcodeScannerModal } from './components/BarcodeScannerModal';
import { OfflineIndicator } from './components/OfflineIndicator';
import { PinLoginModal } from './components/PinLoginModal';
import { PWAInstallBanner } from './components/PWAInstallBanner';
import { PWAInstallButton } from './components/PWAInstallButton';
import { AlertsView } from './features/alerts/AlertsView';
import { AuditLogsView } from './features/audit/AuditLogsView';
import { ShelfCountView } from './features/count/ShelfCountView';
import { OwnerHome } from './features/home/OwnerHome';
import { StaffHome } from './features/home/StaffHome';
import { PosUploadView } from './features/pos/PosUploadView';
import { ProductList } from './features/products/ProductList';
import { ReceiveView } from './features/receive/ReceiveView';
import { ManualSaleView } from './features/sales/ManualSaleView';
import { WeeklySummaryView } from './features/summary/WeeklySummaryView';
import { ToOrderView } from './features/toorder/ToOrderView';
import { WasteView } from './features/waste/WasteView';
import { StoreProvider, useStore } from './lib/store';
import { Product } from './types';

function MainApp() {
  const { currentUser } = useStore();
  const [activeTab, setActiveTab] = useState<string>('home');
  const [isPinModalOpen, setIsPinModalOpen] = useState<boolean>(false);
  const [isScanModalOpen, setIsScanModalOpen] = useState<boolean>(false);
  const [targetProductId, setTargetProductId] = useState<string | undefined>(undefined);

  // Guard: if staff user is on owner-only tab, revert to home
  const isOwnerOnlyTab = ['pos_upload', 'to_order', 'summary', 'audit'].includes(activeTab);
  if (currentUser.role === 'staff' && isOwnerOnlyTab) {
    setActiveTab('home');
  }

  const handleOpenReceive = (productId?: string) => {
    setTargetProductId(productId);
    setActiveTab('receive');
  };

  const handleOpenWaste = (productId?: string) => {
    setTargetProductId(productId);
    setActiveTab('waste');
  };

  const handleBarcodeScanned = (barcode: string, matchedProduct?: Product) => {
    if (matchedProduct) {
      setTargetProductId(matchedProduct.id);
      setActiveTab('products');
    }
  };

  return (
    <div className="min-h-screen bg-slate-100/80 text-slate-900 flex flex-col max-w-md mx-auto shadow-xl relative select-none">
      <OfflineIndicator />

      {/* Top App Header */}
      <header className="sticky top-0 z-40 bg-teal-800 text-white px-4 py-3 shadow-md">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-teal-700/80 border border-teal-600/50 flex items-center justify-center font-bold text-lg shadow-2xs">
              📦
            </div>
            <div>
              <h1 className="text-sm font-bold tracking-tight leading-tight">
                Store Stock Manager
              </h1>
              <p className="text-[11px] text-teal-200">ระบบจัดการสต็อกร้านสะดวกซื้อ PWA</p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <PWAInstallButton />

            {/* Role switch button */}
            <button
              onClick={() => setIsPinModalOpen(true)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-teal-900/60 hover:bg-teal-900 border border-teal-700/60 text-xs font-medium text-teal-100 transition active:scale-95"
              title="สลับบัญชี (PIN 1234/5678)"
            >
              <KeyRound className="w-3.5 h-3.5 text-teal-300" />
              <span className="font-semibold text-[11px]">
                {currentUser.role === 'owner' ? 'เจ้าของ' : 'พนักงาน'}
              </span>
            </button>
          </div>
        </div>

        {/* Sub-bar with User identification & Alerts */}
        <div className="mt-2.5 pt-2 border-t border-teal-700/60 flex items-center justify-between text-[11px]">
          <div className="flex items-center gap-1.5 text-teal-100 truncate">
            {currentUser.role === 'owner' ? (
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            ) : (
              <UserCheck className="w-3.5 h-3.5 text-sky-300 shrink-0" />
            )}
            <span className="truncate">
              ผู้ใช้: <strong>{currentUser.name}</strong>
            </span>
          </div>

        </div>
      </header>

      {/* Prominent PWA Install Banner (Slide 18 of Capstone Lecture) */}
      <PWAInstallBanner />

      {/* Main Content Viewport */}
      <main className="flex-1 p-3.5 overflow-y-auto">
        {activeTab === 'home' &&
          (currentUser.role === 'owner' ? (
            <OwnerHome
              onNavigate={setActiveTab}
              onOpenReceive={() => handleOpenReceive()}
              onOpenWaste={() => handleOpenWaste()}
            />
          ) : (
            <StaffHome
              onNavigate={setActiveTab}
              onOpenReceive={() => handleOpenReceive()}
              onOpenWaste={() => handleOpenWaste()}
              onOpenScan={() => setIsScanModalOpen(true)}
            />
          ))}

        {activeTab === 'products' && (
          <ProductList
            onOpenReceiveForProduct={handleOpenReceive}
            onOpenWasteForProduct={handleOpenWaste}
            onOpenScan={() => setIsScanModalOpen(true)}
          />
        )}

        {activeTab === 'receive' && (
          <ReceiveView
            initialProductId={targetProductId}
            onOpenScan={() => setIsScanModalOpen(true)}
            onDone={() => setActiveTab('products')}
          />
        )}

        {activeTab === 'waste' && (
          <WasteView
            initialProductId={targetProductId}
            onOpenScan={() => setIsScanModalOpen(true)}
            onDone={() => setActiveTab('home')}
          />
        )}

        {activeTab === 'manual_sale' && (
          <ManualSaleView
            onOpenScan={() => setIsScanModalOpen(true)}
            onDone={() => setActiveTab('home')}
          />
        )}

        {activeTab === 'shelf_count' && (
          <ShelfCountView
            onOpenScan={() => setIsScanModalOpen(true)}
            onDone={() => setActiveTab('products')}
          />
        )}

        {activeTab === 'pos_upload' && currentUser.role === 'owner' && (
          <PosUploadView onDone={() => setActiveTab('home')} />
        )}

        {activeTab === 'to_order' && currentUser.role === 'owner' && (
          <ToOrderView />
        )}

        {activeTab === 'alerts' && (
          <AlertsView
            onOpenWasteForProduct={handleOpenWaste}
            onNavigateToOrder={() => setActiveTab('to_order')}
          />
        )}

        {activeTab === 'summary' && currentUser.role === 'owner' && (
          <WeeklySummaryView />
        )}

        {activeTab === 'audit' && currentUser.role === 'owner' && (
          <AuditLogsView />
        )}

      </main>

      {/* Bottom Mobile Tab Bar (Thumb friendly > 48px) */}
      <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white border-t border-slate-200 px-2 py-1.5 z-40 shadow-lg flex items-center justify-around">
        <button
          onClick={() => setActiveTab('home')}
          className={`flex flex-col items-center py-1 px-2 rounded-xl transition ${
            activeTab === 'home'
              ? 'text-teal-700 font-bold'
              : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">หน้าหลัก</span>
        </button>

        <button
          onClick={() => setActiveTab('products')}
          className={`flex flex-col items-center py-1 px-2 rounded-xl transition ${
            activeTab === 'products'
              ? 'text-teal-700 font-bold'
              : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <Package className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">สินค้า</span>
        </button>

        {/* Central Scan Button */}
        <button
          onClick={() => setIsScanModalOpen(true)}
          className="w-12 h-12 -mt-5 rounded-full bg-teal-600 hover:bg-teal-700 active:scale-95 text-white flex items-center justify-center shadow-md border-4 border-slate-100 transition"
          title="สแกนบาร์โค้ด"
        >
          <Barcode className="w-6 h-6" />
        </button>

        {currentUser.role === 'owner' ? (
          <>
            <button
              onClick={() => setActiveTab('to_order')}
              className={`flex flex-col items-center py-1 px-2 rounded-xl transition ${
                activeTab === 'to_order'
                  ? 'text-teal-700 font-bold'
                  : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              <ShoppingCart className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">สั่งซื้อ</span>
            </button>

            <button
              onClick={() => setActiveTab('pos_upload')}
              className={`flex flex-col items-center py-1 px-2 rounded-xl transition ${
                activeTab === 'pos_upload'
                  ? 'text-teal-700 font-bold'
                  : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              <FileSpreadsheet className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">POS</span>
            </button>

          </>
        ) : (
          <>
            <button
              onClick={() => handleOpenReceive()}
              className={`flex flex-col items-center py-1 px-2 rounded-xl transition ${
                activeTab === 'receive'
                  ? 'text-teal-700 font-bold'
                  : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              <Truck className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">รับของ</span>
            </button>

            <button
              onClick={() => handleOpenWaste()}
              className={`flex flex-col items-center py-1 px-2 rounded-xl transition ${
                activeTab === 'waste'
                  ? 'text-teal-700 font-bold'
                  : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              <Trash2 className="w-5 h-5" />
              <span className="text-[10px] mt-0.5">ของเสีย</span>
            </button>

          </>
        )}
      </nav>

      {/* PIN Login / Switch Account Modal */}
      <PinLoginModal
        isOpen={isPinModalOpen}
        onClose={() => setIsPinModalOpen(false)}
      />

      {/* Barcode Scanner Modal */}
      <BarcodeScannerModal
        isOpen={isScanModalOpen}
        onClose={() => setIsScanModalOpen(false)}
        onScan={handleBarcodeScanned}
      />
    </div>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <MainApp />
    </StoreProvider>
  );
}
