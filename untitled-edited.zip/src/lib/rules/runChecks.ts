// implementation-plan.md M2 verification runner
// Tests the 8 mandatory business logic scenarios defined in the implementation plan.

import { CheckResult, Product, StockBatch } from '../../types';
import {
  calculateOnHand,
  calculateSuggestedOrder,
  calculateWasteValue,
  deductFIFOBatches,
  evaluateExpiry,
  filterStaffProduct,
  isLowStock,
  matchPosProduct,
} from './stockRules';

export function runChecks(): CheckResult[] {
  const results: CheckResult[] = [];

  // -------------------------------------------------------------
  // Check 1: Sale of 5 from two batches (3 expiring Oct 10, 10 expiring Oct 20)
  // Expected: takes 3 from Oct 10 batch, 2 from Oct 20 batch.
  // -------------------------------------------------------------
  try {
    const batches: StockBatch[] = [
      {
        id: 'b-oct20',
        product_id: 'p1',
        quantity: 10,
        expiry_date: '2026-10-20',
        received_at: '2026-10-01T00:00:00Z',
        is_active: true,
        created_at: '2026-10-01T00:00:00Z',
      },
      {
        id: 'b-oct10',
        product_id: 'p1',
        quantity: 3,
        expiry_date: '2026-10-10',
        received_at: '2026-10-01T00:00:00Z',
        is_active: true,
        created_at: '2026-10-01T00:00:00Z',
      },
    ];

    const result = deductFIFOBatches(batches, 5);
    const oct10Deduction = result.deductions.find((d) => d.batchId === 'b-oct10')?.quantityDeducted;
    const oct20Deduction = result.deductions.find((d) => d.batchId === 'b-oct20')?.quantityDeducted;
    const b10Remaining = result.updatedBatches.find((b) => b.id === 'b-oct10')?.quantity;
    const b20Remaining = result.updatedBatches.find((b) => b.id === 'b-oct20')?.quantity;

    const pass =
      oct10Deduction === 3 &&
      oct20Deduction === 2 &&
      b10Remaining === 0 &&
      b20Remaining === 8 &&
      !result.negativeStockFlag;

    results.push({
      id: 1,
      title: 'FIFO Batch Deduction',
      description: 'Sale of 5 from 2 batches (3 exp Oct 10, 10 exp Oct 20) takes 3 from Oct 10 and 2 from Oct 20.',
      status: pass ? 'PASS' : 'FAIL',
      details: `Deducted: Oct10=${oct10Deduction}/3, Oct20=${oct20Deduction}/2. Remaining: Oct10=${b10Remaining}, Oct20=${b20Remaining}.`,
    });
  } catch (err: unknown) {
    results.push({
      id: 1,
      title: 'FIFO Batch Deduction',
      description: 'Sale of 5 from 2 batches',
      status: 'FAIL',
      details: String(err),
    });
  }

  // -------------------------------------------------------------
  // Check 2: Sale larger than stock -> stock becomes 0 and negative_stock_flag is true.
  // -------------------------------------------------------------
  try {
    const batches: StockBatch[] = [
      {
        id: 'b-single',
        product_id: 'p2',
        quantity: 4,
        expiry_date: '2026-10-15',
        received_at: '2026-10-01T00:00:00Z',
        is_active: true,
        created_at: '2026-10-01T00:00:00Z',
      },
    ];

    const result = deductFIFOBatches(batches, 7);
    const onHandAfter = calculateOnHand(result.updatedBatches);
    const pass = onHandAfter === 0 && result.negativeStockFlag === true && result.unfulfilledQuantity === 3;

    results.push({
      id: 2,
      title: 'Negative Stock Guard',
      description: 'Sale larger than stock sets remaining stock to 0 and flags negative_stock_flag = true.',
      status: pass ? 'PASS' : 'FAIL',
      details: `Initial: 4, Sold: 7 -> On Hand: ${onHandAfter}, negative_stock_flag: ${result.negativeStockFlag}, Unfulfilled: ${result.unfulfilledQuantity}.`,
    });
  } catch (err: unknown) {
    results.push({
      id: 2,
      title: 'Negative Stock Guard',
      description: 'Sale larger than stock',
      status: 'FAIL',
      details: String(err),
    });
  }

  // -------------------------------------------------------------
  // Check 3: on_hand = 8, low_stock_level = 10 -> appears in low stock.
  // -------------------------------------------------------------
  try {
    const isLow8 = isLowStock(8, 10);
    const isLow12 = isLowStock(12, 10);
    const pass = isLow8 === true && isLow12 === false;

    results.push({
      id: 3,
      title: 'Low Stock Level Check',
      description: 'Product with on_hand = 8 and low_stock_level = 10 triggers low stock alert.',
      status: pass ? 'PASS' : 'FAIL',
      details: `on_hand=8 (level 10): ${isLow8 ? 'Low' : 'Normal'} | on_hand=12 (level 10): ${isLow12 ? 'Low' : 'Normal'}.`,
    });
  } catch (err: unknown) {
    results.push({
      id: 3,
      title: 'Low Stock Level Check',
      description: 'Low stock condition',
      status: 'FAIL',
      details: String(err),
    });
  }

  // -------------------------------------------------------------
  // Check 4: Batch expiring in 5 days with warning = 7 -> appears in expiring; batch in 10 days does not.
  // -------------------------------------------------------------
  try {
    const today = '2026-10-12';
    const batch5Days = evaluateExpiry('2026-10-17', today, 7, 2);
    const batch10Days = evaluateExpiry('2026-10-22', today, 7, 2);

    const pass = batch5Days.isExpiringSoon === true && batch10Days.isExpiringSoon === false;

    results.push({
      id: 4,
      title: 'Expiry Warning Window',
      description: 'Batch expiring in 5 days (warning=7) triggers alert; batch in 10 days does not.',
      status: pass ? 'PASS' : 'FAIL',
      details: `+5 days: isExpiringSoon=${batch5Days.isExpiringSoon} | +10 days: isExpiringSoon=${batch10Days.isExpiringSoon}.`,
    });
  } catch (err: unknown) {
    results.push({
      id: 4,
      title: 'Expiry Warning Window',
      description: 'Expiry alert window calculation',
      status: 'FAIL',
      details: String(err),
    });
  }

  // -------------------------------------------------------------
  // Check 5: Suggested order with avg 6/day, lead time 2 days, on_hand 20 -> ceil(6 * 9) - 20 = 34.
  // -------------------------------------------------------------
  try {
    // Formula: ceil(avg_daily_sales * (lead_time + 7)) - on_hand
    // ceil(6 * (2 + 7)) - 20 = ceil(6 * 9) - 20 = 54 - 20 = 34.
    const suggested = calculateSuggestedOrder(6, 2, 20, 5, true);
    const pass = suggested === 34;

    results.push({
      id: 5,
      title: 'Suggested Order Formula',
      description: 'avg 6/day, lead time 2 days, on_hand 20 gives ceil(6 * (2 + 7)) - 20 = 34 units.',
      status: pass ? 'PASS' : 'FAIL',
      details: `Calculated suggested order: ${suggested} (Expected: 34).`,
    });
  } catch (err: unknown) {
    results.push({
      id: 5,
      title: 'Suggested Order Formula',
      description: 'Suggested order quantity calculation',
      status: 'FAIL',
      details: String(err),
    });
  }

  // -------------------------------------------------------------
  // Check 6: POS row with barcode that matches product -> matched; unknown barcode/name -> unmatched, not dropped.
  // -------------------------------------------------------------
  try {
    const products: Product[] = [
      {
        id: 'p-milk',
        name_th: 'นมสดพาสเจอร์ไรส์ เมจิ 200มล.',
        name_en: 'Meiji Fresh Milk 200ml',
        barcode: '8850188002021',
        category: 'เครื่องดื่ม',
        supplier_id: 'sup-1',
        sell_price: 13.5,
        cost_price: 10.5,
        low_stock_level: 5,
        track_mode: 'fast',
        has_expiry: true,
        is_active: true,
        created_at: '2026-10-01T00:00:00Z',
      },
    ];

    const matchedRow = matchPosProduct('8850188002021', 'นมสด เมจิ', products);
    const unmatchedRow = matchPosProduct('9999999999999', 'สินค้าแปลกใหม่ไม่มีในระบบ', products);

    const pass =
      matchedRow.status === 'matched' &&
      matchedRow.matchedProduct?.id === 'p-milk' &&
      unmatchedRow.status === 'unmatched' &&
      unmatchedRow.matchedProduct === null;

    results.push({
      id: 6,
      title: 'POS Barcode / Name Matching',
      description: 'Known barcode matches product; unknown row marked unmatched (never dropped).',
      status: pass ? 'PASS' : 'FAIL',
      details: `Known barcode: ${matchedRow.status} (matched ${matchedRow.matchedProduct?.name_th}) | Unknown: ${unmatchedRow.status}.`,
    });
  } catch (err: unknown) {
    results.push({
      id: 6,
      title: 'POS Barcode / Name Matching',
      description: 'POS row matching',
      status: 'FAIL',
      details: String(err),
    });
  }

  // -------------------------------------------------------------
  // Check 7: Staff user querying cost_price -> rejected by RLS (hidden from staff).
  // -------------------------------------------------------------
  try {
    const fullProduct: Product = {
      id: 'p-chips',
      name_th: 'เลย์ รสมันฝรั่งแท้ 50ก.',
      name_en: "Lay's Classic 50g",
      barcode: '8850718800033',
      category: 'ขนมขบเคี้ยว',
      supplier_id: 'sup-2',
      sell_price: 20.0,
      cost_price: 15.5,
      low_stock_level: 8,
      track_mode: 'fast',
      has_expiry: true,
      is_active: true,
      created_at: '2026-10-01T00:00:00Z',
    };

    const staffView = filterStaffProduct(fullProduct, 'staff');
    const ownerView = filterStaffProduct(fullProduct, 'owner');

    const pass = staffView.cost_price === undefined && ownerView.cost_price === 15.5;

    results.push({
      id: 7,
      title: 'Staff Cost Price Security (RLS)',
      description: 'Staff users receive product without cost_price; owner sees cost_price.',
      status: pass ? 'PASS' : 'FAIL',
      details: `Staff cost_price: ${staffView.cost_price === undefined ? 'HIDDEN' : staffView.cost_price} | Owner cost_price: ${ownerView.cost_price}.`,
    });
  } catch (err: unknown) {
    results.push({
      id: 7,
      title: 'Staff Cost Price Security',
      description: 'Field-level cost protection',
      status: 'FAIL',
      details: String(err),
    });
  }

  // -------------------------------------------------------------
  // Check 8: Waste of 4 units at cost 12.50 -> waste value 50.00.
  // -------------------------------------------------------------
  try {
    const value = calculateWasteValue(4, 12.5);
    const pass = value === 50.0;

    results.push({
      id: 8,
      title: 'Waste Valuation',
      description: 'Waste of 4 units at cost 12.50 yields waste value of 50.00 baht.',
      status: pass ? 'PASS' : 'FAIL',
      details: `Calculated waste value: ${value.toFixed(2)} THB (Expected: 50.00 THB).`,
    });
  } catch (err: unknown) {
    results.push({
      id: 8,
      title: 'Waste Valuation',
      description: 'Waste value calculation',
      status: 'FAIL',
      details: String(err),
    });
  }

  // Log summary to console as required by implementation-plan M2
  console.log('=== runChecks() Execution Summary ===');
  results.forEach((r) => {
    console.log(`[${r.status}] Check #${r.id} ${r.title}: ${r.details}`);
  });

  return results;
}
