// Pure business rules for Convenience Store Stock Manager (prd.md Section 7)
// Pure functions with NO UI and NO direct database calls. Can be verified by runChecks().

import { Product, StockBatch, UserRole } from '../../types';

/**
 * Rule 1: on_hand of a product = sum of quantity in its active stock_batches
 */
export function calculateOnHand(batches: StockBatch[]): number {
  return batches
    .filter((b) => b.is_active && b.quantity > 0)
    .reduce((sum, b) => sum + b.quantity, 0);
}

export interface FIFODeductionResult {
  updatedBatches: StockBatch[];
  deductions: Array<{ batchId: string; quantityDeducted: number }>;
  negativeStockFlag: boolean;
  actualDeducted: number;
  unfulfilledQuantity: number;
}

/**
 * Rule 2 & 3:
 * A sale subtracts from the batch with the earliest expiry date first (FIFO).
 * Batches without an expiry date are used last.
 * Stock never goes below 0. If a sale would take it below 0, set to 0 and flag negative_stock_flag = true.
 */
export function deductFIFOBatches(
  batches: StockBatch[],
  quantityToDeduct: number
): FIFODeductionResult {
  if (quantityToDeduct <= 0) {
    return {
      updatedBatches: [...batches],
      deductions: [],
      negativeStockFlag: false,
      actualDeducted: 0,
      unfulfilledQuantity: 0,
    };
  }

  // Clone batches
  const workingBatches: StockBatch[] = batches.map((b) => ({ ...b }));

  // Sort batches:
  // Active batches with quantity > 0 first.
  // Earliest expiry date first. Batches with null expiry go last.
  // Stable sort by received_at if expiry is identical.
  const activeBatches = workingBatches.filter((b) => b.is_active && b.quantity > 0);

  activeBatches.sort((a, b) => {
    if (a.expiry_date && b.expiry_date) {
      return a.expiry_date.localeCompare(b.expiry_date);
    }
    if (a.expiry_date && !b.expiry_date) return -1;
    if (!a.expiry_date && b.expiry_date) return 1;
    return a.received_at.localeCompare(b.received_at);
  });

  let remainingToDeduct = quantityToDeduct;
  const deductions: Array<{ batchId: string; quantityDeducted: number }> = [];

  for (const batch of activeBatches) {
    if (remainingToDeduct <= 0) break;

    const deductAmount = Math.min(batch.quantity, remainingToDeduct);
    batch.quantity -= deductAmount;
    remainingToDeduct -= deductAmount;

    if (batch.quantity === 0) {
      batch.is_active = false;
    }

    deductions.push({
      batchId: batch.id,
      quantityDeducted: deductAmount,
    });
  }

  const negativeStockFlag = remainingToDeduct > 0;
  const actualDeducted = quantityToDeduct - remainingToDeduct;

  return {
    updatedBatches: workingBatches,
    deductions,
    negativeStockFlag,
    actualDeducted,
    unfulfilledQuantity: remainingToDeduct,
  };
}

/**
 * Rule 4: Low stock: on_hand <= low_stock_level of the product
 */
export function isLowStock(onHand: number, lowStockLevel: number): boolean {
  return onHand <= lowStockLevel;
}

export interface ExpiryEvaluation {
  isExpired: boolean;
  isExpiringSoon: boolean;
  isUrgent: boolean;
  daysRemaining: number | null;
}

/**
 * Rule 5 & 6:
 * Expiring soon: a batch with quantity > 0 and expiry_date <= today + expiry_warning_days (default 7)
 * Expired: expiry_date < today
 * Urgent: on_hand = 0 on a fast seller, or any batch expiring within 2 days
 */
export function evaluateExpiry(
  expiryDateStr: string | null,
  referenceDateStr: string, // YYYY-MM-DD
  warningDays: number = 7,
  urgentDays: number = 2
): ExpiryEvaluation {
  if (!expiryDateStr) {
    return {
      isExpired: false,
      isExpiringSoon: false,
      isUrgent: false,
      daysRemaining: null,
    };
  }

  const refDate = new Date(referenceDateStr + 'T00:00:00Z');
  const expDate = new Date(expiryDateStr + 'T00:00:00Z');

  const diffMs = expDate.getTime() - refDate.getTime();
  const daysRemaining = Math.round(diffMs / (1000 * 60 * 60 * 24));

  const isExpired = daysRemaining < 0;
  const isExpiringSoon = daysRemaining >= 0 && daysRemaining <= warningDays;
  const isUrgent = isExpired || (daysRemaining >= 0 && daysRemaining <= urgentDays);

  return {
    isExpired,
    isExpiringSoon,
    isUrgent,
    daysRemaining,
  };
}

/**
 * Rule 7: Suggested order quantity:
 * ceil(avg_daily_sales_last_14_days * (supplier.lead_time_days + 7)) - on_hand, never below 0.
 * Products with fewer than 14 days of data use: (low_stock_level * 2) - on_hand, never below 0.
 */
export function calculateSuggestedOrder(
  avgDailySales14d: number | null | undefined,
  leadTimeDays: number,
  onHand: number,
  lowStockLevel: number,
  has14DaysData: boolean = true
): number {
  if (has14DaysData && typeof avgDailySales14d === 'number') {
    const targetBuffer = Math.ceil(avgDailySales14d * (leadTimeDays + 7));
    return Math.max(0, targetBuffer - onHand);
  }
  // Fallback formula when insufficient historical data
  const fallbackTarget = lowStockLevel * 2;
  return Math.max(0, fallbackTarget - onHand);
}

/**
 * Rule 8: Waste value = quantity * cost_price at the time of the record
 */
export function calculateWasteValue(quantity: number, costPrice: number): number {
  const safeQty = Math.max(0, Math.floor(quantity));
  const safePrice = Math.max(0, costPrice);
  return Number((safeQty * safePrice).toFixed(2));
}

export interface PosMatchResult {
  status: 'matched' | 'unmatched';
  matchedProduct: Product | null;
  matchMethod?: 'barcode' | 'name_th';
}

/**
 * Rule 10: POS matching: match by barcode first, then exact name_th.
 * Unmatched rows are never silently dropped.
 */
export function matchPosProduct(
  rawBarcode: string | null | undefined,
  rawName: string,
  products: Product[]
): PosMatchResult {
  const cleanBarcode = rawBarcode?.trim();
  const cleanName = rawName.trim().toLowerCase();

  // 1. Try matching by barcode or product code first
  if (cleanBarcode) {
    const byBarcode = products.find(
      (p) =>
        p.is_active &&
        ((p.barcode && p.barcode.trim() === cleanBarcode) ||
          p.id === cleanBarcode ||
          p.id === `p-${cleanBarcode}`)
    );
    if (byBarcode) {
      return {
        status: 'matched',
        matchedProduct: byBarcode,
        matchMethod: 'barcode',
      };
    }
  }

  // 2. Try matching by exact Thai name
  const byName = products.find(
    (p) => p.is_active && p.name_th.trim().toLowerCase() === cleanName
  );
  if (byName) {
    return {
      status: 'matched',
      matchedProduct: byName,
      matchMethod: 'name_th',
    };
  }

  // 3. Normalized Thai name matching (ignore spaces and punctuation)
  const normCleanName = cleanName.replace(/\s+/g, '');
  const byNormName = products.find(
    (p) => p.is_active && p.name_th.replace(/\s+/g, '').toLowerCase() === normCleanName
  );
  if (byNormName) {
    return {
      status: 'matched',
      matchedProduct: byNormName,
      matchMethod: 'name_th',
    };
  }

  return {
    status: 'unmatched',
    matchedProduct: null,
  };
}

/**
 * RLS rule: Staff users must never receive cost_price, profit, or waste value.
 */
export function filterStaffProduct(product: Product, role: UserRole): Product {
  if (role === 'staff') {
    const safeProduct = { ...product };
    delete safeProduct.cost_price;
    return safeProduct;
  }
  return product;
}
