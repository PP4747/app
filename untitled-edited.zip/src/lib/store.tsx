// App state store with persistence and transactional database-function emulation
// Complies with schema.md and prd.md:
// - All mutations generate audit_logs
// - Stock changed ONLY via stock_movements + batch updates
// - RLS enforced: Staff never receives cost_price, profit, or waste value

import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  AuditLog,
  ExpiringBatchInfo,
  Order,
  PosImport,
  PosImportRow,
  Product,
  ProductWithStock,
  Settings,
  StockBatch,
  StockMovement,
  Supplier,
  User,
  UserRole,
  WasteReason,
} from '../types';
import {
  avgDailySales14dMap,
  initialAuditLogs,
  initialBatches,
  initialMovements,
  initialProducts,
  initialSettings,
  initialSuppliers,
  initialUsers,
} from './mockData';
import {
  calculateOnHand,
  calculateSuggestedOrder,
  calculateWasteValue,
  deductFIFOBatches,
  evaluateExpiry,
  filterStaffProduct,
  isLowStock,
  matchPosProduct,
} from './rules/stockRules';

interface StoreContextType {
  currentUser: User;
  users: User[];
  suppliers: Supplier[];
  products: Product[];
  batches: StockBatch[];
  movements: StockMovement[];
  auditLogs: AuditLog[];
  settings: Settings;
  posImports: PosImport[];
  posImportRows: PosImportRow[];
  orders: Order[];
  isOnline: boolean;

  // View models
  productsWithStock: ProductWithStock[];
  lowStockProducts: ProductWithStock[];
  expiringBatches: ExpiringBatchInfo[];
  expiredBatches: ExpiringBatchInfo[];
  urgentAlerts: {
    type: 'low_stock' | 'urgent_expiry' | 'expired';
    title: string;
    description: string;
    productId: string;
    batchId?: string;
  }[];

  // Role & Auth
  switchUserWithPin: (pin: string) => { success: boolean; message?: string };
  logout: () => void;
  setCurrentUserRoleDirectly: (role: UserRole) => void;

  // Transactional Actions
  receiveStock: (
    productId: string,
    quantity: number,
    expiryDate: string | null
  ) => { success: boolean; movementId: string; batchId: string };

  recordWaste: (
    productId: string,
    batchId: string | null,
    quantity: number,
    reason: WasteReason | string
  ) => { success: boolean; movementId: string; wasteValue?: number };

  recordManualSale: (
    productId: string,
    quantity: number
  ) => { success: boolean; movementId: string; negativeStockFlag: boolean };

  recordShelfCount: (
    productId: string,
    countedQty: number
  ) => { success: boolean; movementId: string; diff: number };

  applyPosImport: (
    filename: string,
    salesDate: string,
    rawRows: Array<{ raw_name: string; raw_barcode?: string; quantity: number }>
  ) => {
    success: boolean;
    importId: string;
    matchedCount: number;
    unmatchedCount: number;
  };

  resolveUnmatchedRow: (rowId: string, matchedProductId: string) => void;

  markOrderAsOrdered: (orderId: string) => void;

  addProduct: (
    productData: Omit<Product, 'id' | 'created_at'>,
    initialQty?: number,
    initialExpiry?: string | null
  ) => Product;

  updateSettings: (updates: Partial<Settings>) => void;
  resetToDemoData: () => void;
}

const StoreContext = createContext<StoreContextType | null>(null);

const STORAGE_KEY_PREFIX = 'stockmgr_store_v1_';

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Simulated reference date: 2026-10-12
  const TODAY_STR = '2026-10-12';

  // State initialization with localStorage fallback
  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'users');
    return saved ? JSON.parse(saved) : initialUsers;
  });

  const [currentUser, setCurrentUser] = useState<User>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'current_user');
    return saved ? JSON.parse(saved) : initialUsers[0]; // Default: Owner
  });

  const [suppliers, setSuppliers] = useState<Supplier[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'suppliers');
    return saved ? JSON.parse(saved) : initialSuppliers;
  });

  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'products');
    return saved ? JSON.parse(saved) : initialProducts;
  });

  const [batches, setBatches] = useState<StockBatch[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'batches');
    return saved ? JSON.parse(saved) : initialBatches;
  });

  const [movements, setMovements] = useState<StockMovement[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'movements');
    return saved ? JSON.parse(saved) : initialMovements;
  });

  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'audit_logs');
    return saved ? JSON.parse(saved) : initialAuditLogs;
  });

  const [settings, setSettings] = useState<Settings>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'settings');
    return saved ? JSON.parse(saved) : initialSettings;
  });

  const [posImports, setPosImports] = useState<PosImport[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'pos_imports');
    return saved ? JSON.parse(saved) : [];
  });

  const [posImportRows, setPosImportRows] = useState<PosImportRow[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'pos_import_rows');
    return saved ? JSON.parse(saved) : [];
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'orders');
    return saved ? JSON.parse(saved) : [];
  });

  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);

  useEffect(() => {
    const onOnline = () => setIsOnline(true);
    const onOffline = () => setIsOnline(false);
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);
    return () => {
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
  }, []);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'current_user', JSON.stringify(currentUser));
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'products', JSON.stringify(products));
    localStorage.setItem(STORAGE_KEY_PREFIX + 'batches', JSON.stringify(batches));
    localStorage.setItem(STORAGE_KEY_PREFIX + 'movements', JSON.stringify(movements));
    localStorage.setItem(STORAGE_KEY_PREFIX + 'audit_logs', JSON.stringify(auditLogs));
    localStorage.setItem(STORAGE_KEY_PREFIX + 'settings', JSON.stringify(settings));
    localStorage.setItem(STORAGE_KEY_PREFIX + 'pos_imports', JSON.stringify(posImports));
    localStorage.setItem(STORAGE_KEY_PREFIX + 'pos_import_rows', JSON.stringify(posImportRows));
    localStorage.setItem(STORAGE_KEY_PREFIX + 'orders', JSON.stringify(orders));
  }, [products, batches, movements, auditLogs, settings, posImports, posImportRows, orders]);

  // Helper to append audit log
  const logAudit = (
    action: string,
    tableName: string,
    recordId: string,
    oldVal: Record<string, unknown> | null,
    newVal: Record<string, unknown> | null
  ) => {
    const log: AuditLog = {
      id: 'log-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      user_id: currentUser.id,
      user_name: currentUser.name,
      action,
      table_name: tableName,
      record_id: recordId,
      old_value: oldVal,
      new_value: newVal,
      created_at: new Date().toISOString(),
    };
    setAuditLogs((prev) => [log, ...prev]);
  };

  // Auth / Role switching
  const switchUserWithPin = (pin: string) => {
    const matched = users.find((u) => u.pin === pin && u.is_active);
    if (matched) {
      setCurrentUser(matched);
      logAudit('login', 'users', matched.id, null, { role: matched.role, name: matched.name });
      return { success: true };
    }
    return { success: false, message: 'รหัส PIN ไม่ถูกต้อง' };
  };

  const logout = () => {
    logAudit('logout', 'users', currentUser.id, null, null);
    // Defaults back to staff or owner
    const defaultStaff = users.find((u) => u.role === 'staff') || users[0];
    setCurrentUser(defaultStaff);
  };

  const setCurrentUserRoleDirectly = (role: UserRole) => {
    const user = users.find((u) => u.role === role);
    if (user) {
      setCurrentUser(user);
      logAudit('role_switch', 'users', user.id, { from_role: currentUser.role }, { to_role: role });
    }
  };

  // -------------------------------------------------------------
  // Transactional Actions (Match schema.md database functions)
  // -------------------------------------------------------------

  // 1. receive_stock
  const receiveStock = (
    productId: string,
    quantity: number,
    expiryDate: string | null
  ) => {
    const product = products.find((p) => p.id === productId);
    if (!product || quantity <= 0) return { success: false, movementId: '', batchId: '' };

    const now = new Date().toISOString();
    const batchId = 'b-' + Date.now() + '-' + Math.random().toString(36).substring(2, 5);

    const newBatch: StockBatch = {
      id: batchId,
      product_id: productId,
      quantity,
      expiry_date: expiryDate,
      received_at: now,
      is_active: true,
      created_at: now,
    };

    const movementId = 'mov-' + Date.now();
    const newMovement: StockMovement = {
      id: movementId,
      product_id: productId,
      batch_id: batchId,
      type: 'receive',
      quantity,
      source: 'manual',
      import_id: null,
      reason: null,
      cost_at_time: product.cost_price ?? null,
      negative_stock_flag: false,
      created_by: currentUser.id,
      created_by_name: currentUser.name,
      created_at: now,
    };

    setBatches((prev) => [...prev, newBatch]);
    setMovements((prev) => [newMovement, ...prev]);

    logAudit('receive_stock', 'stock_batches', batchId, null, {
      product_name: product.name_th,
      quantity,
      expiry_date: expiryDate,
      movement_id: movementId,
    });

    return { success: true, movementId, batchId };
  };

  // 2. record_waste
  const recordWaste = (
    productId: string,
    batchId: string | null,
    quantity: number,
    reason: WasteReason | string
  ) => {
    const product = products.find((p) => p.id === productId);
    if (!product || quantity <= 0) return { success: false, movementId: '' };

    const productBatches = batches.filter((b) => b.product_id === productId && b.is_active);
    let updatedBatches = [...batches];
    const targetBatch = batchId ? batches.find((b) => b.id === batchId) : null;

    if (targetBatch) {
      // Deduct from specific batch
      const deductAmt = Math.min(targetBatch.quantity, quantity);
      updatedBatches = updatedBatches.map((b) => {
        if (b.id === targetBatch.id) {
          const newQty = b.quantity - deductAmt;
          return { ...b, quantity: newQty, is_active: newQty > 0 };
        }
        return b;
      });
    } else {
      // Deduct FIFO
      const fifoRes = deductFIFOBatches(productBatches, quantity);
      const updatedMap = new Map(fifoRes.updatedBatches.map((b) => [b.id, b]));
      updatedBatches = updatedBatches.map((b) => updatedMap.get(b.id) || b);
    }

    const now = new Date().toISOString();
    const movementId = 'mov-' + Date.now();
    const costAtTime = product.cost_price ?? 0;
    const wasteValue = calculateWasteValue(quantity, costAtTime);

    const newMovement: StockMovement = {
      id: movementId,
      product_id: productId,
      batch_id: batchId,
      type: 'waste',
      quantity: -quantity,
      source: 'manual',
      import_id: null,
      reason,
      cost_at_time: costAtTime,
      negative_stock_flag: false,
      created_by: currentUser.id,
      created_by_name: currentUser.name,
      created_at: now,
    };

    setBatches(updatedBatches);
    setMovements((prev) => [newMovement, ...prev]);

    logAudit('record_waste', 'stock_movements', movementId, null, {
      product_name: product.name_th,
      quantity,
      reason,
      waste_value: currentUser.role === 'owner' ? wasteValue : undefined,
    });

    return { success: true, movementId, wasteValue };
  };

  // 3. record_manual_sale (FIFO deduction)
  const recordManualSale = (productId: string, quantity: number) => {
    const product = products.find((p) => p.id === productId);
    if (!product || quantity <= 0) return { success: false, movementId: '', negativeStockFlag: false };

    const productBatches = batches.filter((b) => b.product_id === productId);
    const fifoResult = deductFIFOBatches(productBatches, quantity);

    const updatedMap = new Map(fifoResult.updatedBatches.map((b) => [b.id, b]));
    const newAllBatches = batches.map((b) => updatedMap.get(b.id) || b);

    const now = new Date().toISOString();
    const movementId = 'mov-' + Date.now();
    const newMovement: StockMovement = {
      id: movementId,
      product_id: productId,
      batch_id: fifoResult.deductions[0]?.batchId ?? null,
      type: 'sale',
      quantity: -fifoResult.actualDeducted,
      source: 'manual',
      import_id: null,
      reason: null,
      cost_at_time: product.cost_price ?? null,
      negative_stock_flag: fifoResult.negativeStockFlag,
      created_by: currentUser.id,
      created_by_name: currentUser.name,
      created_at: now,
    };

    setBatches(newAllBatches);
    setMovements((prev) => [newMovement, ...prev]);

    logAudit('record_manual_sale', 'stock_movements', movementId, null, {
      product_name: product.name_th,
      quantity,
      actual_deducted: fifoResult.actualDeducted,
      negative_stock_flag: fifoResult.negativeStockFlag,
    });

    return {
      success: true,
      movementId,
      negativeStockFlag: fifoResult.negativeStockFlag,
    };
  };

  // 4. record_count (Shelf count)
  const recordShelfCount = (productId: string, countedQty: number) => {
    const product = products.find((p) => p.id === productId);
    if (!product) return { success: false, movementId: '', diff: 0 };

    const productBatches = batches.filter((b) => b.product_id === productId && b.is_active);
    const currentOnHand = calculateOnHand(productBatches);
    const diff = countedQty - currentOnHand;

    if (diff === 0) return { success: true, movementId: '', diff: 0 };

    let updatedBatches = [...batches];
    let movementBatchId: string | null = null;
    const now = new Date().toISOString();

    if (diff > 0) {
      // Stock added via count
      const newBatchId = 'b-count-' + Date.now();
      movementBatchId = newBatchId;
      const newBatch: StockBatch = {
        id: newBatchId,
        product_id: productId,
        quantity: diff,
        expiry_date: null,
        received_at: now,
        is_active: true,
        created_at: now,
      };
      updatedBatches.push(newBatch);
    } else {
      // Stock removed via count (FIFO)
      const fifoRes = deductFIFOBatches(productBatches, Math.abs(diff));
      movementBatchId = fifoRes.deductions[0]?.batchId ?? null;
      const map = new Map(fifoRes.updatedBatches.map((b) => [b.id, b]));
      updatedBatches = updatedBatches.map((b) => map.get(b.id) || b);
    }

    const movementId = 'mov-' + Date.now();
    const newMovement: StockMovement = {
      id: movementId,
      product_id: productId,
      batch_id: movementBatchId,
      type: 'count_adjust',
      quantity: diff,
      source: 'count',
      import_id: null,
      reason: `นับสต็อกจริงได้ ${countedQty} ชิ้น (จากระบบ ${currentOnHand} ชิ้น)`,
      cost_at_time: product.cost_price ?? null,
      negative_stock_flag: false,
      created_by: currentUser.id,
      created_by_name: currentUser.name,
      created_at: now,
    };

    setBatches(updatedBatches);
    setMovements((prev) => [newMovement, ...prev]);

    logAudit('record_shelf_count', 'stock_movements', movementId, { on_hand_before: currentOnHand }, {
      counted_qty: countedQty,
      diff,
      product_name: product.name_th,
    });

    return { success: true, movementId, diff };
  };

  // 5. apply_pos_import
  const applyPosImport = (
    filename: string,
    salesDate: string,
    rawRows: Array<{ raw_name: string; raw_barcode?: string; quantity: number }>
  ) => {
    const importId = 'imp-' + Date.now();
    let matchedCount = 0;
    let unmatchedCount = 0;
    const newImportRows: PosImportRow[] = [];
    let currentWorkingBatches = [...batches];
    const newMovements: StockMovement[] = [];
    const now = new Date().toISOString();

    for (const r of rawRows) {
      const match = matchPosProduct(r.raw_barcode, r.raw_name, products);
      const rowId = 'row-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6);

      if (match.status === 'matched' && match.matchedProduct) {
        matchedCount++;
        newImportRows.push({
          id: rowId,
          import_id: importId,
          raw_name: r.raw_name,
          raw_barcode: r.raw_barcode ?? null,
          quantity: r.quantity,
          product_id: match.matchedProduct.id,
          status: 'matched',
        });

        // Deduct FIFO
        const pBatches = currentWorkingBatches.filter(
          (b) => b.product_id === match.matchedProduct!.id
        );
        const fifo = deductFIFOBatches(pBatches, r.quantity);

        const map = new Map(fifo.updatedBatches.map((b) => [b.id, b]));
        currentWorkingBatches = currentWorkingBatches.map((b) => map.get(b.id) || b);

        newMovements.push({
          id: 'mov-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
          product_id: match.matchedProduct.id,
          batch_id: fifo.deductions[0]?.batchId ?? null,
          type: 'sale',
          quantity: -fifo.actualDeducted,
          source: 'pos_import',
          import_id: importId,
          reason: `POS sale: ${filename}`,
          cost_at_time: match.matchedProduct.cost_price ?? null,
          negative_stock_flag: fifo.negativeStockFlag,
          created_by: currentUser.id,
          created_by_name: currentUser.name,
          created_at: now,
        });
      } else {
        unmatchedCount++;
        newImportRows.push({
          id: rowId,
          import_id: importId,
          raw_name: r.raw_name,
          raw_barcode: r.raw_barcode ?? null,
          quantity: r.quantity,
          product_id: null,
          status: 'unmatched',
        });
      }
    }

    const posImportRecord: PosImport = {
      id: importId,
      filename,
      sales_date: salesDate,
      row_count: rawRows.length,
      matched_count: matchedCount,
      unmatched_count: unmatchedCount,
      status: unmatchedCount === 0 ? 'applied' : 'partial',
      uploaded_by: currentUser.id,
      created_at: now,
    };

    setBatches(currentWorkingBatches);
    setMovements((prev) => [...newMovements, ...prev]);
    setPosImports((prev) => [posImportRecord, ...prev]);
    setPosImportRows((prev) => [...newImportRows, ...prev]);

    logAudit('apply_pos_import', 'pos_imports', importId, null, {
      filename,
      sales_date: salesDate,
      total_rows: rawRows.length,
      matched: matchedCount,
      unmatched: unmatchedCount,
    });

    return {
      success: true,
      importId,
      matchedCount,
      unmatchedCount,
    };
  };

  // 6. resolve_unmatched_row
  const resolveUnmatchedRow = (rowId: string, matchedProductId: string) => {
    const row = posImportRows.find((r) => r.id === rowId);
    const prod = products.find((p) => p.id === matchedProductId);
    if (!row || !prod) return;

    // Deduct FIFO now
    const pBatches = batches.filter((b) => b.product_id === matchedProductId);
    const fifo = deductFIFOBatches(pBatches, row.quantity);
    const map = new Map(fifo.updatedBatches.map((b) => [b.id, b]));
    const updatedAllBatches = batches.map((b) => map.get(b.id) || b);

    const now = new Date().toISOString();
    const movementId = 'mov-resolved-' + Date.now();
    const newMovement: StockMovement = {
      id: movementId,
      product_id: matchedProductId,
      batch_id: fifo.deductions[0]?.batchId ?? null,
      type: 'sale',
      quantity: -fifo.actualDeducted,
      source: 'pos_import',
      import_id: row.import_id,
      reason: `Resolved POS row: ${row.raw_name}`,
      cost_at_time: prod.cost_price ?? null,
      negative_stock_flag: fifo.negativeStockFlag,
      created_by: currentUser.id,
      created_by_name: currentUser.name,
      created_at: now,
    };

    setBatches(updatedAllBatches);
    setMovements((prev) => [newMovement, ...prev]);
    setPosImportRows((prev) =>
      prev.map((r) =>
        r.id === rowId ? { ...r, status: 'resolved', product_id: matchedProductId } : r
      )
    );

    logAudit('resolve_pos_row', 'pos_import_rows', rowId, { raw_name: row.raw_name }, {
      linked_product: prod.name_th,
      quantity_deducted: fifo.actualDeducted,
    });
  };

  // 7. mark_order_as_ordered
  const markOrderAsOrdered = (orderId: string) => {
    const now = new Date().toISOString();
    setOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, status: 'ordered', ordered_at: now } : o))
    );
    logAudit('mark_ordered', 'orders', orderId, null, { ordered_at: now });
  };

  // 8. add_product
  const addProduct = (
    productData: Omit<Product, 'id' | 'created_at'>,
    initialQty?: number,
    initialExpiry?: string | null
  ) => {
    const now = new Date().toISOString();
    const newId = 'p-' + Date.now();
    const newProduct: Product = {
      ...productData,
      id: newId,
      created_at: now,
    };

    setProducts((prev) => [...prev, newProduct]);

    if (initialQty && initialQty > 0) {
      const batchId = 'b-' + Date.now();
      const newBatch: StockBatch = {
        id: batchId,
        product_id: newId,
        quantity: initialQty,
        expiry_date: initialExpiry ?? null,
        received_at: now,
        is_active: true,
        created_at: now,
      };
      setBatches((prev) => [...prev, newBatch]);

      const movementId = 'mov-' + Date.now();
      const movement: StockMovement = {
        id: movementId,
        product_id: newId,
        batch_id: batchId,
        type: 'receive',
        quantity: initialQty,
        source: 'manual',
        import_id: null,
        reason: 'Initial stock on product creation',
        cost_at_time: newProduct.cost_price ?? null,
        negative_stock_flag: false,
        created_by: currentUser.id,
        created_by_name: currentUser.name,
        created_at: now,
      };
      setMovements((prev) => [movement, ...prev]);
    }

    logAudit('create_product', 'products', newId, null, {
      name_th: newProduct.name_th,
      barcode: newProduct.barcode,
      initial_qty: initialQty,
    });

    return newProduct;
  };

  const updateSettings = (updates: Partial<Settings>) => {
    setSettings((prev) => {
      const updated = { ...prev, ...updates };
      logAudit(
        'update_settings',
        'settings',
        '1',
        prev as unknown as Record<string, unknown>,
        updated as unknown as Record<string, unknown>
      );
      return updated;
    });
  };

  const resetToDemoData = () => {
    setProducts(initialProducts);
    setBatches(initialBatches);
    setMovements(initialMovements);
    setAuditLogs(initialAuditLogs);
    setSettings(initialSettings);
    setPosImports([]);
    setPosImportRows([]);
    setOrders([]);
    logAudit('reset_demo_data', 'system', '1', null, { status: 'reset_complete' });
  };

  // -------------------------------------------------------------
  // Derived Views (v_stock_on_hand, v_low_stock, v_expiring_batches, v_suggested_order)
  // -------------------------------------------------------------
  const productsWithStock: ProductWithStock[] = products
    .filter((p) => p.is_active)
    .map((p) => {
      const pBatches = batches.filter((b) => b.product_id === p.id && b.is_active);
      const onHand = calculateOnHand(pBatches);
      const lowStock = isLowStock(onHand, p.low_stock_level);
      const supplier = suppliers.find((s) => s.id === p.supplier_id);
      const avgSales = avgDailySales14dMap[p.id] ?? 3;
      const suggestedOrder = calculateSuggestedOrder(
        avgSales,
        supplier?.lead_time_days ?? 2,
        onHand,
        p.low_stock_level,
        true
      );

      // Check expiring batches count
      let expCount = 0;
      let hasUrgent = false;
      for (const b of pBatches) {
        const evalRes = evaluateExpiry(
          b.expiry_date,
          TODAY_STR,
          settings.expiry_warning_days,
          settings.urgent_expiry_days
        );
        if (evalRes.isExpiringSoon || evalRes.isExpired) {
          expCount++;
        }
        if (evalRes.isUrgent) {
          hasUrgent = true;
        }
      }

      const filteredProduct = filterStaffProduct(p, currentUser.role);

      return {
        ...filteredProduct,
        on_hand: onHand,
        batches: pBatches,
        supplier,
        avg_daily_sales_14d: avgSales,
        suggested_order_qty: suggestedOrder,
        is_low_stock: lowStock,
        expiring_batches_count: expCount,
        has_urgent_expiry: hasUrgent,
      };
    });

  const lowStockProducts = productsWithStock.filter((p) => p.is_low_stock);

  // Expiring & Expired Batches
  const expiringBatches: ExpiringBatchInfo[] = [];
  const expiredBatches: ExpiringBatchInfo[] = [];

  batches
    .filter((b) => b.is_active && b.quantity > 0 && b.expiry_date)
    .forEach((b) => {
      const product = products.find((p) => p.id === b.product_id);
      if (!product || !product.is_active) return;

      const evalRes = evaluateExpiry(
        b.expiry_date,
        TODAY_STR,
        settings.expiry_warning_days,
        settings.urgent_expiry_days
      );

      const info: ExpiringBatchInfo = {
        batch: b,
        product: filterStaffProduct(product, currentUser.role),
        days_until_expiry: evalRes.daysRemaining ?? 0,
        is_expired: evalRes.isExpired,
        is_urgent: evalRes.isUrgent,
      };

      if (evalRes.isExpired) {
        expiredBatches.push(info);
      } else if (evalRes.isExpiringSoon) {
        expiringBatches.push(info);
      }
    });

  // Urgent alerts list
  const urgentAlerts: Array<{
    type: 'low_stock' | 'urgent_expiry' | 'expired';
    title: string;
    description: string;
    productId: string;
    batchId?: string;
  }> = [];

  // 1. Expired batches
  expiredBatches.forEach((exp) => {
    urgentAlerts.push({
      type: 'expired',
      title: `หมดอายุแล้ว: ${exp.product.name_th}`,
      description: `ล็อต ${exp.batch.id.slice(-6)} จำนวน ${exp.batch.quantity} ชิ้น (หมดอายุ ${exp.batch.expiry_date})`,
      productId: exp.product.id,
      batchId: exp.batch.id,
    });
  });

  // 2. Urgent expiring within 2 days
  expiringBatches
    .filter((exp) => exp.is_urgent)
    .forEach((exp) => {
      urgentAlerts.push({
        type: 'urgent_expiry',
        title: `หมดอายุในอีก ${exp.days_until_expiry} วัน: ${exp.product.name_th}`,
        description: `ล็อต ${exp.batch.id.slice(-6)} จำนวน ${exp.batch.quantity} ชิ้น (หมดอายุ ${exp.batch.expiry_date})`,
        productId: exp.product.id,
        batchId: exp.batch.id,
      });
    });

  // 3. Fast sellers with 0 on hand
  lowStockProducts
    .filter((p) => p.track_mode === 'fast' && p.on_hand === 0)
    .forEach((p) => {
      urgentAlerts.push({
        type: 'low_stock',
        title: `สินค้าขายดีหมดสต็อก (0 ชิ้น): ${p.name_th}`,
        description: `ควรสั่งซื้อทันที แนะนำ ${p.suggested_order_qty} ชิ้น`,
        productId: p.id,
      });
    });

  return (
    <StoreContext.Provider
      value={{
        currentUser,
        users,
        suppliers,
        products,
        batches,
        movements,
        auditLogs,
        settings,
        posImports,
        posImportRows,
        orders,
        isOnline,
        productsWithStock,
        lowStockProducts,
        expiringBatches,
        expiredBatches,
        urgentAlerts,
        switchUserWithPin,
        logout,
        setCurrentUserRoleDirectly,
        receiveStock,
        recordWaste,
        recordManualSale,
        recordShelfCount,
        applyPosImport,
        resolveUnmatchedRow,
        markOrderAsOrdered,
        addProduct,
        updateSettings,
        resetToDemoData,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export function useStore(): StoreContextType {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
}
