import React, { useState } from 'react';
import { History, Search, ShieldCheck } from 'lucide-react';
import { useStore } from '../../lib/store';

export const AuditLogsView: React.FC = () => {
  const { auditLogs } = useStore();
  const [filter, setFilter] = useState('');

  const filteredLogs = auditLogs.filter(
    (log) =>
      log.action.toLowerCase().includes(filter.toLowerCase()) ||
      log.table_name.toLowerCase().includes(filter.toLowerCase()) ||
      (log.user_name && log.user_name.toLowerCase().includes(filter.toLowerCase()))
  );

  return (
    <div className="space-y-4 pb-20">
      <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-2xs">
        <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
          <div className="w-10 h-10 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center shrink-0">
            <History className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">
              ประวัติการบันทึกข้อมูล (Audit Logs)
            </h2>
            <p className="text-xs text-slate-400">
              บันทึกทุกการกระทำ ทุกการรับเข้า ตัดทิ้ง และยอดขาย (ไม่สามารถลบหรือแก้ไขได้)
            </p>
          </div>
        </div>

        {/* Search filter */}
        <div className="mt-3 relative">
          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
          <input
            type="text"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            placeholder="ค้นหาตามการกระทำ หรือชื่อผู้ใช้..."
            className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-teal-500 outline-none"
          />
        </div>

        {/* Logs list */}
        <div className="mt-4 space-y-2.5">
          {filteredLogs.map((log) => (
            <div
              key={log.id}
              className="p-3 bg-slate-50/70 border border-slate-200 rounded-2xl text-xs space-y-1.5"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-900 px-2 py-0.5 rounded-md bg-white border border-slate-200 text-[10px] uppercase font-mono">
                    {log.action}
                  </span>
                  <span className="text-[11px] text-slate-500">
                    ตาราง: <code>{log.table_name}</code>
                  </span>
                </div>
                <span className="text-[10px] text-slate-400">
                  {new Date(log.created_at).toLocaleString('th-TH', {
                    dateStyle: 'short',
                    timeStyle: 'short',
                  })}
                </span>
              </div>

              <div className="flex items-center justify-between text-[11px]">
                <span className="text-teal-800 font-medium">
                  ผู้ดำเนินการ: {log.user_name || log.user_id}
                </span>
                <span className="text-slate-400 font-mono text-[10px]">
                  ID: {log.record_id.slice(-8)}
                </span>
              </div>

              {log.new_value && (
                <div className="p-2 bg-white rounded-xl border border-slate-100 text-[11px] text-slate-600 font-mono overflow-x-auto">
                  {JSON.stringify(log.new_value, null, 1)}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
