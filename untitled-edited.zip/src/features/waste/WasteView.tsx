import React, { useState } from 'react';
import {
  AlertTriangle,
  Barcode,
  CheckCircle2,
  Trash2,
} from 'lucide-react';
import { useStore } from '../../lib/store';
import { WasteReason } from '../../types';

interface WasteViewProps {
  initialProductId?: string;
  onOpenScan: () => void;
  onDone: () => void;
}

export const WasteView: React.FC<WasteViewProps> = ({
  initialProductId,
  onOpenScan,
  onDone,
}) => {
  const { products, batches, recordWaste, currentUser } = useStore();
  const [selectedProductId, setSelectedProductId] = useState<string>(
    initialProductId || (products[0]?.id ?? '')
  );
  const [selectedBatchId, setSelectedBatchId] = useState<string>('');
  const [quantity, setQuantity] = useState<string>('2');
  const [reason, setReason] = useState<WasteReason>('expired');
  const [otherReason, setOtherReason] = useState<string>('');
  const [successInfo, setSuccessInfo] = useState<{
    productName: string;
    qty: number;
    wasteValue?: number;
  } | null>(null);

  const selectedProduct = products.find((p) => p.id === selectedProductId);
  const productBatches = batches.filter(
    (b) => b.product_id === selectedProductId && b.is_active && b.quantity > 0
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const qtyNum = parseInt(quantity, 10);
    if (!selectedProductId || isNaN(qtyNum) || qtyNum <= 0) return;

    const finalReason = reason === 'other' ? (otherReason || 'อื่นๆ') : reason;
    const batchTarget = selectedBatchId ? selectedBatchId : null;

    const res = recordWaste(selectedProductId, batchTarget, qtyNum, finalReason);

    if (res.success && selectedProduct) {
      setSuccessInfo({
        productName: selectedProduct.name_th,
        qty: qtyNum,
        wasteValue: res.wasteValue,
      });
      setQuantity('1');
    }
  };

  return (
    <div className="space-y-4 pb-20">
      <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-2xs">
        <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
          <div className="w-10 h-10 rounded-2xl bg-rose-50 text-rose-700 flex items-center justify-center shrink-0">
            <Trash2 className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">บันทึกของเสีย / สินค้าเสียหาย</h2>
            <p className="text-xs text-slate-400">
              ผู้บันทึก: {currentUser.name} ({currentUser.role === 'owner' ? 'เจ้าของร้าน' : 'พนักงาน'})
            </p>
          </div>
        </div>

        {successInfo ? (
          <div className="my-6 p-5 bg-rose-50 border border-rose-200 rounded-2xl text-center space-y-3 animate-in zoom-in-95">
            <CheckCircle2 className="w-12 h-12 text-rose-600 mx-auto" />
            <div>
              <h3 className="text-sm font-bold text-rose-900">
                บันทึกตัดของเสียเรียบร้อยแล้ว
              </h3>
              <p className="text-xs text-rose-700 mt-1">
                {successInfo.productName} จำนวน <strong>-{successInfo.qty} ชิ้น</strong>
              </p>
              {currentUser.role === 'owner' && successInfo.wasteValue !== undefined && (
                <p className="text-xs text-rose-800 font-semibold mt-1">
                  มูลค่าความเสียหาย: ฿{successInfo.wasteValue.toFixed(2)}
                </p>
              )}
            </div>
            <div className="flex gap-2 justify-center pt-2">
              <button
                type="button"
                onClick={() => setSuccessInfo(null)}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold rounded-xl transition"
              >
                บันทึกรายการต่อไป
              </button>
              <button
                type="button"
                onClick={onDone}
                className="px-4 py-2 bg-white border border-slate-200 text-slate-700 text-xs font-semibold rounded-xl hover:bg-slate-50 transition"
              >
                กลับหน้าหลัก
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 mt-4 text-xs">
            {/* Product selection */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="font-semibold text-slate-700">เลือกสินค้า *</label>
                <button
                  type="button"
                  onClick={onOpenScan}
                  className="flex items-center gap-1 text-[11px] font-semibold text-teal-700 hover:underline"
                >
                  <Barcode className="w-3.5 h-3.5" />
                  สแกนบาร์โค้ด
                </button>
              </div>
              <select
                value={selectedProductId}
                onChange={(e) => {
                  setSelectedProductId(e.target.value);
                  setSelectedBatchId('');
                }}
                className="w-full p-3 border border-slate-200 rounded-2xl bg-white text-xs font-medium focus:ring-2 focus:ring-rose-500 outline-none"
              >
                {products.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name_th} {p.barcode ? `(${p.barcode})` : ''}
                  </option>
                ))}
              </select>
            </div>

            {/* Batch selector (Optional, or auto FIFO) */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                เลือกล็อตที่ต้องการตัด (หรือให้ระบบตัดแบบ FIFO อัตโนมัติ)
              </label>
              <select
                value={selectedBatchId}
                onChange={(e) => setSelectedBatchId(e.target.value)}
                className="w-full p-3 border border-slate-200 rounded-2xl bg-white text-xs focus:ring-2 focus:ring-rose-500 outline-none"
              >
                <option value="">-- ตัดแบบ FIFO (ล็อตที่หมดอายุก่อนอัตโนมัติ) --</option>
                {productBatches.map((b) => (
                  <option key={b.id} value={b.id}>
                    ล็อต {b.id.slice(-6)}: เหลือ {b.quantity} ชิ้น{' '}
                    {b.expiry_date ? `(หมดอายุ ${b.expiry_date})` : ''}
                  </option>
                ))}
              </select>
            </div>

            {/* Quantity */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                จำนวนที่ต้องการตัดทิ้ง (ชิ้น) *
              </label>
              <input
                type="number"
                min="1"
                required
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                className="w-full p-3 border border-slate-200 rounded-2xl text-base font-bold focus:ring-2 focus:ring-rose-500 outline-none"
              />
            </div>

            {/* Waste Reason */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                สาเหตุของเสีย (Reason) *
              </label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'expired', label: 'สินค้าหมดอายุ' },
                  { id: 'damaged', label: 'ชำรุด / แตกหัก / ซองฉีก' },
                  { id: 'lost', label: 'สูญหาย / นับไม่พบ' },
                  { id: 'other', label: 'อื่นๆ' },
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setReason(item.id as WasteReason)}
                    className={`p-3 rounded-2xl border text-left font-medium transition active:scale-95 ${
                      reason === item.id
                        ? 'border-rose-500 bg-rose-50 text-rose-800 font-bold'
                        : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>

              {reason === 'other' && (
                <input
                  type="text"
                  placeholder="ระบุสาเหตุเพิ่มเติม..."
                  value={otherReason}
                  onChange={(e) => setOtherReason(e.target.value)}
                  className="w-full p-3 mt-2 border border-slate-200 rounded-xl"
                />
              )}
            </div>

            {/* Owner Cost preview */}
            {currentUser.role === 'owner' && selectedProduct && selectedProduct.cost_price !== undefined && (
              <div className="p-3 bg-rose-50/70 border border-rose-100 rounded-2xl text-xs text-rose-800 flex items-center justify-between">
                <span>มูลค่าความเสียหายโดยประมาณ:</span>
                <span className="font-bold text-sm">
                  ฿{((parseInt(quantity, 10) || 0) * selectedProduct.cost_price).toFixed(2)}
                </span>
              </div>
            )}

            <button
              type="submit"
              className="w-full py-3.5 bg-rose-600 hover:bg-rose-700 active:scale-95 text-white font-bold rounded-2xl shadow-sm transition flex items-center justify-center gap-2 text-sm mt-4"
            >
              <Trash2 className="w-5 h-5" />
              ยืนยันตัดของเสียออกจากสต็อก
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
