import React from 'react';
import {
  AlertCircle,
  Barcode,
  PackageSearch,
  Receipt,
  RotateCcw,
  Trash2,
  Truck,
} from 'lucide-react';
import { useStore } from '../../lib/store';

interface StaffHomeProps {
  onNavigate: (tab: string) => void;
  onOpenReceive: () => void;
  onOpenWaste: () => void;
  onOpenScan: () => void;
}

export const StaffHome: React.FC<StaffHomeProps> = ({
  onNavigate,
  onOpenReceive,
  onOpenWaste,
  onOpenScan,
}) => {
  const { currentUser, productsWithStock, expiringBatches } = useStore();

  const fastSellers = productsWithStock
    .filter((p) => p.track_mode === 'fast')
    .slice(0, 4);

  return (
    <div className="space-y-4 pb-20">
      {/* Staff Greeting & Shift Role Banner */}
      <div className="bg-gradient-to-r from-sky-600 to-teal-700 text-white rounded-3xl p-5 shadow-sm">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs uppercase tracking-wider font-semibold text-sky-200">
            พนักงานหน้าร้าน (Store Staff)
          </span>
          <span className="px-2.5 py-0.5 rounded-full bg-white/20 text-xs font-medium">
            PIN: 5678
          </span>
        </div>
        <h2 className="text-xl font-bold">สวัสดีคุณ {currentUser.name}</h2>
        <p className="text-xs text-sky-100 mt-1">
          ระบบบันทึกรับของเข้า ตัดของเสีย และเช็คสต็อกสินค้าประจำวัน
        </p>
      </div>

      {/* Main Staff Action Buttons - Giant Touch Targets (> 56px) */}
      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={onOpenReceive}
          className="p-5 bg-white border border-slate-200 rounded-3xl shadow-2xs hover:border-teal-500 hover:shadow-md transition active:scale-95 flex flex-col items-center text-center group"
        >
          <div className="w-14 h-14 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center mb-3 group-hover:bg-teal-600 group-hover:text-white transition">
            <Truck className="w-7 h-7" />
          </div>
          <span className="text-sm font-bold text-slate-800">รับสินค้าเข้า</span>
          <span className="text-[11px] text-slate-400 mt-0.5">
            บันทึกของส่งมา + วันหมดอายุ
          </span>
        </button>

        <button
          onClick={onOpenWaste}
          className="p-5 bg-white border border-slate-200 rounded-3xl shadow-2xs hover:border-rose-500 hover:shadow-md transition active:scale-95 flex flex-col items-center text-center group"
        >
          <div className="w-14 h-14 rounded-2xl bg-rose-50 text-rose-700 flex items-center justify-center mb-3 group-hover:bg-rose-600 group-hover:text-white transition">
            <Trash2 className="w-7 h-7" />
          </div>
          <span className="text-sm font-bold text-slate-800">บันทึกของเสีย</span>
          <span className="text-[11px] text-slate-400 mt-0.5">
            ของหมดอายุ / แตกหัก
          </span>
        </button>

        <button
          onClick={() => onNavigate('products')}
          className="p-4 bg-white border border-slate-200 rounded-2xl shadow-2xs hover:border-sky-500 transition active:scale-95 flex items-center gap-3 text-left"
        >
          <div className="w-10 h-10 rounded-xl bg-sky-50 text-sky-700 flex items-center justify-center shrink-0">
            <PackageSearch className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs font-bold text-slate-800 block">ค้นหาสต็อก</span>
            <span className="text-[10px] text-slate-400">เช็คจำนวนคงเหลือ</span>
          </div>
        </button>

        <button
          onClick={onOpenScan}
          className="p-4 bg-white border border-slate-200 rounded-2xl shadow-2xs hover:border-amber-500 transition active:scale-95 flex items-center gap-3 text-left"
        >
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center shrink-0">
            <Barcode className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs font-bold text-slate-800 block">สแกนบาร์โค้ด</span>
            <span className="text-[10px] text-slate-400">สแกนค้นหาทันที</span>
          </div>
        </button>

        <button
          onClick={() => onNavigate('manual_sale')}
          className="p-4 bg-white border border-slate-200 rounded-2xl shadow-2xs hover:border-emerald-500 transition active:scale-95 flex items-center gap-3 text-left"
        >
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
            <Receipt className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs font-bold text-slate-800 block">บันทึกขาย</span>
            <span className="text-[10px] text-slate-400">ตัดสต็อก FIFO</span>
          </div>
        </button>

        <button
          onClick={() => onNavigate('shelf_count')}
          className="p-4 bg-white border border-slate-200 rounded-2xl shadow-2xs hover:border-indigo-500 transition active:scale-95 flex items-center gap-3 text-left"
        >
          <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center shrink-0">
            <RotateCcw className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs font-bold text-slate-800 block">นับสต็อกจริง</span>
            <span className="text-[10px] text-slate-400">นับยอดบนชั้นวาง</span>
          </div>
        </button>
      </div>

      {/* Expiry Attention Notice */}
      {expiringBatches.length > 0 && (
        <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200">
          <div className="flex items-center gap-2 text-amber-800 font-bold text-xs mb-1.5">
            <AlertCircle className="w-4 h-4 text-amber-600" />
            <span>สินค้าต้องตรวจสอบวันหมดอายุบนชั้นวาง</span>
          </div>
          <p className="text-xs text-amber-700 mb-2">
            พบ {expiringBatches.length} ล็อตที่ใกล้หมดอายุ โปรดดึงมาติดป้ายลดราคาหรือตัดของเสีย
          </p>
          <div className="space-y-1.5">
            {expiringBatches.slice(0, 3).map((item, idx) => (
              <div
                key={idx}
                className="bg-white/80 p-2 rounded-xl text-xs flex items-center justify-between"
              >
                <span className="font-semibold text-slate-800 truncate pr-2">
                  {item.product.name_th}
                </span>
                <span className="text-rose-600 font-bold shrink-0">
                  {item.is_expired ? 'หมดอายุแล้ว!' : `เหลือ ${item.days_until_expiry} วัน`}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Fast Movers Quick Check */}
      <div>
        <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
          สินค้าขายดีหน้าร้าน (Fast Sellers)
        </h3>
        <div className="bg-white rounded-2xl border border-slate-100 divide-y divide-slate-100 overflow-hidden">
          {fastSellers.map((p) => (
            <div key={p.id} className="p-3 flex items-center justify-between text-xs">
              <div className="pr-2">
                <p className="font-semibold text-slate-800">{p.name_th}</p>
                <p className="text-[10px] text-slate-400">ราคาขาย ฿{p.sell_price.toFixed(2)}</p>
              </div>
              <div className="text-right">
                <span
                  className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                    p.on_hand <= p.low_stock_level
                      ? 'bg-rose-100 text-rose-700'
                      : 'bg-emerald-100 text-emerald-800'
                  }`}
                >
                  คงเหลือ {p.on_hand} ชิ้น
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
