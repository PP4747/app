import React from 'react';
import {
  AlertTriangle,
  ArrowDownLeft,
  ArrowUpRight,
  Clock,
  FileSpreadsheet,
  RotateCcw,
  ShoppingCart,
  Trash2,
  Truck,
} from 'lucide-react';
import { useStore } from '../../lib/store';

interface OwnerHomeProps {
  onNavigate: (tab: string) => void;
  onOpenReceive: () => void;
  onOpenWaste: () => void;
}

export const OwnerHome: React.FC<OwnerHomeProps> = ({
  onNavigate,
  onOpenReceive,
  onOpenWaste,
}) => {
  const {
    productsWithStock,
    lowStockProducts,
    expiringBatches,
    expiredBatches,
    urgentAlerts,
    movements,
    resetToDemoData,
  } = useStore();

  const lowCount = lowStockProducts.length;
  const expCount = expiringBatches.length;
  const expiredCount = expiredBatches.length;

  return (
    <div className="space-y-4 pb-20">
      {/* Store Banner */}
      <div className="p-3.5 bg-gradient-to-r from-teal-900 to-slate-900 text-white rounded-2xl flex items-center justify-between border border-teal-800/80 shadow-xs">
        <div>
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-teal-500/30 text-teal-300 font-bold uppercase">
              POS Branch 0
            </span>
            <span className="text-xs font-bold text-white">ร้านรุ่งเรืองพานิช</span>
          </div>
          <p className="text-[11px] text-teal-200/80 mt-0.5">คลังสินค้าหลัก (Main WareHouse)</p>
        </div>
        <button
          onClick={() => {
            if (confirm('ต้องการโหลด/รีเซ็ตสต็อกเป็นข้อมูลสินค้าของร้านรุ่งเรืองพานิชหรือไม่?')) {
              resetToDemoData();
            }
          }}
          className="px-2.5 py-1.5 rounded-xl bg-teal-800 hover:bg-teal-700 active:scale-95 text-teal-100 text-[10px] font-semibold border border-teal-700/60 transition flex items-center gap-1 shrink-0"
          title="ซิงค์ข้อมูลร้านรุ่งเรืองพานิช"
        >
          <RotateCcw className="w-3 h-3 text-teal-300" />
          <span>ซิงค์สต็อกร้าน</span>
        </button>
      </div>

      {/* Top Welcome & KPI Summary */}
      <div className="grid grid-cols-2 gap-2.5">
        <div
          onClick={() => onNavigate('alerts')}
          className="bg-white p-3.5 rounded-2xl border border-slate-100 shadow-2xs cursor-pointer hover:border-amber-200 transition"
        >
          <div className="flex items-center justify-between text-amber-600 mb-1">
            <span className="text-xs font-semibold">สินค้าสต็อกต่ำ</span>
            <AlertTriangle className="w-4 h-4" />
          </div>
          <div className="text-2xl font-bold text-slate-800">{lowCount}</div>
          <p className="text-[11px] text-slate-400 mt-0.5">รายการต่ำกว่าเกณฑ์</p>
        </div>

        <div
          onClick={() => onNavigate('alerts')}
          className="bg-white p-3.5 rounded-2xl border border-slate-100 shadow-2xs cursor-pointer hover:border-rose-200 transition"
        >
          <div className="flex items-center justify-between text-rose-600 mb-1">
            <span className="text-xs font-semibold">ใกล้ / หมดอายุ</span>
            <Clock className="w-4 h-4" />
          </div>
          <div className="text-2xl font-bold text-slate-800">
            {expCount + expiredCount}
          </div>
          <p className="text-[11px] text-slate-400 mt-0.5">
            {expiredCount > 0 ? `หมดอายุ ${expiredCount} ล็อต` : 'เฝ้าระวัง 7 วัน'}
          </p>
        </div>
      </div>

      {/* Urgent Alerts Banner if any */}
      {urgentAlerts.length > 0 && (
        <div className="bg-rose-50 border border-rose-200 rounded-2xl p-4">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5 text-rose-700 font-bold text-xs uppercase tracking-wide">
              <AlertTriangle className="w-4 h-4" />
              <span>การแจ้งเตือนด่วน ({urgentAlerts.length} รายการ)</span>
            </div>
            <button
              onClick={() => onNavigate('alerts')}
              className="text-xs text-rose-700 font-semibold underline"
            >
              ดูทั้งหมด
            </button>
          </div>
          <div className="space-y-2">
            {urgentAlerts.slice(0, 3).map((alert, idx) => (
              <div
                key={idx}
                className="bg-white p-2.5 rounded-xl border border-rose-100 flex items-center justify-between text-xs"
              >
                <div>
                  <p className="font-semibold text-rose-900">{alert.title}</p>
                  <p className="text-[11px] text-rose-600">{alert.description}</p>
                </div>
                {alert.type === 'expired' ? (
                  <button
                    onClick={onOpenWaste}
                    className="px-2.5 py-1 bg-rose-600 text-white rounded-lg text-[10px] font-semibold hover:bg-rose-700 shrink-0"
                  >
                    ตัดทิ้ง
                  </button>
                ) : (
                  <button
                    onClick={() => onNavigate('to_order')}
                    className="px-2.5 py-1 bg-teal-600 text-white rounded-lg text-[10px] font-semibold hover:bg-teal-700 shrink-0"
                  >
                    สั่งเพิ่ม
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Primary Action Buttons (Thumb Reachable) */}
      <div>
        <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
          งานประจำวัน (Daily Actions)
        </h3>
        <div className="grid grid-cols-2 gap-2.5">
          <button
            onClick={() => onNavigate('pos_upload')}
            className="flex items-center gap-3 p-3.5 bg-gradient-to-r from-teal-600 to-teal-700 text-white rounded-2xl shadow-sm hover:from-teal-700 hover:to-teal-800 transition active:scale-95 text-left"
          >
            <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold leading-tight">นำเข้ายอดขาย POS</p>
              <p className="text-[10px] text-teal-100">ตัดสต็อก FIFO สิ้นวัน</p>
            </div>
          </button>

          <button
            onClick={() => onNavigate('to_order')}
            className="flex items-center gap-3 p-3.5 bg-gradient-to-r from-emerald-600 to-emerald-700 text-white rounded-2xl shadow-sm hover:from-emerald-700 hover:to-emerald-800 transition active:scale-95 text-left"
          >
            <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
              <ShoppingCart className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold leading-tight">รายการต้องสั่งซื้อ</p>
              <p className="text-[10px] text-emerald-100">คำนวณสูตร 14 วัน</p>
            </div>
          </button>

          <button
            onClick={onOpenReceive}
            className="flex items-center gap-3 p-3.5 bg-white border border-slate-200 rounded-2xl hover:bg-slate-50 transition active:scale-95 text-left"
          >
            <div className="w-10 h-10 rounded-xl bg-sky-50 text-sky-700 flex items-center justify-center shrink-0">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-800">รับสินค้าเข้า</p>
              <p className="text-[10px] text-slate-400">บันทึกล็อต + วันหมดอายุ</p>
            </div>
          </button>

          <button
            onClick={onOpenWaste}
            className="flex items-center gap-3 p-3.5 bg-white border border-slate-200 rounded-2xl hover:bg-slate-50 transition active:scale-95 text-left"
          >
            <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-700 flex items-center justify-center shrink-0">
              <Trash2 className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-800">บันทึกของเสีย</p>
              <p className="text-[10px] text-slate-400">หมดอายุ / แตกหัก</p>
            </div>
          </button>
        </div>
      </div>

      {/* Recent Movements Log Preview */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            ความเคลื่อนไหวสต็อกล่าสุด
          </h3>
          <button
            onClick={() => onNavigate('audit')}
            className="text-xs text-teal-700 font-semibold"
          >
            ดูประวัติทั้งหมด
          </button>
        </div>
        <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden divide-y divide-slate-100">
          {movements.slice(0, 5).map((m) => {
            const product = productsWithStock.find((p) => p.id === m.product_id);
            const isAdd = m.quantity > 0;
            return (
              <div key={m.id} className="p-3 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2.5">
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${
                      m.type === 'receive'
                        ? 'bg-emerald-50 text-emerald-600'
                        : m.type === 'waste'
                        ? 'bg-rose-50 text-rose-600'
                        : 'bg-teal-50 text-teal-600'
                    }`}
                  >
                    {isAdd ? (
                      <ArrowDownLeft className="w-3.5 h-3.5" />
                    ) : (
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    )}
                  </div>
                  <div>
                    <p className="font-semibold text-slate-800 line-clamp-1">
                      {product?.name_th || 'สินค้าในระบบ'}
                    </p>
                    <p className="text-[10px] text-slate-400">
                      โดย {m.created_by_name || 'ผู้ใช้'} •{' '}
                      {new Date(m.created_at).toLocaleTimeString('th-TH', {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <span
                    className={`font-bold ${
                      isAdd ? 'text-emerald-600' : 'text-slate-700'
                    }`}
                  >
                    {isAdd ? `+${m.quantity}` : m.quantity} ชิ้น
                  </span>
                  <span className="block text-[10px] text-slate-400 capitalize">
                    {m.type === 'sale'
                      ? 'ขาย'
                      : m.type === 'receive'
                      ? 'รับของ'
                      : m.type === 'waste'
                      ? 'ของเสีย'
                      : 'นับสต็อก'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
