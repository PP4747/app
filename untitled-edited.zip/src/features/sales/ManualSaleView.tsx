import React, { useState } from 'react';
import { Barcode, CheckCircle2, Receipt, ShoppingBag } from 'lucide-react';
import { useStore } from '../../lib/store';

interface ManualSaleViewProps {
  onOpenScan: () => void;
  onDone: () => void;
}

export const ManualSaleView: React.FC<ManualSaleViewProps> = ({ onOpenScan, onDone }) => {
  const { productsWithStock, recordManualSale, currentUser } = useStore();
  const [selectedProductId, setSelectedProductId] = useState<string>(
    productsWithStock[0]?.id ?? ''
  );
  const [quantity, setQuantity] = useState<string>('1');
  const [successInfo, setSuccessInfo] = useState<{
    productName: string;
    qty: number;
    negativeStock: boolean;
  } | null>(null);

  const selectedProduct = productsWithStock.find((p) => p.id === selectedProductId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const qtyNum = parseInt(quantity, 10);
    if (!selectedProductId || isNaN(qtyNum) || qtyNum <= 0) return;

    const res = recordManualSale(selectedProductId, qtyNum);
    if (res.success && selectedProduct) {
      setSuccessInfo({
        productName: selectedProduct.name_th,
        qty: qtyNum,
        negativeStock: res.negativeStockFlag,
      });
      setQuantity('1');
    }
  };

  return (
    <div className="space-y-4 pb-20">
      <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-2xs">
        <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
          <div className="w-10 h-10 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center shrink-0">
            <Receipt className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">บันทึกการขายหน้าร้าน (Manual Sale)</h2>
            <p className="text-xs text-slate-400">
              ตัดสต็อกแบบ FIFO อัตโนมัติ (ล็อตที่หมดอายุก่อนจะถูกตัดก่อน)
            </p>
          </div>
        </div>

        {successInfo ? (
          <div className="my-6 p-5 bg-teal-50 border border-teal-200 rounded-2xl text-center space-y-3 animate-in zoom-in-95">
            <CheckCircle2 className="w-12 h-12 text-teal-600 mx-auto" />
            <div>
              <h3 className="text-sm font-bold text-teal-900">บันทึกการขายเรียบร้อย!</h3>
              <p className="text-xs text-teal-700 mt-1">
                {successInfo.productName} จำนวน <strong>-{successInfo.qty} ชิ้น</strong>
              </p>
              {successInfo.negativeStock && (
                <p className="text-xs text-amber-700 font-semibold mt-1">
                  ⚠️ คำเตือน: ยอดขายมากกว่าสต็อกที่มีในระบบ (คงเหลือปรับเป็น 0 พร้อมบันทึกเตือน)
                </p>
              )}
            </div>
            <div className="flex gap-2 justify-center pt-2">
              <button
                type="button"
                onClick={() => setSuccessInfo(null)}
                className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold rounded-xl transition"
              >
                ขายรายการต่อไป
              </button>
              <button
                type="button"
                onClick={onDone}
                className="px-4 py-2 bg-white border border-slate-200 text-slate-700 text-xs font-semibold rounded-xl hover:bg-slate-50 transition"
              >
                กลับหน้ารวม
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 mt-4 text-xs">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="font-semibold text-slate-700">เลือกสินค้า *</label>
                <button
                  type="button"
                  onClick={onOpenScan}
                  className="flex items-center gap-1 text-[11px] font-semibold text-teal-700 hover:underline"
                >
                  <Barcode className="w-3.5 h-3.5" />
                  สแกนบาร์โค้ด
                </button>
              </div>
              <select
                value={selectedProductId}
                onChange={(e) => setSelectedProductId(e.target.value)}
                className="w-full p-3 border border-slate-200 rounded-2xl bg-white text-xs font-medium focus:ring-2 focus:ring-teal-500 outline-none"
              >
                {productsWithStock.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name_th} [คงเหลือ: {p.on_hand}]
                  </option>
                ))}
              </select>
            </div>

            {selectedProduct && (
              <div className="p-3 bg-slate-50 rounded-2xl text-[11px] text-slate-600 flex items-center justify-between">
                <div>
                  <p className="font-medium text-slate-800">ราคาขาย: ฿{selectedProduct.sell_price.toFixed(2)}</p>
                  <p className="text-slate-400">คงเหลือในระบบ: {selectedProduct.on_hand} ชิ้น</p>
                </div>
                <div className="text-right">
                  <p className="text-[10px] text-teal-700 font-semibold">
                    ยอดรวม: ฿{((parseInt(quantity, 10) || 0) * selectedProduct.sell_price).toFixed(2)}
                  </p>
                </div>
              </div>
            )}

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                จำนวนที่ขาย (ชิ้น) *
              </label>
              <input
                type="number"
                min="1"
                required
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                className="w-full p-3 border border-slate-200 rounded-2xl text-base font-bold focus:ring-2 focus:ring-teal-500 outline-none"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3.5 bg-teal-600 hover:bg-teal-700 active:scale-95 text-white font-bold rounded-2xl shadow-sm transition flex items-center justify-center gap-2 text-sm mt-4"
            >
              <ShoppingBag className="w-5 h-5" />
              ยืนยันการขาย & ตัดสต็อก
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
