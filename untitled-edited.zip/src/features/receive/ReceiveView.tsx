import React, { useState } from 'react';
import {
  Barcode,
  Calendar,
  CheckCircle2,
  Package,
  Plus,
  Truck,
} from 'lucide-react';
import { useStore } from '../../lib/store';

interface ReceiveViewProps {
  initialProductId?: string;
  onOpenScan: () => void;
  onDone: () => void;
}

export const ReceiveView: React.FC<ReceiveViewProps> = ({
  initialProductId,
  onOpenScan,
  onDone,
}) => {
  const { products, receiveStock, currentUser } = useStore();
  const [selectedProductId, setSelectedProductId] = useState<string>(
    initialProductId || (products[0]?.id ?? '')
  );
  const [quantity, setQuantity] = useState<string>('10');
  const [hasExpiry, setHasExpiry] = useState<boolean>(true);
  const [expiryDate, setExpiryDate] = useState<string>('2026-10-25');
  const [successInfo, setSuccessInfo] = useState<{
    productName: string;
    qty: number;
    expiry: string | null;
  } | null>(null);

  const selectedProduct = products.find((p) => p.id === selectedProductId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const qtyNum = parseInt(quantity, 10);
    if (!selectedProductId || isNaN(qtyNum) || qtyNum <= 0) return;

    const finalExpiry = hasExpiry && expiryDate ? expiryDate : null;
    const res = receiveStock(selectedProductId, qtyNum, finalExpiry);

    if (res.success && selectedProduct) {
      setSuccessInfo({
        productName: selectedProduct.name_th,
        qty: qtyNum,
        expiry: finalExpiry,
      });
      // reset
      setQuantity('10');
    }
  };

  return (
    <div className="space-y-4 pb-20">
      <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-2xs">
        <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
          <div className="w-10 h-10 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center shrink-0">
            <Truck className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">รับสินค้าเข้าสต็อก</h2>
            <p className="text-xs text-slate-400">
              ผู้บันทึก: {currentUser.name} ({currentUser.role === 'owner' ? 'เจ้าของร้าน' : 'พนักงาน'})
            </p>
          </div>
        </div>

        {successInfo ? (
          <div className="my-6 p-5 bg-teal-50 border border-teal-200 rounded-2xl text-center space-y-3 animate-in zoom-in-95">
            <CheckCircle2 className="w-12 h-12 text-teal-600 mx-auto" />
            <div>
              <h3 className="text-sm font-bold text-teal-900">
                บันทึกรับสินค้าเข้าสำเร็จเรียบร้อย!
              </h3>
              <p className="text-xs text-teal-700 mt-1">
                {successInfo.productName} จำนวน <strong>+{successInfo.qty} ชิ้น</strong>
              </p>
              {successInfo.expiry && (
                <p className="text-xs text-teal-600">
                  วันหมดอายุล็อตนี้: {successInfo.expiry}
                </p>
              )}
            </div>
            <div className="flex gap-2 justify-center pt-2">
              <button
                type="button"
                onClick={() => setSuccessInfo(null)}
                className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold rounded-xl transition"
              >
                รับรายการต่อไป
              </button>
              <button
                type="button"
                onClick={onDone}
                className="px-4 py-2 bg-white border border-slate-200 text-slate-700 text-xs font-semibold rounded-xl hover:bg-slate-50 transition"
              >
                กลับหน้ารายการ
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 mt-4 text-xs">
            {/* Product Selector with Scanner button */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="font-semibold text-slate-700">เลือกสินค้า *</label>
                <button
                  type="button"
                  onClick={onOpenScan}
                  className="flex items-center gap-1 text-[11px] font-semibold text-teal-700 hover:underline"
                >
                  <Barcode className="w-3.5 h-3.5" />
                  สแกนบาร์โค้ด
                </button>
              </div>
              <select
                value={selectedProductId}
                onChange={(e) => setSelectedProductId(e.target.value)}
                className="w-full p-3 border border-slate-200 rounded-2xl bg-white text-xs font-medium focus:ring-2 focus:ring-teal-500 outline-none"
              >
                {products.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name_th} {p.barcode ? `(${p.barcode})` : ''}
                  </option>
                ))}
              </select>
            </div>

            {selectedProduct && (
              <div className="p-3 bg-slate-50 rounded-2xl text-[11px] text-slate-600 space-y-0.5">
                <p>หมวดหมู่: {selectedProduct.category}</p>
                <p>ราคาขาย: ฿{selectedProduct.sell_price.toFixed(2)}</p>
                {selectedProduct.barcode && <p>บาร์โค้ด: {selectedProduct.barcode}</p>}
              </div>
            )}

            {/* Quantity */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                จำนวนที่รับเข้ามา (ชิ้น) *
              </label>
              <input
                type="number"
                min="1"
                required
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                placeholder="เช่น 12"
                className="w-full p-3 border border-slate-200 rounded-2xl text-base font-bold focus:ring-2 focus:ring-teal-500 outline-none"
              />
            </div>

            {/* Expiry Date */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="font-semibold text-slate-700">
                  วันหมดอายุของล็อตนี้ (Expiry Date)
                </label>
                <label className="flex items-center gap-1.5 text-[11px] text-slate-500 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={!hasExpiry}
                    onChange={(e) => setHasExpiry(!e.target.checked)}
                    className="rounded text-teal-600 focus:ring-teal-500"
                  />
                  <span>ไม่มีวันหมดอายุ</span>
                </label>
              </div>

              {hasExpiry ? (
                <div className="relative">
                  <input
                    type="date"
                    required
                    value={expiryDate}
                    onChange={(e) => setExpiryDate(e.target.value)}
                    className="w-full p-3 border border-slate-200 rounded-2xl font-medium focus:ring-2 focus:ring-teal-500 outline-none"
                  />
                </div>
              ) : (
                <div className="p-2.5 rounded-xl bg-slate-100 text-slate-500 text-center">
                  สินค้าประเภทนี้ไม่มีวันหมดอายุ (เช่น ของใช้ ยาสีฟัน)
                </div>
              )}
            </div>

            <button
              type="submit"
              className="w-full py-3.5 bg-teal-600 hover:bg-teal-700 active:scale-95 text-white font-bold rounded-2xl shadow-sm transition flex items-center justify-center gap-2 text-sm mt-4"
            >
              <Plus className="w-5 h-5" />
              ยืนยันรับเข้าสต็อก
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
