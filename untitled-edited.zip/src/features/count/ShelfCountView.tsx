import React, { useState } from 'react';
import { Barcode, CheckCircle2, RotateCcw } from 'lucide-react';
import { useStore } from '../../lib/store';

interface ShelfCountViewProps {
  onOpenScan: () => void;
  onDone: () => void;
}

export const ShelfCountView: React.FC<ShelfCountViewProps> = ({ onOpenScan, onDone }) => {
  const { productsWithStock, recordShelfCount, currentUser } = useStore();
  const [selectedProductId, setSelectedProductId] = useState<string>(
    productsWithStock[0]?.id ?? ''
  );
  const [countedQty, setCountedQty] = useState<string>('10');
  const [successInfo, setSuccessInfo] = useState<{
    productName: string;
    counted: number;
    diff: number;
  } | null>(null);

  const selectedProduct = productsWithStock.find((p) => p.id === selectedProductId);
  const currentOnHand = selectedProduct?.on_hand ?? 0;
  const countedNum = parseInt(countedQty, 10) || 0;
  const calculatedDiff = countedNum - currentOnHand;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProductId || isNaN(countedNum) || countedNum < 0) return;

    const res = recordShelfCount(selectedProductId, countedNum);
    if (res.success && selectedProduct) {
      setSuccessInfo({
        productName: selectedProduct.name_th,
        counted: countedNum,
        diff: res.diff,
      });
    }
  };

  return (
    <div className="space-y-4 pb-20">
      <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-2xs">
        <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
          <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-700 flex items-center justify-center shrink-0">
            <RotateCcw className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">ตรวจนับสต็อกจริง (Shelf Count)</h2>
            <p className="text-xs text-slate-400">
              สำหรับสินค้าหมุนเวียนช้า (Slow-moving) หรือตรวจสอบความถูกต้อง
            </p>
          </div>
        </div>

        {successInfo ? (
          <div className="my-6 p-5 bg-indigo-50 border border-indigo-200 rounded-2xl text-center space-y-3 animate-in zoom-in-95">
            <CheckCircle2 className="w-12 h-12 text-indigo-600 mx-auto" />
            <div>
              <h3 className="text-sm font-bold text-indigo-900">
                ปรับปรุงยอดสต็อกตามการนับจริงสำเร็จ!
              </h3>
              <p className="text-xs text-indigo-700 mt-1">
                {successInfo.productName}: ยอดนับจริงคือ <strong>{successInfo.counted} ชิ้น</strong>
              </p>
              <p className="text-xs text-indigo-600 font-semibold mt-1">
                ผลต่างสต็อกที่ปรับปรุง:{' '}
                {successInfo.diff > 0
                  ? `+${successInfo.diff} ชิ้น (สต็อกเพิ่มขึ้น)`
                  : successInfo.diff < 0
                  ? `${successInfo.diff} ชิ้น (สต็อกลดลง)`
                  : 'ตรงกับในระบบ (ไม่มียอดปรับปรุง)'}
              </p>
            </div>
            <div className="flex gap-2 justify-center pt-2">
              <button
                type="button"
                onClick={() => setSuccessInfo(null)}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-xl transition"
              >
                นับรายการต่อไป
              </button>
              <button
                type="button"
                onClick={onDone}
                className="px-4 py-2 bg-white border border-slate-200 text-slate-700 text-xs font-semibold rounded-xl hover:bg-slate-50 transition"
              >
                กลับหน้าหลัก
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 mt-4 text-xs">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="font-semibold text-slate-700">เลือกสินค้า *</label>
                <button
                  type="button"
                  onClick={onOpenScan}
                  className="flex items-center gap-1 text-[11px] font-semibold text-indigo-700 hover:underline"
                >
                  <Barcode className="w-3.5 h-3.5" />
                  สแกนบาร์โค้ด
                </button>
              </div>
              <select
                value={selectedProductId}
                onChange={(e) => {
                  setSelectedProductId(e.target.value);
                  const p = productsWithStock.find((x) => x.id === e.target.value);
                  if (p) setCountedQty(String(p.on_hand));
                }}
                className="w-full p-3 border border-slate-200 rounded-2xl bg-white text-xs font-medium focus:ring-2 focus:ring-indigo-500 outline-none"
              >
                {productsWithStock.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name_th} [ในระบบ: {p.on_hand}]
                  </option>
                ))}
              </select>
            </div>

            {/* Current vs Counted comparison card */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 grid grid-cols-3 gap-2 text-center">
              <div>
                <span className="text-[10px] text-slate-400 block">ในระบบปัจจุบัน</span>
                <span className="text-lg font-bold text-slate-700">{currentOnHand}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block">นับได้จริง</span>
                <span className="text-lg font-bold text-indigo-600">{countedNum}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block">ผลต่าง (Diff)</span>
                <span
                  className={`text-lg font-bold ${
                    calculatedDiff > 0
                      ? 'text-emerald-600'
                      : calculatedDiff < 0
                      ? 'text-rose-600'
                      : 'text-slate-500'
                  }`}
                >
                  {calculatedDiff > 0 ? `+${calculatedDiff}` : calculatedDiff}
                </span>
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                กรอกจำนวนที่นับได้จริงบนชั้นวาง (ชิ้น) *
              </label>
              <input
                type="number"
                min="0"
                required
                value={countedQty}
                onChange={(e) => setCountedQty(e.target.value)}
                className="w-full p-3 border border-slate-200 rounded-2xl text-lg font-bold focus:ring-2 focus:ring-indigo-500 outline-none"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3.5 bg-indigo-600 hover:bg-indigo-700 active:scale-95 text-white font-bold rounded-2xl shadow-sm transition flex items-center justify-center gap-2 text-sm mt-4"
            >
              <RotateCcw className="w-5 h-5" />
              บันทึกผลการนับ & บันทึกการปรับปรุงสต็อก
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
