import React, { useState } from 'react';
import Papa from 'papaparse';
import {
  AlertCircle,
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  Download,
  FileSpreadsheet,
  Link2,
  Upload,
} from 'lucide-react';
import { useStore } from '../../lib/store';
import { matchPosProduct } from '../../lib/rules/stockRules';

interface PosUploadViewProps {
  onDone: () => void;
}

interface ParsedRow {
  raw_barcode?: string;
  raw_name: string;
  quantity: number;
  matchedId?: string;
  matchedName?: string;
  status: 'matched' | 'unmatched';
}

export const PosUploadView: React.FC<PosUploadViewProps> = ({ onDone }) => {
  const { products, applyPosImport, posImports, resolveUnmatchedRow, posImportRows } = useStore();
  const [file, setFile] = useState<File | null>(null);
  const [filename, setFilename] = useState<string>('');
  const [salesDate, setSalesDate] = useState<string>('2026-10-12');
  const [parsedRows, setParsedRows] = useState<ParsedRow[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [duplicateWarning, setDuplicateWarning] = useState<string | null>(null);
  const [step, setStep] = useState<'upload' | 'preview' | 'success'>('upload');
  const [importSummary, setImportSummary] = useState<{
    importId: string;
    matched: number;
    unmatched: number;
  } | null>(null);

  // Link unmatched product dialog state
  const [resolvingRow, setResolvingRow] = useState<ParsedRow | null>(null);
  const [selectedLinkProductId, setSelectedLinkProductId] = useState<string>(products[0]?.id || '');

  // Generate and download sample CSV from real store POS
  const handleDownloadSample = () => {
    const link = document.createElement('a');
    link.href = '/pos_rungruang_sample.csv';
    link.download = `pos_rungruang_sample.csv`;
    link.click();
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFile = e.target.files?.[0];
    if (!uploadedFile) return;

    setFile(uploadedFile);
    setFilename(uploadedFile.name);
    parseFile(uploadedFile);
  };

  const parseFile = (fileToParse: File) => {
    setIsProcessing(true);
    setDuplicateWarning(null);

    Papa.parse(fileToParse, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        setIsProcessing(false);
        const data = results.data as Array<Record<string, string>>;

        let detectedDate = salesDate;

        const mappedRows: ParsedRow[] = data
          .map((row) => {
            // Flexible column detection (handles Rungruang Panich POS format & generic variants)
            const rawBarcode =
              row['CF_ITEMID'] ||
              row['CF_SERIALNO'] ||
              row['SYSITEMID'] ||
              row['Barcode'] ||
              row['barcode'] ||
              row['บาร์โค้ด'] ||
              row['รหัสสินค้า'] ||
              '';

            const rawName =
              row['CF_ITEMNAME'] ||
              row['ProductName'] ||
              row['name'] ||
              row['ชื่อสินค้า'] ||
              row['รายการ'] ||
              'ไม่ระบุชื่อ';

            const qtyStr =
              row['CF_TDBASEQUANTITY'] ||
              row['QuantitySold'] ||
              row['quantity'] ||
              row['จำนวน'] ||
              row['จำนวนขาย'] ||
              '1';
            const quantity = Math.abs(parseInt(qtyStr, 10)) || 1;

            // Auto-detect transaction date if present (e.g. 02/10/2569 or 10/2/2026)
            const rawDate = row['CF_TRANDATE'] || row['TRANDATE'] || '';
            if (rawDate && !detectedDate) {
              if (rawDate.includes('/2569')) {
                // Thai Buddhist era (2569 -> 2026)
                const parts = rawDate.split(' ')[0].split('/');
                if (parts.length === 3) {
                  const day = parts[0].padStart(2, '0');
                  const month = parts[1].padStart(2, '0');
                  detectedDate = `2026-${month}-${day}`;
                }
              } else if (rawDate.includes('/2026')) {
                const parts = rawDate.split(' ')[0].split('/');
                if (parts.length === 3) {
                  const month = parts[0].padStart(2, '0');
                  const day = parts[1].padStart(2, '0');
                  detectedDate = `2026-${month}-${day}`;
                }
              }
            }

            const match = matchPosProduct(rawBarcode, rawName, products);

            return {
              raw_barcode: rawBarcode.trim() || undefined,
              raw_name: rawName.trim(),
              quantity,
              matchedId: match.matchedProduct?.id,
              matchedName: match.matchedProduct?.name_th,
              status: match.status,
            };
          })
          .filter((r) => r.quantity > 0 && r.raw_name !== 'ไม่ระบุชื่อ');

        if (detectedDate) {
          setSalesDate(detectedDate);
        }

        // Check Rule 11: Duplicate upload guard
        const duplicate = posImports.find(
          (imp) => imp.filename === fileToParse.name && imp.sales_date === (detectedDate || salesDate)
        );
        if (duplicate) {
          setDuplicateWarning(
            `คุณเคยอัปโหลดไฟล์ "${fileToParse.name}" สำหรับวันที่ ${detectedDate || salesDate} แล้ว (จำนวน ${duplicate.row_count} แถว)`
          );
        }

        setParsedRows(mappedRows);
        setStep('preview');
      },
      error: (err) => {
        setIsProcessing(false);
        console.error('CSV parse error:', err);
      },
    });
  };

  const handleApplyImport = () => {
    if (parsedRows.length === 0) return;

    const rawRows = parsedRows.map((r) => ({
      raw_name: r.raw_name,
      raw_barcode: r.raw_barcode,
      quantity: r.quantity,
    }));

    const res = applyPosImport(filename, salesDate, rawRows);
    if (res.success) {
      setImportSummary({
        importId: res.importId,
        matched: res.matchedCount,
        unmatched: res.unmatchedCount,
      });
      setStep('success');
    }
  };

  const matchedCount = parsedRows.filter((r) => r.status === 'matched').length;
  const unmatchedCount = parsedRows.filter((r) => r.status === 'unmatched').length;

  return (
    <div className="space-y-4 pb-20">
      <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-2xs">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center shrink-0">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                นำเข้ายอดขาย POS ประจำวัน
              </h2>
              <p className="text-xs text-slate-400">
                อัปโหลดไฟล์ CSV เพื่อตัดสต็อกสินค้าตามลำดับ FIFO
              </p>
            </div>
          </div>
          <button
            onClick={handleDownloadSample}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-teal-200 bg-teal-50 text-teal-800 text-xs font-semibold hover:bg-teal-100 transition active:scale-95"
            title="ดาวน์โหลดไฟล์ตัวอย่าง CSV"
          >
            <Download className="w-3.5 h-3.5" />
            <span>โหลดไฟล์ตัวอย่าง</span>
          </button>
        </div>

        {step === 'upload' && (
          <div className="space-y-4 mt-4 text-xs">
            {/* Sales Date */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                วันที่ยอดขายของไฟล์นี้ (Sales Date) *
              </label>
              <input
                type="date"
                value={salesDate}
                onChange={(e) => setSalesDate(e.target.value)}
                className="w-full p-3 border border-slate-200 rounded-2xl font-medium focus:ring-2 focus:ring-teal-500 outline-none"
              />
            </div>

            {/* Drop Zone */}
            <div className="border-2 border-dashed border-teal-200 rounded-3xl p-8 text-center bg-teal-50/40 hover:bg-teal-50 transition cursor-pointer relative">
              <input
                type="file"
                accept=".csv,text/csv"
                onChange={handleFileUpload}
                className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
              />
              <Upload className="w-10 h-10 text-teal-600 mx-auto mb-2" />
              <p className="text-sm font-bold text-teal-900">
                แตะเพื่อเลือกไฟล์ หรือลากไฟล์ CSV มาวาง
              </p>
              <p className="text-[11px] text-teal-700 mt-1">
                รองรับไฟล์ส่งออกจากเครื่อง POS (มีคอลัมน์ Barcode, Name, Quantity)
              </p>
            </div>

            {/* Quick Demo Button */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
              <p className="text-xs font-semibold text-slate-700 mb-2">
                ต้องการทดสอบทันที? ใช้ชุดข้อมูลตัวอย่างของวันนี้:
              </p>
              <button
                type="button"
                onClick={() => {
                  setFilename('pos_sales_20261012_demo.csv');
                  const demoRows: ParsedRow[] = [
                    {
                      raw_barcode: '8850188002021',
                      raw_name: 'นมสดพาสเจอร์ไรส์ เมจิ 200มล.',
                      quantity: 3,
                      matchedId: 'p-milk-meiji',
                      matchedName: 'นมสดพาสเจอร์ไรส์ เมจิ 200มล.',
                      status: 'matched',
                    },
                    {
                      raw_barcode: '8850123456789',
                      raw_name: 'ขนมปังแซนด์วิช ฟาร์มเฮ้าส์ 240ก.',
                      quantity: 2,
                      matchedId: 'p-bread-farmhouse',
                      matchedName: 'ขนมปังแซนด์วิช ฟาร์มเฮ้าส์ 240ก.',
                      status: 'matched',
                    },
                    {
                      raw_barcode: '8850718800033',
                      raw_name: 'เลย์ รสมันฝรั่งแท้ 50ก.',
                      quantity: 2,
                      matchedId: 'p-lays-classic',
                      matchedName: 'เลย์ รสมันฝรั่งแท้ 50ก.',
                      status: 'matched',
                    },
                    {
                      raw_barcode: '8850987101019',
                      raw_name: 'มาม่า บะหมี่กึ่งสำเร็จรูป ต้มยำกุ้ง 55ก.',
                      quantity: 4,
                      matchedId: 'p-mama-tomyum',
                      matchedName: 'มาม่า บะหมี่กึ่งสำเร็จรูป ต้มยำกุ้ง 55ก.',
                      status: 'matched',
                    },
                    {
                      raw_barcode: '9990001112223',
                      raw_name: 'น้ำดื่มสมุนไพรไม่มีบาร์โค้ดในระบบ',
                      quantity: 1,
                      status: 'unmatched',
                    },
                  ];
                  setParsedRows(demoRows);
                  setStep('preview');
                }}
                className="w-full py-2.5 px-3 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-semibold text-xs transition active:scale-95 flex items-center justify-center gap-2"
              >
                <span>โหลดตัวอย่างยอดขาย 5 รายการเพื่อทดสอบ</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {step === 'preview' && (
          <div className="space-y-4 mt-4 text-xs">
            {/* Duplicate upload warning */}
            {duplicateWarning && (
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-2xl flex items-start gap-2.5 text-amber-800">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-xs">คำเตือน: อัปโหลดซ้ำ (Duplicate Guard)</p>
                  <p className="text-[11px] mt-0.5">{duplicateWarning}</p>
                </div>
              </div>
            )}

            {/* Matching stats */}
            <div className="grid grid-cols-3 gap-2">
              <div className="p-3 bg-slate-50 rounded-2xl text-center">
                <span className="text-[10px] text-slate-400 block">ทั้งหมด</span>
                <span className="text-base font-bold text-slate-800">
                  {parsedRows.length} แถว
                </span>
              </div>
              <div className="p-3 bg-emerald-50 rounded-2xl text-center border border-emerald-100">
                <span className="text-[10px] text-emerald-600 block">จับคู่สำเร็จ</span>
                <span className="text-base font-bold text-emerald-800">
                  {matchedCount} รายการ
                </span>
              </div>
              <div className="p-3 bg-rose-50 rounded-2xl text-center border border-rose-100">
                <span className="text-[10px] text-rose-600 block">ไม่พบในระบบ</span>
                <span className="text-base font-bold text-rose-800">
                  {unmatchedCount} รายการ
                </span>
              </div>
            </div>

            {/* Rows table preview */}
            <div className="border border-slate-200 rounded-2xl overflow-hidden max-h-64 overflow-y-auto divide-y divide-slate-100">
              {parsedRows.map((row, idx) => (
                <div
                  key={idx}
                  className={`p-3 flex items-center justify-between text-xs ${
                    row.status === 'unmatched' ? 'bg-rose-50/50' : 'bg-white'
                  }`}
                >
                  <div className="pr-2 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span
                        className={`text-[9px] px-2 py-0.5 rounded-full font-bold ${
                          row.status === 'matched'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {row.status === 'matched' ? 'พบสินค้า' : 'ไม่พบสินค้า'}
                      </span>
                      {row.raw_barcode && (
                        <span className="text-[10px] text-slate-400 font-mono truncate">
                          {row.raw_barcode}
                        </span>
                      )}
                    </div>
                    <p className="font-semibold text-slate-800 mt-0.5 truncate">
                      {row.raw_name}
                    </p>
                    {row.matchedName && (
                      <p className="text-[10px] text-teal-700">
                        → ตรงกับ: {row.matchedName}
                      </p>
                    )}
                  </div>

                  <div className="text-right shrink-0">
                    <span className="font-bold text-slate-900 block">
                      {row.quantity} ชิ้น
                    </span>
                    {row.status === 'unmatched' && (
                      <button
                        type="button"
                        onClick={() => {
                          setResolvingRow(row);
                          setSelectedLinkProductId(products[0]?.id || '');
                        }}
                        className="mt-1 px-2 py-0.5 bg-rose-600 hover:bg-rose-700 text-white rounded text-[10px] font-semibold"
                      >
                        จับคู่
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {unmatchedCount > 0 && (
              <p className="text-[11px] text-rose-600">
                * แถวที่ไม่พบสินค้าจะถูกเก็บไว้ในฐานข้อมูล <code>pos_import_rows</code>{' '}
                และไม่ถูกละทิ้ง เจ้าของร้านสามารถจับคู่เพื่อตัดสต็อกภายหลังได้
              </p>
            )}

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setStep('upload')}
                className="py-3 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold transition"
              >
                เลือกไฟล์ใหม่
              </button>
              <button
                type="button"
                onClick={handleApplyImport}
                className="flex-1 py-3 bg-teal-600 hover:bg-teal-700 active:scale-95 text-white font-bold rounded-xl shadow-sm transition"
              >
                ยืนยันตัดสต็อก ({matchedCount} รายการ)
              </button>
            </div>
          </div>
        )}

        {step === 'success' && importSummary && (
          <div className="my-6 p-6 bg-teal-50 border border-teal-200 rounded-3xl text-center space-y-3 animate-in zoom-in-95">
            <CheckCircle2 className="w-14 h-14 text-teal-600 mx-auto" />
            <div>
              <h3 className="text-base font-bold text-teal-900">
                ตัดสต็อกตามยอดขาย POS สำเร็จเรียบร้อย!
              </h3>
              <p className="text-xs text-teal-700 mt-1">
                ตัดสต็อกตามลำดับ FIFO สำเร็จ <strong>{importSummary.matched} รายการ</strong>
              </p>
              {importSummary.unmatched > 0 && (
                <p className="text-xs text-amber-700 mt-1 font-medium">
                  มีรายการไม่พบบาร์โค้ด {importSummary.unmatched} รายการถูกบันทึกไว้ในประวัติ
                </p>
              )}
            </div>

            <div className="flex gap-2 justify-center pt-3">
              <button
                type="button"
                onClick={() => {
                  setStep('upload');
                  setParsedRows([]);
                }}
                className="px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold rounded-xl transition"
              >
                อัปโหลดไฟล์ถัดไป
              </button>
              <button
                type="button"
                onClick={onDone}
                className="px-4 py-2.5 bg-white border border-slate-200 text-slate-700 text-xs font-semibold rounded-xl hover:bg-slate-50 transition"
              >
                กลับหน้าหลัก
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Modal to link unmatched row */}
      {resolvingRow && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs animate-in fade-in">
          <div className="w-full max-w-sm rounded-3xl bg-white p-5 shadow-2xl space-y-3 text-xs">
            <h3 className="text-sm font-bold text-slate-900">
              จับคู่รายการที่ไม่พบกับสินค้าในร้าน
            </h3>
            <p className="text-slate-600 bg-slate-50 p-2.5 rounded-xl">
              ชื่อในไฟล์ POS: <strong>{resolvingRow.raw_name}</strong>
              {resolvingRow.raw_barcode && (
                <span className="block font-mono text-[10px] text-slate-400 mt-0.5">
                  บาร์โค้ด: {resolvingRow.raw_barcode}
                </span>
              )}
            </p>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                เลือกสินค้าในร้านที่ตรงกัน:
              </label>
              <select
                value={selectedLinkProductId}
                onChange={(e) => setSelectedLinkProductId(e.target.value)}
                className="w-full p-2.5 border border-slate-200 rounded-xl"
              >
                {products.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name_th}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setResolvingRow(null)}
                className="flex-1 py-2 rounded-xl border border-slate-200 text-slate-700"
              >
                ยกเลิก
              </button>
              <button
                type="button"
                onClick={() => {
                  const targetProd = products.find((p) => p.id === selectedLinkProductId);
                  if (targetProd) {
                    setParsedRows((prev) =>
                      prev.map((r) =>
                        r === resolvingRow
                          ? {
                              ...r,
                              status: 'matched',
                              matchedId: targetProd.id,
                              matchedName: targetProd.name_th,
                            }
                          : r
                      )
                    );
                  }
                  setResolvingRow(null);
                }}
                className="flex-1 py-2 rounded-xl bg-teal-600 text-white font-bold"
              >
                เชื่อมโยง
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
