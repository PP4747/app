import React, { useState } from 'react';
import {
  CheckCircle2,
  Download,
  FileDown,
  History,
  LifeBuoy,
  MessageCircle,
  TrendingDown,
  TrendingUp,
} from 'lucide-react';
import { useStore } from '../../lib/store';

export const WeeklySummaryView: React.FC = () => {
  const {
    productsWithStock,
    movements,
    auditLogs,
    batches,
    currentUser,
  } = useStore();

  const [exportedMsg, setExportedMsg] = useState<string | null>(null);

  // Top Sellers (from movements)
  const salesMap: Record<string, number> = {};
  movements
    .filter((m) => m.type === 'sale')
    .forEach((m) => {
      salesMap[m.product_id] = (salesMap[m.product_id] || 0) + Math.abs(m.quantity);
    });

  const topSellers = Object.entries(salesMap)
    .map(([pid, qty]) => {
      const p = productsWithStock.find((x) => x.id === pid);
      return {
        product: p,
        totalSold: qty,
      };
    })
    .filter((item) => item.product)
    .sort((a, b) => b.totalSold - a.totalSold);

  // Waste cost (Owner only)
  const wasteMovements = movements.filter((m) => m.type === 'waste');
  const totalWasteQty = wasteMovements.reduce((sum, m) => sum + Math.abs(m.quantity), 0);
  const totalWasteValue = wasteMovements.reduce(
    (sum, m) => sum + Math.abs(m.quantity) * (m.cost_at_time ?? 0),
    0
  );

  // CSV Export functions
  const downloadCsv = (filename: string, content: string) => {
    const blob = new Blob([new Uint8Array([0xef, 0xbb, 0xbf]), content], {
      type: 'text/csv;charset=utf-8;',
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
    setExportedMsg(`ส่งออกไฟล์ ${filename} เรียบร้อยแล้ว`);
    setTimeout(() => setExportedMsg(null), 3000);
  };

  const exportProductsCsv = () => {
    let csv = 'Product ID,Thai Name,English Name,Barcode,Category,Sell Price,Cost Price,On Hand,Low Stock Level\n';
    productsWithStock.forEach((p) => {
      csv += `"${p.id}","${p.name_th}","${p.name_en || ''}","${p.barcode || ''}","${p.category}",${p.sell_price},${p.cost_price ?? ''},${p.on_hand},${p.low_stock_level}\n`;
    });
    downloadCsv('products_catalog.csv', csv);
  };

  const exportBatchesCsv = () => {
    let csv = 'Batch ID,Product Name,Barcode,Quantity Remaining,Expiry Date,Received At,Is Active\n';
    batches.forEach((b) => {
      const p = productsWithStock.find((x) => x.id === b.product_id);
      csv += `"${b.id}","${p?.name_th || b.product_id}","${p?.barcode || ''}",${b.quantity},"${b.expiry_date || 'N/A'}","${b.received_at}",${b.is_active}\n`;
    });
    downloadCsv('stock_batches.csv', csv);
  };

  const exportMovementsCsv = () => {
    let csv = 'Movement ID,Product Name,Type,Quantity,Source,Reason,Created By,Timestamp\n';
    movements.forEach((m) => {
      const p = productsWithStock.find((x) => x.id === m.product_id);
      csv += `"${m.id}","${p?.name_th || m.product_id}","${m.type}",${m.quantity},"${m.source}","${m.reason || ''}","${m.created_by_name || m.created_by}","${m.created_at}"\n`;
    });
    downloadCsv('stock_movements.csv', csv);
  };

  const exportAuditLogsCsv = () => {
    let csv = 'Log ID,User Name,Action,Table,Record ID,Timestamp\n';
    auditLogs.forEach((log) => {
      csv += `"${log.id}","${log.user_name || log.user_id}","${log.action}","${log.table_name}","${log.record_id}","${log.created_at}"\n`;
    });
    downloadCsv('audit_logs.csv', csv);
  };

  return (
    <div className="space-y-4 pb-20">
      <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-2xs">
        <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
          <div className="w-10 h-10 rounded-2xl bg-amber-50 text-amber-700 flex items-center justify-center shrink-0">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">
              สรุปรายสัปดาห์ & รายงานวิเคราะห์ (Weekly Summary)
            </h2>
            <p className="text-xs text-slate-400">
              สินค้าขายดี ของเสีย และการส่งออกข้อมูล CSV
            </p>
          </div>
        </div>

        {/* Export toast */}
        {exportedMsg && (
          <div className="mt-3 p-3 bg-emerald-50 text-emerald-800 rounded-xl text-xs flex items-center gap-2 font-medium">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{exportedMsg}</span>
          </div>
        )}

        {/* KPIs */}
        <div className="grid grid-cols-2 gap-3 mt-4">
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
            <span className="text-[11px] text-slate-500 block">
              ของเสียสะสม (Waste Units)
            </span>
            <span className="text-xl font-bold text-rose-600">{totalWasteQty} ชิ้น</span>
            {currentUser.role === 'owner' && (
              <p className="text-[11px] text-rose-700 font-semibold mt-1">
                มูลค่า ฿{totalWasteValue.toFixed(2)}
              </p>
            )}
          </div>

          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
            <span className="text-[11px] text-slate-500 block">
              สินค้าหมดสต็อก (Stockout)
            </span>
            <span className="text-xl font-bold text-amber-600">
              {productsWithStock.filter((p) => p.on_hand === 0).length} รายการ
            </span>
            <p className="text-[11px] text-slate-400 mt-1">จากทั้งหมด {productsWithStock.length} ชนิด</p>
          </div>
        </div>

        {/* Top Sellers Table */}
        <div className="mt-5">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wide mb-2">
            อันดับสินค้าขายดี (Top Moving Items)
          </h3>
          <div className="border border-slate-200 rounded-2xl overflow-hidden divide-y divide-slate-100">
            {topSellers.slice(0, 5).map((item, idx) => (
              <div
                key={idx}
                className="p-3 flex items-center justify-between text-xs bg-white"
              >
                <div className="flex items-center gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-teal-50 text-teal-800 font-bold flex items-center justify-center text-[11px]">
                    {idx + 1}
                  </span>
                  <div>
                    <p className="font-semibold text-slate-800">
                      {item.product?.name_th}
                    </p>
                    <p className="text-[10px] text-slate-400">
                      คงเหลือปัจจุบัน: {item.product?.on_hand} ชิ้น
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="font-bold text-teal-700">
                    {item.totalSold} ชิ้น
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* CSV Data Export Section (Owner Requirement) */}
        {currentUser.role === 'owner' && (
          <div className="mt-6 pt-5 border-t border-slate-100">
            <h3 className="text-xs font-bold text-slate-800 flex items-center gap-1.5 mb-2">
              <FileDown className="w-4 h-4 text-teal-600" />
              <span>ส่งออกข้อมูลสำรอง (Export to CSV - Never Locked In)</span>
            </h3>
            <p className="text-xs text-slate-500 mb-3">
              ดาวน์โหลดไฟล์สเปรดชีต CSV ครบทุกตารางเพื่อใช้งานต่อใน Excel
            </p>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                onClick={exportProductsCsv}
                className="p-3 rounded-xl border border-slate-200 hover:bg-slate-50 font-semibold text-slate-700 flex items-center gap-2 transition active:scale-95"
              >
                <Download className="w-4 h-4 text-teal-600" />
                <span>แคตตาล็อกสินค้า (.csv)</span>
              </button>

              <button
                onClick={exportBatchesCsv}
                className="p-3 rounded-xl border border-slate-200 hover:bg-slate-50 font-semibold text-slate-700 flex items-center gap-2 transition active:scale-95"
              >
                <Download className="w-4 h-4 text-teal-600" />
                <span>ทุกล็อตสินค้า (.csv)</span>
              </button>

              <button
                onClick={exportMovementsCsv}
                className="p-3 rounded-xl border border-slate-200 hover:bg-slate-50 font-semibold text-slate-700 flex items-center gap-2 transition active:scale-95"
              >
                <Download className="w-4 h-4 text-teal-600" />
                <span>ประวัติเคลื่อนไหวสต็อก (.csv)</span>
              </button>

              <button
                onClick={exportAuditLogsCsv}
                className="p-3 rounded-xl border border-slate-200 hover:bg-slate-50 font-semibold text-slate-700 flex items-center gap-2 transition active:scale-95"
              >
                <Download className="w-4 h-4 text-teal-600" />
                <span>ประวัติ Audit Log (.csv)</span>
              </button>
            </div>
          </div>
        )}

        {/* Contact Support Line (Pre-launch requirement) */}
        <div className="mt-6 p-4 bg-teal-50/70 border border-teal-100 rounded-2xl text-xs space-y-1">
          <div className="flex items-center gap-2 font-bold text-teal-900">
            <LifeBuoy className="w-4 h-4 text-teal-700" />
            <span>ช่องทางติดต่อผู้พัฒนา & แจ้งปัญหาการใช้งาน</span>
          </div>
          <p className="text-teal-800 text-[11px]">
            ทีมงานนักศึกษา KMITL (Convenience Store Stock Manager Project)
          </p>
          <p className="text-teal-700 text-[11px]">
            อีเมล: <code>68011890@kmitl.ac.th</code> • แคปภาพหน้าจอและส่งข้อความได้ทันที
          </p>
        </div>
      </div>
    </div>
  );
};
