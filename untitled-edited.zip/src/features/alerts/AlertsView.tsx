import React, { useState } from 'react';
import {
  AlertTriangle,
  Clock,
  Package,
  ShoppingCart,
  Trash2,
  XCircle,
} from 'lucide-react';
import { useStore } from '../../lib/store';

interface AlertsViewProps {
  onOpenWasteForProduct: (productId: string) => void;
  onNavigateToOrder: () => void;
}

export const AlertsView: React.FC<AlertsViewProps> = ({
  onOpenWasteForProduct,
  onNavigateToOrder,
}) => {
  const { lowStockProducts, expiringBatches, expiredBatches, urgentAlerts } = useStore();
  const [filter, setFilter] = useState<'all' | 'low' | 'expiring' | 'expired'>('all');

  return (
    <div className="space-y-4 pb-20">
      <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-2xs">
        <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
          <div className="w-10 h-10 rounded-2xl bg-rose-50 text-rose-700 flex items-center justify-center shrink-0">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">
              ศูนย์การแจ้งเตือนสต็อก (Alerts)
            </h2>
            <p className="text-xs text-slate-400">
              เฝ้าระวังสินค้าสต็อกต่ำ สินค้าหมด และล็อตที่หมดอายุ
            </p>
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex gap-1.5 mt-3 overflow-x-auto pb-1 no-scrollbar text-xs">
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1.5 rounded-full font-semibold transition ${
              filter === 'all'
                ? 'bg-slate-900 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            ทั้งหมด ({urgentAlerts.length})
          </button>
          <button
            onClick={() => setFilter('expired')}
            className={`px-3 py-1.5 rounded-full font-semibold transition ${
              filter === 'expired'
                ? 'bg-rose-600 text-white'
                : 'bg-rose-50 text-rose-700 hover:bg-rose-100'
            }`}
          >
            หมดอายุแล้ว ({expiredBatches.length})
          </button>
          <button
            onClick={() => setFilter('expiring')}
            className={`px-3 py-1.5 rounded-full font-semibold transition ${
              filter === 'expiring'
                ? 'bg-amber-600 text-white'
                : 'bg-amber-50 text-amber-700 hover:bg-amber-100'
            }`}
          >
            ใกล้หมดอายุ ({expiringBatches.length})
          </button>
          <button
            onClick={() => setFilter('low')}
            className={`px-3 py-1.5 rounded-full font-semibold transition ${
              filter === 'low'
                ? 'bg-teal-600 text-white'
                : 'bg-teal-50 text-teal-700 hover:bg-teal-100'
            }`}
          >
            สต็อกต่ำ ({lowStockProducts.length})
          </button>
        </div>

        {/* List of alerts */}
        <div className="space-y-3 mt-4">
          {/* 1. Expired Items */}
          {(filter === 'all' || filter === 'expired') && expiredBatches.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-rose-700 uppercase tracking-wide flex items-center gap-1.5">
                <XCircle className="w-4 h-4" />
                <span>สินค้าหมดอายุแล้ว (Expired)</span>
              </h4>
              {expiredBatches.map((exp) => (
                <div
                  key={exp.batch.id}
                  className="p-3.5 bg-rose-50/70 border border-rose-200 rounded-2xl flex items-center justify-between text-xs"
                >
                  <div>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-200 text-rose-800 font-bold">
                      หมดอายุแล้ว!
                    </span>
                    <p className="font-bold text-slate-900 mt-1">{exp.product.name_th}</p>
                    <p className="text-[11px] text-slate-500">
                      ล็อต {exp.batch.id.slice(-6)}: เหลือ {exp.batch.quantity} ชิ้น •
                      หมดอายุเมื่อ {exp.batch.expiry_date}
                    </p>
                  </div>
                  <button
                    onClick={() => onOpenWasteForProduct(exp.product.id)}
                    className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-xl text-xs flex items-center gap-1 shrink-0"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    ตัดทิ้ง
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* 2. Expiring Soon Items */}
          {(filter === 'all' || filter === 'expiring') && expiringBatches.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-amber-700 uppercase tracking-wide flex items-center gap-1.5">
                <Clock className="w-4 h-4" />
                <span>สินค้าใกล้หมดอายุ (ภายใน 7 วัน)</span>
              </h4>
              {expiringBatches.map((exp) => (
                <div
                  key={exp.batch.id}
                  className="p-3.5 bg-amber-50/70 border border-amber-200 rounded-2xl flex items-center justify-between text-xs"
                >
                  <div>
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                        exp.is_urgent
                          ? 'bg-rose-100 text-rose-800'
                          : 'bg-amber-200 text-amber-900'
                      }`}
                    >
                      {exp.days_until_expiry <= 2
                        ? `ด่วนมาก: เหลือ ${exp.days_until_expiry} วัน`
                        : `เหลือ ${exp.days_until_expiry} วัน`}
                    </span>
                    <p className="font-bold text-slate-900 mt-1">{exp.product.name_th}</p>
                    <p className="text-[11px] text-slate-500">
                      ล็อต {exp.batch.id.slice(-6)}: จำนวน {exp.batch.quantity} ชิ้น •
                      หมดอายุวันที่ {exp.batch.expiry_date}
                    </p>
                  </div>
                  <button
                    onClick={() => onOpenWasteForProduct(exp.product.id)}
                    className="px-3 py-1.5 bg-white border border-amber-300 text-amber-900 hover:bg-amber-50 font-semibold rounded-xl text-xs flex items-center gap-1 shrink-0"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    ตัดทิ้ง
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* 3. Low Stock Items */}
          {(filter === 'all' || filter === 'low') && lowStockProducts.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-teal-800 uppercase tracking-wide flex items-center gap-1.5">
                <Package className="w-4 h-4" />
                <span>สินค้าสต็อกต่ำกว่าเกณฑ์ (Low Stock)</span>
              </h4>
              {lowStockProducts.map((p) => (
                <div
                  key={p.id}
                  className="p-3.5 bg-teal-50/50 border border-teal-200 rounded-2xl flex items-center justify-between text-xs"
                >
                  <div>
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                        p.on_hand === 0
                          ? 'bg-rose-100 text-rose-800'
                          : 'bg-teal-100 text-teal-800'
                      }`}
                    >
                      {p.on_hand === 0 ? 'หมดสต็อก (0 ชิ้น)' : `สต็อกต่ำ (เหลือ ${p.on_hand})`}
                    </span>
                    <p className="font-bold text-slate-900 mt-1">{p.name_th}</p>
                    <p className="text-[11px] text-slate-500">
                      เกณฑ์เตือน: ≤ {p.low_stock_level} ชิ้น • แนะนำสั่ง:{' '}
                      <strong>{p.suggested_order_qty} ชิ้น</strong>
                    </p>
                  </div>
                  <button
                    onClick={onNavigateToOrder}
                    className="px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white font-semibold rounded-xl text-xs flex items-center gap-1 shrink-0"
                  >
                    <ShoppingCart className="w-3.5 h-3.5" />
                    สั่งซื้อ
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
