import React, { useState } from 'react';
import {
  AlertTriangle,
  Barcode,
  Calendar,
  Clock,
  Layers,
  Plus,
  Search,
  Truck,
  X,
} from 'lucide-react';
import { useStore } from '../../lib/store';
import { ProductWithStock } from '../../types';

interface ProductListProps {
  onOpenReceiveForProduct: (productId: string) => void;
  onOpenWasteForProduct: (productId: string) => void;
  onOpenScan: () => void;
}

export const ProductList: React.FC<ProductListProps> = ({
  onOpenReceiveForProduct,
  onOpenWasteForProduct,
  onOpenScan,
}) => {
  const { productsWithStock, currentUser, addProduct, suppliers } = useStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedProduct, setSelectedProduct] = useState<ProductWithStock | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);

  // New product form state
  const [newThName, setNewThName] = useState('');
  const [newEnName, setNewEnName] = useState('');
  const [newBarcode, setNewBarcode] = useState('');
  const [newCategory, setNewCategory] = useState('เครื่องดื่ม');
  const [newSupplierId, setNewSupplierId] = useState(suppliers[0]?.id || '');
  const [newSellPrice, setNewSellPrice] = useState('20');
  const [newCostPrice, setNewCostPrice] = useState('15');
  const [newLowStock, setNewLowStock] = useState('5');
  const [newInitialQty, setNewInitialQty] = useState('10');
  const [newExpiry, setNewExpiry] = useState('');

  // Extract unique categories
  const categories = [
    'all',
    ...Array.from(new Set(productsWithStock.map((p) => p.category))),
  ];

  const filteredProducts = productsWithStock.filter((p) => {
    const matchesSearch =
      p.name_th.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (p.name_en && p.name_en.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (p.barcode && p.barcode.includes(searchTerm));

    const matchesCategory =
      selectedCategory === 'all' || p.category === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newThName.trim()) return;

    addProduct(
      {
        name_th: newThName.trim(),
        name_en: newEnName.trim() || null,
        barcode: newBarcode.trim() || null,
        category: newCategory,
        supplier_id: newSupplierId,
        sell_price: parseFloat(newSellPrice) || 0,
        cost_price: parseFloat(newCostPrice) || 0,
        low_stock_level: parseInt(newLowStock, 10) || 5,
        track_mode: 'fast',
        has_expiry: Boolean(newExpiry),
        is_active: true,
      },
      parseInt(newInitialQty, 10) || 0,
      newExpiry || null
    );

    setShowAddModal(false);
    setNewThName('');
    setNewEnName('');
    setNewBarcode('');
  };

  return (
    <div className="space-y-3 pb-24">
      {/* Search Bar & Scanner trigger */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="ค้นหาชื่อสินค้า หรือบาร์โค้ด..."
            className="w-full pl-9 pr-3 py-2.5 text-xs bg-white border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-teal-500 shadow-2xs"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        <button
          onClick={onOpenScan}
          className="p-2.5 bg-white border border-slate-200 rounded-2xl hover:bg-slate-50 transition active:scale-95 text-slate-700 shadow-2xs shrink-0 flex items-center justify-center"
          title="สแกนบาร์โค้ด"
        >
          <Barcode className="w-5 h-5 text-teal-700" />
        </button>

        {currentUser.role === 'owner' && (
          <button
            onClick={() => setShowAddModal(true)}
            className="p-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-2xl transition active:scale-95 shadow-2xs shrink-0 flex items-center justify-center"
            title="เพิ่มสินค้าใหม่"
          >
            <Plus className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Category Filter Pills */}
      <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition ${
              selectedCategory === cat
                ? 'bg-teal-700 text-white shadow-2xs'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            {cat === 'all' ? 'ทั้งหมด' : cat}
          </button>
        ))}
      </div>

      {/* Product Count Indicator */}
      <div className="flex items-center justify-between text-[11px] text-slate-400 px-1">
        <span>พบ {filteredProducts.length} รายการ</span>
        {currentUser.role === 'owner' && (
          <span>แสดงราคาทุนเฉพาะเจ้าของร้าน</span>
        )}
      </div>

      {/* Product Cards List */}
      <div className="space-y-2.5">
        {filteredProducts.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-3xl border border-slate-100 p-6">
            <Layers className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-semibold text-slate-700">ไม่พบรายการสินค้า</p>
            <p className="text-xs text-slate-400 mt-1">ลองเปลี่ยนคำค้นหาหรือเลือกหมวดหมู่อื่น</p>
          </div>
        ) : (
          filteredProducts.map((p) => {
            const isLow = p.is_low_stock;
            const isZero = p.on_hand === 0;

            return (
              <div
                key={p.id}
                onClick={() => setSelectedProduct(p)}
                className="bg-white p-3.5 rounded-2xl border border-slate-100 hover:border-teal-300 shadow-2xs transition active:scale-98 cursor-pointer relative"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 mb-0.5">
                      <span className="text-[10px] px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 font-medium">
                        {p.category}
                      </span>
                      {p.barcode && (
                        <span className="text-[10px] text-slate-400 font-mono">
                          {p.barcode}
                        </span>
                      )}
                    </div>

                    <h4 className="text-xs font-bold text-slate-900 leading-snug line-clamp-2">
                      {p.name_th}
                    </h4>
                    {p.name_en && (
                      <p className="text-[10px] text-slate-400 line-clamp-1">{p.name_en}</p>
                    )}

                    {/* Price display */}
                    <div className="mt-2 flex items-center gap-3 text-xs">
                      <span className="font-semibold text-slate-800">
                        ขาย ฿{p.sell_price.toFixed(2)}
                      </span>
                      {currentUser.role === 'owner' && p.cost_price !== undefined && (
                        <span className="text-slate-400 text-[11px]">
                          ทุน ฿{p.cost_price.toFixed(2)}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Stock On Hand Status */}
                  <div className="text-right shrink-0">
                    <div
                      className={`inline-flex flex-col items-end px-3 py-1.5 rounded-xl font-bold ${
                        isZero
                          ? 'bg-rose-100 text-rose-700'
                          : isLow
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-emerald-50 text-emerald-800 border border-emerald-100'
                      }`}
                    >
                      <span className="text-base leading-none">{p.on_hand}</span>
                      <span className="text-[9px] font-medium opacity-80">
                        {isZero ? 'หมดสต็อก' : isLow ? 'สต็อกต่ำ' : 'คงเหลือ'}
                      </span>
                    </div>

                    <div className="mt-1 text-[10px] text-slate-400">
                      เตือนที่ ≤ {p.low_stock_level}
                    </div>
                  </div>
                </div>

                {/* Sub info: Batches & Expiry warnings */}
                {p.expiring_batches_count ? p.expiring_batches_count > 0 && (
                  <div className="mt-2.5 pt-2 border-t border-slate-50 flex items-center gap-1.5 text-[11px] text-rose-600 font-medium">
                    <Clock className="w-3.5 h-3.5" />
                    <span>มี {p.expiring_batches_count} ล็อตใกล้หรือหมดอายุ</span>
                  </div>
                ) : null}
              </div>
            );
          })
        )}
      </div>

      {/* Batch Inspector Modal */}
      {selectedProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs animate-in fade-in">
          <div className="w-full max-w-md rounded-3xl bg-white p-5 shadow-2xl flex flex-col max-h-[85vh]">
            <div className="flex items-start justify-between pb-3 border-b border-slate-100">
              <div className="pr-3">
                <span className="text-[10px] px-2 py-0.5 rounded bg-teal-50 text-teal-700 font-semibold">
                  {selectedProduct.category}
                </span>
                <h3 className="text-sm font-bold text-slate-900 mt-1">
                  {selectedProduct.name_th}
                </h3>
                {selectedProduct.barcode && (
                  <p className="text-xs text-slate-400 font-mono mt-0.5">
                    บาร์โค้ด: {selectedProduct.barcode}
                  </p>
                )}
              </div>
              <button
                onClick={() => setSelectedProduct(null)}
                className="p-1 rounded-full text-slate-400 hover:bg-slate-100 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Key product info */}
            <div className="grid grid-cols-3 gap-2 my-3 p-3 bg-slate-50 rounded-2xl text-center text-xs">
              <div>
                <span className="text-[10px] text-slate-400 block">คงเหลือรวม</span>
                <span className="text-base font-bold text-slate-800">
                  {selectedProduct.on_hand}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block">ราคาขาย</span>
                <span className="text-base font-bold text-slate-800">
                  ฿{selectedProduct.sell_price.toFixed(2)}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block">
                  {currentUser.role === 'owner' ? 'ราคาทุน' : 'เกณฑ์เตือน'}
                </span>
                <span className="text-base font-bold text-slate-800">
                  {currentUser.role === 'owner' && selectedProduct.cost_price !== undefined
                    ? `฿${selectedProduct.cost_price.toFixed(2)}`
                    : `≤ ${selectedProduct.low_stock_level}`}
                </span>
              </div>
            </div>

            {/* Batch List */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              <h4 className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-teal-600" />
                <span>ทุกล็อตสินค้าที่ยังใช้งานอยู่ (Active Batches)</span>
              </h4>

              {selectedProduct.batches.length === 0 ? (
                <div className="p-4 bg-slate-50 rounded-xl text-center text-xs text-slate-400">
                  ไม่มีล็อตสินค้าคงเหลือ
                </div>
              ) : (
                selectedProduct.batches.map((batch) => {
                  return (
                    <div
                      key={batch.id}
                      className="p-3 bg-white border border-slate-200 rounded-xl text-xs flex items-center justify-between shadow-2xs"
                    >
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-semibold text-slate-800">
                            ล็อต {batch.id.slice(-6)}
                          </span>
                          <span className="text-[10px] text-slate-400">
                            (รับ {new Date(batch.received_at).toLocaleDateString('th-TH')})
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          วันหมดอายุ:{' '}
                          {batch.expiry_date ? (
                            <span className="font-semibold text-slate-700">
                              {batch.expiry_date}
                            </span>
                          ) : (
                            <span className="text-slate-400">ไม่มีวันหมดอายุ</span>
                          )}
                        </p>
                      </div>
                      <div className="text-right">
                        <span className="text-sm font-bold text-teal-700">
                          {batch.quantity} ชิ้น
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Action buttons inside inspector */}
            <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-slate-100">
              <button
                onClick={() => {
                  const id = selectedProduct.id;
                  setSelectedProduct(null);
                  onOpenReceiveForProduct(id);
                }}
                className="py-2.5 px-3 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold flex items-center justify-center gap-1.5 active:scale-95 transition"
              >
                <Truck className="w-4 h-4" />
                รับสินค้าเข้า
              </button>
              <button
                onClick={() => {
                  const id = selectedProduct.id;
                  setSelectedProduct(null);
                  onOpenWasteForProduct(id);
                }}
                className="py-2.5 px-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 hover:bg-rose-100 text-xs font-semibold flex items-center justify-center gap-1.5 active:scale-95 transition"
              >
                ตัดของเสีย
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Product Modal (Owner Only) */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs animate-in fade-in">
          <div className="w-full max-w-md rounded-3xl bg-white p-5 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">เพิ่มสินค้าใหม่เข้าร้าน</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1 rounded-full text-slate-400 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateProduct} className="space-y-3 mt-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  ชื่อสินค้า (ภาษาไทย) *
                </label>
                <input
                  type="text"
                  required
                  value={newThName}
                  onChange={(e) => setNewThName(e.target.value)}
                  placeholder="เช่น ไวตามิ้ลค์ สูตรเจ 300มล."
                  className="w-full p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  ชื่อภาษาอังกฤษ (ถ้ามี)
                </label>
                <input
                  type="text"
                  value={newEnName}
                  onChange={(e) => setNewEnName(e.target.value)}
                  placeholder="เช่น Vitamilk Soy Milk 300ml"
                  className="w-full p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">บาร์โค้ด</label>
                <input
                  type="text"
                  value={newBarcode}
                  onChange={(e) => setNewBarcode(e.target.value)}
                  placeholder="เช่น 8850123456789"
                  className="w-full p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 outline-none font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">หมวดหมู่</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    className="w-full p-2.5 border border-slate-200 rounded-xl bg-white"
                  >
                    <option value="เครื่องดื่ม">เครื่องดื่ม</option>
                    <option value="ขนมขบเคี้ยว">ขนมขบเคี้ยว</option>
                    <option value="บะหมี่/อาหารสำเร็จรูป">บะหมี่/อาหารสำเร็จรูป</option>
                    <option value="เบเกอรี่">เบเกอรี่</option>
                    <option value="ของใช้ส่วนตัว">ของใช้ส่วนตัว</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">ซัพพลายเออร์</label>
                  <select
                    value={newSupplierId}
                    onChange={(e) => setNewSupplierId(e.target.value)}
                    className="w-full p-2.5 border border-slate-200 rounded-xl bg-white truncate"
                  >
                    {suppliers.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">ราคาขาย (฿)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={newSellPrice}
                    onChange={(e) => setNewSellPrice(e.target.value)}
                    className="w-full p-2.5 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    ราคาทุน (฿) (เจ้าของร้าน)
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    value={newCostPrice}
                    onChange={(e) => setNewCostPrice(e.target.value)}
                    className="w-full p-2.5 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    จำนวนสต็อกแรกเริ่ม
                  </label>
                  <input
                    type="number"
                    value={newInitialQty}
                    onChange={(e) => setNewInitialQty(e.target.value)}
                    className="w-full p-2.5 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    วันหมดอายุล็อตแรก
                  </label>
                  <input
                    type="date"
                    value={newExpiry}
                    onChange={(e) => setNewExpiry(e.target.value)}
                    className="w-full p-2.5 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-teal-600 hover:bg-teal-700 text-white rounded-xl font-bold mt-2 shadow-sm transition active:scale-95"
              >
                บันทึกสินค้าใหม่
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
