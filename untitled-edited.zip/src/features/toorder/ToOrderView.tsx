import React, { useState } from 'react';
import {
  Check,
  CheckCircle2,
  Copy,
  ExternalLink,
  MessageSquare,
  Package,
  Phone,
  ShoppingCart,
  Truck,
} from 'lucide-react';
import { useStore } from '../../lib/store';
import { ProductWithStock, Supplier } from '../../types';

export const ToOrderView: React.FC = () => {
  const { suppliers, productsWithStock } = useStore();
  const [copiedSupplierId, setCopiedSupplierId] = useState<string | null>(null);
  const [orderedMap, setOrderedMap] = useState<Record<string, boolean>>({});
  const [customQuantities, setCustomQuantities] = useState<Record<string, number>>({});

  // Filter products that have suggested_order_qty > 0 or are low on stock
  const orderItems = productsWithStock.filter(
    (p) => (p.suggested_order_qty && p.suggested_order_qty > 0) || p.is_low_stock
  );

  // Group by supplier
  const supplierGroups = suppliers
    .map((supplier) => {
      const items = orderItems.filter((p) => p.supplier_id === supplier.id);
      return {
        supplier,
        items,
      };
    })
    .filter((group) => group.items.length > 0);

  const getQty = (p: ProductWithStock) => {
    if (customQuantities[p.id] !== undefined) {
      return customQuantities[p.id];
    }
    return p.suggested_order_qty ?? (p.low_stock_level * 2 - p.on_hand);
  };

  const handleQtyChange = (productId: string, val: number) => {
    setCustomQuantities((prev) => ({
      ...prev,
      [productId]: Math.max(0, val),
    }));
  };

  const generateLineText = (supplier: Supplier, items: ProductWithStock[]) => {
    const todayStr = new Date().toLocaleDateString('th-TH', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });

    let text = `📦 [ใบสั่งซื้อสินค้า - ร้านสะดวกซื้อ]\n`;
    text += `เรียน: ${supplier.name}\n`;
    text += `วันที่: ${todayStr}\n\n`;
    text += `รายการที่ต้องการสั่ง:\n`;

    items.forEach((item, index) => {
      const qty = getQty(item);
      text += `${index + 1}. ${item.name_th} - จำนวน ${qty} ชิ้น\n`;
    });

    text += `\nขอบคุณครับ/ค่ะ (ส่งจากระบบ Stock Manager)`;
    return text;
  };

  const handleCopyForLine = (supplier: Supplier, items: ProductWithStock[]) => {
    const text = generateLineText(supplier, items);
    navigator.clipboard.writeText(text);
    setCopiedSupplierId(supplier.id);
    setTimeout(() => setCopiedSupplierId(null), 2500);
  };

  const handleToggleOrdered = (supplierId: string) => {
    setOrderedMap((prev) => ({
      ...prev,
      [supplierId]: !prev[supplierId],
    }));
  };

  return (
    <div className="space-y-4 pb-20">
      <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-2xs">
        <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
          <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
            <ShoppingCart className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">
              รายการสินค้าที่ต้องสั่งซื้อ (To-Order List)
            </h2>
            <p className="text-xs text-slate-400">
              คำนวณตามสูตรแนะนำ จัดกลุ่มตามซัพพลายเออร์เพื่อส่ง LINE ทันที
            </p>
          </div>
        </div>

        {/* Formula Explainer Banner */}
        <div className="mt-3 p-3 bg-emerald-50/70 border border-emerald-100 rounded-2xl text-[11px] text-emerald-900 flex items-start gap-2">
          <Truck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
          <div>
            <p className="font-bold">สูตรคำนวณปริมาณแนะนำ (Rule 7):</p>
            <p className="text-emerald-800">
              ปัดขึ้น(ยอดขายเฉลี่ย 14 วัน × (ระยะเวลารอของ + 7 วัน)) - จำนวนคงเหลือ
            </p>
          </div>
        </div>

        {supplierGroups.length === 0 ? (
          <div className="text-center py-12">
            <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto mb-2" />
            <p className="text-sm font-bold text-slate-800">สต็อกสินค้าเพียงพอทุกรายการ</p>
            <p className="text-xs text-slate-400 mt-1">
              ไม่มีสินค้าที่ต้องสั่งซื้อเพิ่มเติมในขณะนี้
            </p>
          </div>
        ) : (
          <div className="space-y-4 mt-4">
            {supplierGroups.map(({ supplier, items }) => {
              const isOrdered = orderedMap[supplier.id];
              const isCopied = copiedSupplierId === supplier.id;

              return (
                <div
                  key={supplier.id}
                  className={`rounded-2xl border transition overflow-hidden ${
                    isOrdered
                      ? 'bg-slate-50 border-slate-200 opacity-75'
                      : 'bg-white border-slate-200 shadow-2xs'
                  }`}
                >
                  {/* Supplier Header Card */}
                  <div className="p-4 bg-slate-50/80 border-b border-slate-100 flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-xs text-slate-900">
                          {supplier.name}
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-200 text-slate-600">
                          รอของ {supplier.lead_time_days} วัน
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-2">
                        <span>{supplier.contact}</span>
                      </p>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => handleCopyForLine(supplier, items)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition active:scale-95 ${
                          isCopied
                            ? 'bg-emerald-600 text-white'
                            : 'bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100'
                        }`}
                      >
                        {isCopied ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>คัดลอกแล้ว!</span>
                          </>
                        ) : (
                          <>
                            <MessageSquare className="w-3.5 h-3.5" />
                            <span>คัดลอกส่ง LINE</span>
                          </>
                        )}
                      </button>

                      <button
                        onClick={() => handleToggleOrdered(supplier.id)}
                        className={`p-1.5 rounded-xl text-xs font-semibold transition ${
                          isOrdered
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                        }`}
                        title="ทำเครื่องหมายว่าสั่งแล้ว"
                      >
                        <Check className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Items in this supplier order */}
                  <div className="p-3 divide-y divide-slate-100">
                    {items.map((item) => {
                      const qty = getQty(item);
                      return (
                        <div
                          key={item.id}
                          className="py-2.5 flex items-center justify-between text-xs first:pt-1 last:pb-1"
                        >
                          <div className="pr-3 flex-1 min-w-0">
                            <p className="font-semibold text-slate-800 truncate">
                              {item.name_th}
                            </p>
                            <p className="text-[11px] text-slate-400 mt-0.5">
                              คงเหลือ: <strong>{item.on_hand}</strong> ชิ้น • ขายเฉลี่ย:{' '}
                              {item.avg_daily_sales_14d} ชิ้น/วัน
                            </p>
                          </div>

                          <div className="flex items-center gap-2 shrink-0">
                            <span className="text-[11px] text-slate-500">สั่งจริง:</span>
                            <input
                              type="number"
                              min="0"
                              value={qty}
                              onChange={(e) =>
                                handleQtyChange(item.id, parseInt(e.target.value, 10) || 0)
                              }
                              className="w-16 p-1.5 text-center font-bold text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-emerald-500 outline-none"
                            />
                            <span className="text-[11px] text-slate-400">ชิ้น</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
