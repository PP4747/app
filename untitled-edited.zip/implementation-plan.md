# implementation-plan.md — M0 to M7

Version 0.1 · Last updated 2026-10-07

Small milestones. Each one runs, is tested with two accounts (owner and staff), is deployed, and is committed. Do not start the next milestone before the checks of the current one pass.

## Calendar (from the course)

| Date | Checkpoint |
|---|---|
| Wed 7 Oct | Weekly update 1: interview video, payment slip, 6 docs, live PWA URL |
| 7–19 Oct | Field test with the real user |
| Wed 14 Oct | Weekly update 2 |
| Mon 19 Oct | Code freeze, feedback video, submission |
| Wed 21 Oct | Final presentation |

Target: M0–M5 deployed by 7 Oct (very tight, see risks), M6 installed on the user's phone before testing starts, M7 during testing.

## Milestones

### M0 — Scaffold and deploy
- Vite + React + TS app shell, Thai/English i18n skeleton, Supabase project connected.
- Deployed to a public HTTPS URL on day one.
- **Done when:** the URL opens on a phone and shows a Thai home screen.

### M1 — Auth and roles
- PIN login, `users` table with role, role-based menu (owner sees everything, staff sees Receive, Waste, Search).
- Two test accounts: `owner`, `staff`.
- **Done when:** staff cannot open owner screens by typing the URL.

### M2 — Schema, rules, and checks
- Tables, RLS policies, views, and database functions from `schema.md`.
- Business rules as pure functions in `src/lib/rules/` with `runChecks()`.
- **No UI code in this milestone.**

`runChecks()` must log PASS or FAIL for at least:
1. Sale of 5 from two batches (3 expiring Oct 10, 10 expiring Oct 20) → takes 3 from the Oct 10 batch, 2 from the Oct 20 batch.
2. Sale larger than stock → stock becomes 0 and `negative_stock_flag` is true.
3. `on_hand = 8`, `low_stock_level = 10` → product appears in low stock.
4. Batch expiring in 5 days with `expiry_warning_days = 7` → appears in expiring; batch expiring in 10 days → does not.
5. Suggested order with avg 6/day, lead time 2 days, on_hand 20 → `ceil(6 × 9) − 20 = 34`.
6. POS row with a barcode that matches a product → matched; row with unknown barcode and unknown name → `unmatched`, not dropped.
7. Staff user querying `cost_price` → rejected by RLS.
8. Waste of 4 units at cost 12.50 → waste value 50.00.

### M3 — Main screens per role
- Owner home: alerts summary, to-order shortcut, upload shortcut.
- Staff home: Receive, Waste, Search.
- Product search (Thai and English) and product detail with stock and batches. Seed data included.
- **Done when:** both roles see their own home screen with seed data.

### M4 — Input and audit
- Product list import (one-time CSV/Excel) with a preview and error list.
- Receive (scan or search, quantity, expiry), Waste (with reason), Manual sale entry, Shelf count.
- Barcode scan with `BarcodeDetector` and the `@zxing/browser` fallback. Unknown barcode → link once.
- Every write goes through a database function and creates `audit_logs`.
- **Done when:** a delivery received by staff shows up as a new batch for the owner.

### M5 — POS upload, alerts, to-order, realtime
- POS CSV upload: column mapping screen (first time), preview, apply, unmatched rows list that the owner resolves once.
- Alerts list (low stock, expiring, expired) and to-order list grouped by supplier, with mark-as-ordered.
- Realtime: a change on one phone appears on another without refresh.
- **Done when:** two phones show the same stock after an upload, and the to-order list matches `v_suggested_order`.

### M6 — PWA install and push
- `manifest.json`, icons, `apple-touch-icon`, service worker (app shell only).
- Daily Edge Function and Web Push where supported.
- Installed on one iPhone and one Android phone.
- **Done when:** the app opens full screen from the home screen icon on both phones.

### M7 — Hardening (during testing)
- Edge cases from real use, CSV export, weekly summary, empty/error states, backups, session lifetime on iOS.
- **Done when:** the pre-launch checklist below is fully ticked.

## Pre-launch checklist (before the user installs)

- [ ] Installs on both iPhone and Android
- [ ] One account per real person, correct role, no shared logins
- [ ] Every cell of the permissions table in `prd.md` tested with the wrong role
- [ ] No secret keys in the client or the repo
- [ ] `runChecks()` all PASS on the live URL
- [ ] Empty, offline, wrong-PIN, and bad-CSV states show clear Thai messages
- [ ] CSV export works
- [ ] One line in the app: who to contact and how to send a screenshot

## Risks

| Risk | Plan |
|---|---|
| No payer or interview yet | Do this first. The docs are only valid after the interview. See `progress.md`. |
| Store has no POS export | Switch to manual sale entry for fast sellers plus weekly shelf count. Rules and schema already support this. |
| POS export columns differ from what we assume | Build the column mapping screen in M5, and get a real sample file before starting M5. |
| iOS push or session problems | In-app alerts list carries everything. Test the session on iPhone early. |
| Timeline is very tight | If M5 slips, cut order: weekly summary first, then push, then realtime. Never cut RLS or audit logs. |
