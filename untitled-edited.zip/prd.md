# prd.md — ร้านรุ่งเรืองพานิช (Convenience & Wholesale Store Stock Manager)

Version 1.0 · Last updated 2026-10-12 · Owner of this doc: team

## 1. What

A mobile-first PWA for **ร้านรุ่งเรืองพานิช (Main WareHouse)**, a convenience and wholesale grocery store. The app helps the owner and staff track stock on hand, avoid stockouts on fast-selling products, prevent losses from expired goods, and streamline daily stock deductions by directly importing daily sales CSV exports from the store's POS software.

## 2. Why

- **Store Context**: ร้านรุ่งเรืองพานิช sells a large range of products both in wholesale cartons (สินค้ายกลัง) and retail units (ลูก, แพค, ชิ้น), including beverages, coffee, canned goods, household cleaning supplies, baby care, and packaging bags.
- **Pain Points**:
  - The store tracks hundreds of items with varying delivery batch dates. Checking expiration dates manually across warehouses often leads to expired goods.
  - Popular fast-movers (e.g. นมวัวแดง, น้ำดื่มคริสตัล, น้ำมันมรกต, เป๊ปซี่, เนสกาแฟ) frequently run low without early warning.
  - The existing POS system exports daily transaction ledgers, but does not provide FIFO batch tracking, mobile expiry alerts, or LINE order suggestions.

## 3. Who (personas and roles)

| Role | Who | Device | What they need |
|---|---|---|---|
| `owner` | คุณสมชาย (เจ้าของร้านรุ่งเรืองพานิช) | มือถือส่วนตัว (iPhone/Android) | ดูสต็อกรวม, การแจ้งเตือนสต็อกต่ำและหมดอายุ, อัปโหลดไฟล์ POS รายวัน, คำนวณยอดสั่งซื้อส่ง LINE, ดูราคาทุนและส่งออก CSV |
| `staff` | พนักงานคลังสินค้า & หน้าร้าน | แท็บเล็ตหรือมือถือประจำร้าน | บันทึกรับสินค้าเข้าพร้อมวันหมดอายุ, ตัดของเสีย (แตกหัก/หมดอายุ), บันทึกยอดขาย, ตรวจนับสต็อกจริง (ราคาทุนถูกซ่อนไว้ตาม RLS) |

## 4. Core features (MVP)

1. **POS Sales Ledger Import**: Direct upload and automatic parsing of the store's POS export CSV (auto-detecting columns `CF_ITEMNAME`, `CF_ITEMID`, `CF_TDBASEQUANTITY`, `CF_FSTOCKMAIN`, `TRANDATE`, etc.) with FIFO deduction and duplicate upload protection.
2. **Receive Delivery (รับของ)**: Quick scanner or selector to log new delivery lots with expiration dates (`stock_batches`).
3. **Record Waste (ของเสีย)**: Track damaged, expired, or lost goods with reason codes and automated cost valuation (owner only).
4. **Manual Sale & Shelf Count**: Backup manual sales entry and shelf counting for slow-moving inventory.
5. **Urgent Alerts**: Flags batches expiring within 7 days (and urgent within 2 days), expired items, and fast sellers reaching zero stock.
6. **To-Order List**: Generates suggested order quantities per supplier and provides one-tap **"คัดลอกส่ง LINE"** formatted messages.
7. **Bilingual & Mobile PWA**: Thai-first UI with installable PWA manifest and service worker.

## 5. Daily flow

1. End of day: Owner exports daily transactions from the store POS and uploads the CSV file.
2. The app matches rows by product ID (`CF_ITEMID`) and Thai product name (`CF_ITEMNAME`), applying FIFO deductions to active batches.
3. Deliveries received by staff during the day are logged under **Receive**, immediately updating active batches.
4. Any damaged packages or expired lots are logged under **Waste**.
5. Owner reviews the **To-Order** tab, copies formatted orders into suppliers' LINE chats, and marks them as ordered.

## 6. Permissions

| Action | staff | owner |
|---|---|---|
| Log in with own PIN (1234 / 5678) | ✓ | ✓ |
| Search products, see stock on hand | ✓ | ✓ |
| Receive delivery with expiry date | ✓ | ✓ |
| Record waste (damage/expired) | ✓ | ✓ |
| Manual sale entry & Shelf count | ✓ | ✓ |
| See cost price, profit, waste value | — | ✓ |
| Upload store POS CSV file | — | ✓ |
| View and copy to-order list for LINE | — | ✓ |
| View weekly summary and export CSV | — | ✓ |
| View audit log | — | ✓ |

## 7. Business rules

1. `on_hand` = sum of `quantity` across active `stock_batches`.
2. FIFO deduction: earliest expiration date deducted first; non-expiring batches deducted last.
3. Negative stock guard: stock never drops below 0; flags `negative_stock_flag`.
4. Low stock: `on_hand <= low_stock_level`.
5. Expiry warning: `expiry_date <= today + 7 days`. Urgent: $\le 2$ days or expired.
6. Suggested order formula: `ceil(avg_daily_sales_14d × (supplier.lead_time_days + 7)) − on_hand`.
7. POS matching: matches by `CF_ITEMID` (or barcode) first, then exact/normalized `CF_ITEMNAME`.
8. Unmatched POS rows are kept in `pos_import_rows` with status `unmatched` and never dropped.
9. Duplicate upload guard: checks filename and sales date on the same day before applying.
10. RLS security: staff users cannot access `cost_price` or monetary waste value.
11. Immutability: every write creates an audit log entry; soft deletes use `is_active = false`.

## 8. Out of scope

- Direct live database sync with the proprietary POS server (handled via daily CSV upload).
- Automated payment gateway integration with suppliers.
- Multi-branch accounting.

## 9. Success criteria

- Daily POS upload takes under 10 seconds to parse and apply.
- Zero forgotten supplier orders per week.
- Time to check reorders reduced from 15 minutes to under 2 minutes.
