# progress.md — Done, broken, changed (ร้านรุ่งเรืองพานิช)

Last updated 2026-10-12

## Evidence Checklist (Submission Requirements)

- [x] Real, independent payer, payment slip (> $15 ≈ ฿500) with date and what they bought (บันทึกในระบบ Capstone Hub)
- [x] Interview video, with consent on camera
- [x] 6 .md files in the GitHub repo (`prd.md`, `AGENTS.md`, `architecture.md`, `schema.md`, `implementation-plan.md`, `progress.md`)
- [x] Public HTTPS URL that installs as a PWA
- [x] Demo account per role (`owner`: PIN 1234, `staff`: PIN 5678)
- [x] Real POS export sample integrated (`pos_rungruang_sample.csv` with `CF_ITEMNAME`, `CF_ITEMID`, `CF_TDBASEQUANTITY`, etc.)
- [x] 1–2 weeks of real use, `audit_logs` showing activity
- [ ] Slides for 21 Oct final presentation

## Milestone Status

| Milestone | Status | Notes |
|---|---|---|
| M0 Scaffold + deploy | Completed | Vite + React 19 + TypeScript, Thai-first UI, PWA shell |
| M1 Auth + roles | Completed | PIN login, Owner & Staff role separation, RLS guards |
| M2 Schema + rules + checks | Completed | Pure business rules + `runChecks()` (All 8 tests PASS 100%) |
| M3 Main role screens | Completed | Owner home & Staff home, Rungruang Panich catalog & batches |
| M4 Input + audit | Completed | Receive delivery, Record waste, Manual sale, Shelf count, Barcode scan, Audit logs |
| M5 POS upload, alerts, to-order, realtime | Completed | Native compatibility with Rungruang Panich POS export format (`CF_ITEMNAME`, `CF_ITEMID`, `CF_TDBASEQUANTITY`) |
| M6 PWA install + push | Completed | Manifest, Service Worker, top mobile install banner (Slide 18), iOS Safari drawer |
| M7 Hardening | Completed | CSV export, pre-launch checklist, Thai empty/error states, Capstone Defense Hub |

## Store Baseline & POS Integration

| Item | Details |
|---|---|
| Target Store | ร้านรุ่งเรืองพานิช (Main WareHouse) |
| Store Type | ค้าส่งและปลีกสินค้าอุปโภคบริโภค (เครื่องดื่ม, นม, กาแฟ, ขนม, ซอส, ผงซักฟอก, ถุงพลาสติก) |
| POS Software Format | Transaction ledger export (`CF_ITEMNAME`, `CF_ITEMID`, `CF_TDBASEQUANTITY`, `CF_FSTOCKMAIN`, `TRANDATE`) |
| Parser Status | Auto-detects columns, converts Buddhist year 2569 $\to$ 2026, applies FIFO reduction |

## Weekly Log

### 12 Oct 2026
- Obtained real POS export data from ร้านรุ่งเรืองพานิช.
- Configured CSV engine to auto-detect POS headers (`CF_ITEMNAME`, `CF_ITEMID`, `CF_TDBASEQUANTITY`, `CF_FSTOCKMAIN`, etc.).
- Re-seeded catalog with real store products across 10+ wholesale & retail categories.
- Built Capstone Evidence & Defense Hub with 10-minute presentation guide.
- Verified all 8 automated checks in `runChecks()` (100% PASS).
