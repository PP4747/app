# Convenience Store Stock Manager — Data Origin & Architecture Blueprint

This document details the source, calculation engine, and lifecycle of all data shown in the Store Stock Manager application (including the Alerts screen, inventory counts, batches, and suggested orders).

---

## User Review & Critical Decisions

> [!NOTE]
> The items currently visible in the application (Farmhouse bread, Meiji milk, Lay's chips, Mama noodles, etc.) come from the **pre-configured seed dataset** located in `src/lib/mockData.ts`, initialized to satisfy **Milestone M3** of the course capstone requirements ("Seed data included").

- **Current State**: Seed data is stored in the browser's persistent `localStorage` under the key `stockmgr_store_v1_*`.
- **Customization for Pilot**: The store owner can:
  1. Continue using the sample items alongside real entries.
  2. Add new real store products via the **"เพิ่มสินค้าใหม่"** button.
  3. Upload their daily POS sales CSV file via the **"นำเข้า POS"** screen.
  4. Use the **"รีเซ็ตข้อมูล"** or clear storage option when transitioning to live store data.

---

## 1. Where Does Each Part of the Alert Screen Come From?

Referring to the uploaded screenshot:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           RAW DATA SOURCE                                   │
│  src/lib/mockData.ts  ──►  localStorage  ──►  src/lib/store.tsx             │
└──────────────────────────────────────┬──────────────────────────────────────┘
                                       │
                 ┌─────────────────────┴─────────────────────┐
                 ▼                                           ▼
      [ stock_batches Table ]                     [ products Table ]
      • product_id: 'p-bread-farmhouse'           • name_th: 'ขนมปังแซนด์วิช...'
      • quantity: 3                               • low_stock_level: 6
      • expiry_date: '2026-10-13'                 • track_mode: 'fast'
                 │                                           │
                 │                                           │
                 ▼                                           ▼
┌─────────────────────────────────┐         ┌─────────────────────────────────┐
│     evaluateExpiry() Rule       │         │       isLowStock() Rule         │
│ Compare expiry_date vs. Today   │         │ Compare on_hand vs.             │
│ (2026-10-12 reference date):    │         │ low_stock_level:                │
│ • 2026-10-13 = 1 day left       │         │ • Lay's: on_hand=6 <= 10        │
│   (isUrgent = true, <= 2 days)  │         │   ──► LOW STOCK ALERT           │
│ • 2026-10-16 = 4 days left      │         │ • Mama: on_hand=14 <= 24        │
│   (isExpiringSoon = true, <= 7) │         │   ──► LOW STOCK ALERT           │
└────────────────┬────────────────┘         └────────────────┬────────────────┘
                 │                                           │
                 └─────────────────────┬─────────────────────┘
                                       ▼
                       [ Alerts Screen View Model ]
                       Rendered into React Component
```

### Specific Items Breakdown

1. **ขนมปังแซนด์วิช ฟาร์มเฮ้าส์ 240ก. (ล็อต read-1: 3 ชิ้น, หมดอายุ 2026-10-13)**:
   - **Source**: `initialBatches` in `src/lib/mockData.ts` with expiry `2026-10-13`.
   - **Calculation**: Relative to the simulated store date (`2026-10-12`), there is **1 day remaining** ($\le 2$ days), triggering the `ด่วนมาก (Urgent)` tag under Rule 6.
2. **ขนมปังแซนด์วิช ฟาร์มเฮ้าส์ 240ก. (ล็อต read-2: 5 ชิ้น, หมดอายุ 2026-10-16)**:
   - **Source**: `initialBatches` with expiry `2026-10-16`.
   - **Calculation**: **4 days remaining** ($\le 7$ days warning window), triggering the `เตือนใกล้หมดอายุ` badge under Rule 5.
3. **นมสดพาสเจอร์ไรส์ เมจิ 200มล. (ล็อต milk-1: 4 ชิ้น, หมดอายุ 2026-10-14 & milk-2: 8 ชิ้น, หมดอายุ 2026-10-19)**:
   - **Source**: Meiji milk delivery batches from CP All supplier with short shelf-life dates.
4. **เลย์ รสมันฝรั่งแท้ 50ก. (คงเหลือ 6 ชิ้น, เกณฑ์เตือน $\le 10$ ชิ้น)**:
   - **Source**: Total active batch quantities sum to 6. Because $6 \le 10$, it is classified as Low Stock under Rule 4.
   - **Suggested order (30 ชิ้น)**: Calculated by $\lceil\text{avg\_daily\_sales} \times (\text{lead\_time} + 7)\rceil - \text{on\_hand} = \lceil 4 \times (2 + 7)\rceil - 6 = 36 - 6 = 30$ units.
5. **มาม่า บะหมี่กึ่งสำเร็จรูป ต้มยำกุ้ง 55ก. (คงเหลือ 14 ชิ้น, เกณฑ์เตือน $\le 24$ ชิ้น)**:
   - **Suggested order (67 ชิ้น)**: Calculated by $\lceil 9 \times (2 + 7)\rceil - 14 = 81 - 14 = 67$ units.

---

## 2. Real-Time Data Flow & Storage Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                             BROWSER CLIENT (PWA)                            │
│                                                                             │
│  ┌───────────────────────┐             ┌──────────────────────────────────┐ │
│  │   Input Actions       │             │       Pure Business Rules        │ │
│  │  • รับของ (Receive)    ├────────────►│  (src/lib/rules/stockRules.ts)   │ │
│  │  • ตัดทิ้ง (Waste)     │             │  • calculateOnHand()             │ │
│  │  • ขาย (Manual/POS)   │             │  • deductFIFOBatches()           │ │
│  │  • ตรวจนับ (Count)    │             │  • evaluateExpiry()              │ │
│  └───────────────────────┘             │  • calculateSuggestedOrder()     │ │
│                                        └────────────────┬─────────────────┘ │
│                                                         │                   │
│                                                         ▼                   │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │                   Transactional Store (src/lib/store.tsx)            │   │
│  │  • Writes to stock_batches (creates or updates remaining units)      │   │
│  │  • Writes to stock_movements (immutable audit trail)                 │   │
│  │  • Writes to audit_logs (tracks user_id, action, timestamp)          │   │
│  └──────────────────────────────────────┬───────────────────────────────┘   │
│                                         │                                   │
│                                         ▼                                   │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │                 Persistent Browser Cache (localStorage)              │   │
│  │  stockmgr_store_v1_products, stockmgr_store_v1_batches, etc.         │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. How to Connect Real Store Data During Field Testing

When testing with the store owner:
1. **Adding Existing Catalog**: Use the **"เพิ่มสินค้าใหม่"** button on the Products tab or import a spreadsheet CSV.
2. **Receiving Deliveries**: When a supplier arrives, tap **"รับของ"** or scan the barcode to log quantity and expiry dates into new batches.
3. **Daily Sales**: Upload the store's POS export CSV or enter sales via **"บันทึกขาย"**.
4. **Exporting Data**: At any time, tap **"สรุปสัปดาห์" $\to$ "ส่งออกข้อมูลเป็น CSV"** to download all records into Excel without lock-in.
